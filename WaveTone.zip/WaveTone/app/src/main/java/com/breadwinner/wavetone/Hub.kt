package com.breadwinner.wavetone

import android.content.Context
import android.graphics.Bitmap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Locale

/** What is playing on one device. [posAt] is SystemClock.elapsedRealtime() when [posMs] was true. */
data class MediaInfo(
    val title: String = "",
    val artist: String = "",
    val app: String = "",
    val playing: Boolean = false,
    val posMs: Long = 0L,
    val durMs: Long = 0L,
    val posAt: Long = 0L,
    val canLike: Boolean = false,
    val liked: Boolean = false,
    val vol: Int = -1,
    val coverKey: Int = 0,
    val cover: Bitmap? = null,
    val appIcon: Bitmap? = null
) {
    val has: Boolean get() = title.isNotEmpty()

    fun now(): Long {
        if (!playing) return posMs
        val p = posMs + (android.os.SystemClock.elapsedRealtime() - posAt)
        return if (durMs > 0) p.coerceIn(0L, durMs) else max0(p)
    }

    private fun max0(v: Long): Long = if (v < 0) 0 else v
}

/** Shared state between the engine, the service and the screens. */
object Hub {
    private var sp: android.content.SharedPreferences? = null

    var running by mutableStateOf(false)
    /** 0 = my hotspot, 1 = auto hotspot (default), 2 = USB cable */
    var mode by mutableStateOf(1)
    var ssid by mutableStateOf("")
    var pass by mutableStateOf("")
    var hotspotMsg by mutableStateOf("")
    var port by mutableStateOf(8765)

    // the PC on the other end
    var connected by mutableStateOf(false)
    var peerName by mutableStateOf("")
    var peerWant by mutableStateOf(false)    // the PC wants to hear this phone
    var peerAllow by mutableStateOf(false)   // the PC lets the phone hear it

    // what you choose on this phone
    var wantPc by mutableStateOf(true)       // play the PC's sound on this phone
    var allowSend by mutableStateOf(true)    // let the PC hear this phone
    var playVol by mutableStateOf(100)       // percent
    var playMute by mutableStateOf(false)
    var sendGain by mutableStateOf(100)      // percent
    var latency by mutableStateOf(120)       // ms of cushion: 60 low, 120 balanced, 250 high
    var showHealth by mutableStateOf(true)
    var stayAwake by mutableStateOf(false)
    /** 0 smart, 1 fast, 2 steady */
    var delayMode by mutableStateOf(0)
    /** lip-sync nudge in ms: negative = sound earlier, positive = later */
    var nudge by mutableStateOf(0)
    /** 0 bars, 1 waves */
    var viz by mutableStateOf(1)
    /** 0 follow the phone, 1 light, 2 dark */
    var theme by mutableStateOf(0)
    var bubbleOn by mutableStateOf(false)
    var bubbleX by mutableStateOf(0)
    var bubbleY by mutableStateOf(400)

    /** The user wants the link up. Sent to the PC in the beacon so it can reconnect by itself. */
    var linkWanted by mutableStateOf(true)
    var wantedSeq by mutableStateOf(1)
    var everConnected by mutableStateOf(false)

    // media
    var local by mutableStateOf(MediaInfo())     // what plays on this phone
    var peerMedia by mutableStateOf(MediaInfo()) // what plays on the PC
    /** 0 pick by itself, 1 this phone, 2 the PC */
    var mediaPick by mutableStateOf(0)
    var notifAccess by mutableStateOf(false)
    var phoneVol by mutableStateOf(50)
    var targetMs by mutableStateOf(0)
    var underruns by mutableStateOf(0)

    // live numbers
    var playLevel by mutableStateOf(0f)
    var sendLevel by mutableStateOf(0f)
    val playBands = BandAnalyzer()
    val sendBands = BandAnalyzer()
    var rttMs by mutableStateOf(0)
    var bufMs by mutableStateOf(0)
    var dropped by mutableStateOf(0)
    var sentKb by mutableStateOf(0L)
    var recvKb by mutableStateOf(0L)

    val errors = mutableStateListOf<String>()

    fun init(c: Context) {
        if (sp != null) return
        val s = c.getSharedPreferences("wt", Context.MODE_PRIVATE)
        sp = s
        mode = s.getInt("mode", 1)
        wantPc = s.getBoolean("wantPc", true)
        allowSend = s.getBoolean("allowSend", true)
        playVol = s.getInt("playVol", 100)
        sendGain = s.getInt("sendGain", 100)
        latency = s.getInt("latency", 120)
        showHealth = s.getBoolean("health", true)
        stayAwake = s.getBoolean("awake", false)
        delayMode = s.getInt("delayMode", 0)
        nudge = s.getInt("nudge", 0)
        viz = s.getInt("viz", 1)
        theme = s.getInt("theme", 0)
        bubbleOn = s.getBoolean("bubbleOn", false)
        bubbleX = s.getInt("bubbleX", 0)
        bubbleY = s.getInt("bubbleY", 400)
        mediaPick = s.getInt("mediaPick", 0)
    }

    /** Which player the screens should show: 1 = this phone, 2 = the PC. */
    fun mediaSource(): Int = when (mediaPick) {
        1 -> 1
        2 -> 2
        else -> when {
            local.playing -> 1
            connected && peerMedia.playing -> 2
            local.has -> 1
            connected && peerMedia.has -> 2
            else -> 1
        }
    }

    fun shownMedia(): MediaInfo = if (mediaSource() == 2) peerMedia else local

    fun save() {
        sp?.edit()
            ?.putInt("mode", mode)?.putBoolean("wantPc", wantPc)?.putBoolean("allowSend", allowSend)
            ?.putInt("playVol", playVol)?.putInt("sendGain", sendGain)?.putInt("latency", latency)
            ?.putBoolean("health", showHealth)?.putBoolean("awake", stayAwake)
            ?.putInt("delayMode", delayMode)?.putInt("nudge", nudge)?.putInt("viz", viz)?.putInt("theme", theme)
            ?.putBoolean("bubbleOn", bubbleOn)?.putInt("bubbleX", bubbleX)?.putInt("bubbleY", bubbleY)
            ?.putInt("mediaPick", mediaPick)
            ?.apply()
    }

    /** Tells the PC what we want and allow, then re-checks what should be running. */
    fun changed() {
        save()
        Engine.sendControl()
        Engine.refresh()
        MediaBridge.pokeWidgets()
    }

    fun logErr(msg: String) {
        val t = java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(java.util.Date())
        errors.add(0, "$t  $msg")
        while (errors.size > 60) errors.removeAt(errors.size - 1)
    }
}

/** Finds the phone's address on the hotspot, USB cable or Wi-Fi. */
fun findIp(mode: Int): Pair<String, String>? {
    val found = ArrayList<Pair<String, String>>()
    try {
        val all = NetworkInterface.getNetworkInterfaces() ?: return null
        for (ni in all) {
            if (!ni.isUp || ni.isLoopback) continue
            for (a in ni.inetAddresses) {
                if (a is Inet4Address && a.isSiteLocalAddress) {
                    val host = a.hostAddress ?: continue
                    found.add(host to ni.name)
                }
            }
        }
    } catch (e: Exception) {
        return null
    }
    fun rank(n: String): Int {
        val usb = n.startsWith("rndis") || n.startsWith("usb") || n.startsWith("eth")
        val hot = n.startsWith("ap") || n.startsWith("swlan")
        val wifi = n.startsWith("wlan")
        return if (mode == 2) {
            when { usb -> 0; hot -> 1; wifi -> 2; else -> 3 }
        } else {
            when { hot -> 0; wifi -> 1; usb -> 2; else -> 3 }
        }
    }
    return found.minByOrNull { rank(it.second) }
}

package com.breadwinner.wavetone

import android.content.ComponentName
import android.service.notification.NotificationListenerService

/**
 * Having this switched on in Android's "Notification access" is what lets WaveTone see
 * which song is playing and press its buttons. It does not read or keep any notifications.
 */
class ToneNotifService : NotificationListenerService() {
    override fun onCreate() {
        super.onCreate()
        MediaBridge.init(applicationContext)
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        Hub.notifAccess = true
        MediaBridge.attach(ComponentName(this, ToneNotifService::class.java))
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        Hub.notifAccess = false
        MediaBridge.detach()
    }
}

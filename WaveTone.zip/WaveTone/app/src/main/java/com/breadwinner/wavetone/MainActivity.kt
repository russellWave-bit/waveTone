package com.breadwinner.wavetone

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val projLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val d = r.data
        if (r.resultCode == RESULT_OK && d != null) {
            val i = Intent(this, ToneService::class.java)
                .putExtra("code", r.resultCode).putExtra("data", d).putExtra("mode", Hub.mode)
            ContextCompat.startForegroundService(this, i)
        } else {
            Hub.hotspotMsg = "Sound capture was not allowed."
        }
    }

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res[Manifest.permission.RECORD_AUDIO] == false) {
            Hub.hotspotMsg = "WaveTone needs the Microphone permission to capture the phone's sound."
        } else {
            askProjection()
        }
    }

    private fun askProjection() {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projLauncher.launch(mpm.createScreenCaptureIntent())
    }

    private fun begin() {
        Hub.hotspotMsg = ""
        val need = ArrayList<String>()
        need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Hub.mode == 1) {
            need.add(Manifest.permission.ACCESS_FINE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        }
        val missing = need.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) askProjection() else permLauncher.launch(missing.toTypedArray())
    }

    private fun end() {
        startService(Intent(this, ToneService::class.java).setAction(ToneService.STOP))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Hub.init(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Acc)) {
                WaveToneApp(onStart = { begin() }, onStop = { end() })
            }
        }
    }
}

package com.breadwinner.wavetone

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.widget.RemoteViews

class NowPlayingWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) { MediaBridge.init(c); Widgets.updateAll(c) }
}

class SwitchesWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) { MediaBridge.init(c); Widgets.updateAll(c) }
}

class MiniWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) { MediaBridge.init(c); Widgets.updateAll(c) }
}

object Widgets {
    private fun bcast(c: Context, action: String, code: Int): PendingIntent =
        PendingIntent.getBroadcast(c, code, Intent(c, ActionReceiver::class.java).setAction(action), PendingIntent.FLAG_IMMUTABLE)

    private fun openApp(c: Context, code: Int, autostart: Boolean = false): PendingIntent =
        PendingIntent.getActivity(
            c, code, Intent(c, MainActivity::class.java).putExtra("autostart", autostart).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    /** The button that connects or disconnects. When the sound link is off it opens the app to start it. */
    private fun linkIntent(c: Context, code: Int): PendingIntent =
        if (Hub.running) bcast(c, MediaBridge.A_LINK, code) else openApp(c, code, true)

    private fun linkText(): String = when {
        !Hub.running -> "Start"
        Hub.connected -> "Disconnect"
        else -> "Connect"
    }

    private fun statusText(): String = when {
        Hub.connected -> "Connected to " + Hub.peerName
        Hub.running && Hub.everConnected -> "Reconnecting..."
        Hub.running -> "Waiting for your PC"
        else -> "Off"
    }

    private fun rounded(src: Bitmap?, px: Int, r: Float): Bitmap? {
        if (src == null) return null
        return try {
            val out = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
            val scaled = Bitmap.createScaledBitmap(src, px, px, true)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.shader = BitmapShader(scaled, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            Canvas(out).drawRoundRect(RectF(0f, 0f, px.toFloat(), px.toFloat()), r, r, p)
            out
        } catch (e: Exception) {
            null
        }
    }

    fun updateAll(c: Context) {
        val awm = AppWidgetManager.getInstance(c)
        push(c, awm, NowPlayingWidget::class.java) { now(c) }
        push(c, awm, SwitchesWidget::class.java) { switches(c) }
        push(c, awm, MiniWidget::class.java) { mini(c) }
    }

    private fun push(c: Context, awm: AppWidgetManager, cls: Class<*>, build: () -> RemoteViews) {
        val ids = awm.getAppWidgetIds(ComponentName(c, cls))
        if (ids.isEmpty()) return
        awm.updateAppWidget(ids, build())
    }

    private fun now(c: Context): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.widget_now)
        val pc = Hub.mediaSource() == 2
        val m = Hub.shownMedia()
        v.setTextViewText(R.id.w_title, if (m.has) m.title else "Nothing playing")
        v.setTextViewText(
            R.id.w_sub,
            if (m.has) (m.app.ifEmpty { if (pc) "PC" else "Phone" } + (if (pc) " on PC" else "") + (if (m.artist.isNotEmpty()) " - " + m.artist else ""))
            else "Play something in any app"
        )
        val cover = rounded(m.cover, 140, 28f)
        if (cover != null) v.setImageViewBitmap(R.id.w_cover, cover) else v.setImageViewResource(R.id.w_cover, R.drawable.cover_ph)
        v.setImageViewResource(R.id.w_play, if (m.playing) R.drawable.ic_pause else R.drawable.ic_play)
        v.setOnClickPendingIntent(R.id.w_prev, bcast(c, MediaBridge.A_PREV, 1))
        v.setOnClickPendingIntent(R.id.w_play, bcast(c, MediaBridge.A_TOGGLE, 2))
        v.setOnClickPendingIntent(R.id.w_next, bcast(c, MediaBridge.A_NEXT, 3))
        v.setOnClickPendingIntent(R.id.w_cover, openApp(c, 4))
        v.setOnClickPendingIntent(R.id.w_texts, openApp(c, 5))
        return v
    }

    private fun switches(c: Context): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.widget_switches)
        v.setInt(R.id.w_sw_pc, "setBackgroundResource", if (Hub.wantPc) R.drawable.chip_mint else R.drawable.chip_off)
        v.setInt(R.id.w_sw_phone, "setBackgroundResource", if (Hub.allowSend) R.drawable.chip_rose else R.drawable.chip_off)
        v.setTextViewText(R.id.w_sw_pc_state, if (Hub.wantPc) "On" else "Off")
        v.setTextViewText(R.id.w_sw_phone_state, if (Hub.allowSend) "On" else "Off")
        v.setTextViewText(R.id.w_sw_link, linkText())
        v.setTextViewText(R.id.w_sw_status, statusText())
        v.setOnClickPendingIntent(R.id.w_sw_pc, bcast(c, MediaBridge.A_PC, 6))
        v.setOnClickPendingIntent(R.id.w_sw_phone, bcast(c, MediaBridge.A_PHONE, 7))
        v.setOnClickPendingIntent(R.id.w_sw_link, linkIntent(c, 8))
        v.setOnClickPendingIntent(R.id.w_sw_status, openApp(c, 9))
        return v
    }

    private fun mini(c: Context): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.widget_mini)
        v.setTextViewText(R.id.w_mini_status, statusText())
        val dirs = (if (Hub.wantPc) "PC to phone on" else "PC to phone off") + "  |  " + (if (Hub.allowSend) "Phone to PC on" else "Phone to PC off")
        v.setTextViewText(R.id.w_mini_dirs, dirs)
        v.setTextViewText(R.id.w_mini_link, linkText())
        v.setOnClickPendingIntent(R.id.w_mini_link, linkIntent(c, 10))
        v.setOnClickPendingIntent(R.id.w_mini_root, openApp(c, 11))
        return v
    }
}

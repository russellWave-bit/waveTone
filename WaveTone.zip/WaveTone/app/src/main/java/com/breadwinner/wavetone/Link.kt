package com.breadwinner.wavetone

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.Socket

/**
 * One connection to the PC. Every message is: 1 byte type, 4 bytes length, then the bytes.
 * Types: 1 control (JSON), 2 audio (48 kHz stereo 16-bit), 3 ping, 4 pong.
 */
class Link(private val sock: Socket) {
    private val out = DataOutputStream(BufferedOutputStream(sock.getOutputStream(), 16384))
    private val inp = DataInputStream(BufferedInputStream(sock.getInputStream(), 16384))
    @Volatile var alive = true

    fun send(type: Int, payload: ByteArray) {
        if (!alive) return
        synchronized(out) {
            try {
                out.writeByte(type)
                out.writeInt(payload.size)
                out.write(payload)
                out.flush()
            } catch (e: Exception) {
                close()
            }
        }
    }

    fun readLoop(onFrame: (Int, ByteArray) -> Unit) {
        try {
            while (alive) {
                val t = inp.readUnsignedByte()
                val n = inp.readInt()
                if (n < 0 || n > 1_000_000) throw IOException("bad frame")
                val b = ByteArray(n)
                inp.readFully(b)
                onFrame(t, b)
            }
        } catch (e: Exception) {
        } finally {
            close()
        }
    }

    fun close() {
        alive = false
        try { sock.close() } catch (e: Exception) { }
    }
}

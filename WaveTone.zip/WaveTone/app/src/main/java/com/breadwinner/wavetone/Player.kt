package com.breadwinner.wavetone

import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

fun openNotifAccess(c: Context) {
    try {
        c.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
    }
}

/** A clock that ticks twice a second so the progress bar moves. */
@Composable
fun rememberNowMs(): Long {
    var t by remember { mutableStateOf(SystemClock.elapsedRealtime()) }
    LaunchedEffect(Unit) {
        while (true) {
            t = SystemClock.elapsedRealtime()
            delay(500)
        }
    }
    return t
}

private fun sourceLine(m: MediaInfo, pc: Boolean): String {
    val app = if (m.app.isEmpty()) (if (pc) "PC" else "Phone") else m.app
    return if (pc) "$app on your PC" else app
}

/** The small player on the main Sound page. Tap the cover to open the big Media player. */
@Composable
fun MiniPlayer(onOpen: () -> Unit) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    val tick = rememberNowMs()
    val pc = Hub.mediaSource() == 2
    val m = Hub.shownMedia()
    val shape = RoundedCornerShape(28.dp)
    Column(Modifier.fillMaxWidth().glass(shape, pal, strong = true)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.plainClick { onOpen() }) { Cover(m, 56.dp, 16.dp) }
            Column(
                Modifier.weight(1f).padding(start = 16.dp, end = 6.dp).plainClick {
                    if (!m.has && !Hub.notifAccess) openNotifAccess(ctx) else onOpen()
                }
            ) {
                T(if (m.has) m.title else "Nothing playing", 15, maxLines = 1, weight = FontWeight.Bold)
                T(
                    if (m.has) sourceLine(m, pc) + (if (m.artist.isNotEmpty()) "  -  " + m.artist else "")
                    else if (!Hub.notifAccess) "Tap to allow media access" else "Play something in any app",
                    12, pal.muted, FontWeight.Medium, maxLines = 1
                )
            }
            RoundBtn("prev", 38, m.has) { MediaBridge.act("prev") }
            Spacer(Modifier.width(4.dp))
            Box(
                Modifier.size(46.dp).clip(CircleShape).background(pal.ink)
                    .plainClick { if (m.has) MediaBridge.act("toggle") },
                contentAlignment = Alignment.Center
            ) { Ico(if (m.playing) "pause" else "play", 22.dp, if (pal.dark) pal.onAcc else Color.White) }
            Spacer(Modifier.width(4.dp))
            RoundBtn("next", 38, m.has) { MediaBridge.act("next") }
        }
        // thin progress line along the bottom
        val frac = if (m.durMs > 0) (m.now().toFloat() / m.durMs).coerceIn(0f, 1f) else 0f
        if (tick >= 0) {
            Box(Modifier.fillMaxWidth().padding(horizontal = 18.dp).padding(bottom = 10.dp).height(3.dp).clip(CircleShape).background(pal.track)) {
                Box(Modifier.fillMaxWidth(frac).height(3.dp).background(if (pc) pal.violet else pal.mint))
            }
        }
    }
}

@Composable
private fun RoundBtn(kind: String, size: Int, enabled: Boolean, onClick: () -> Unit) {
    val pal = LocalPal.current
    Box(
        Modifier.size(size.dp).clip(CircleShape).plainClick { if (enabled) onClick() },
        contentAlignment = Alignment.Center
    ) { Ico(kind, (size * 0.52f).dp, pal.ink.copy(alpha = if (enabled) 1f else 0.35f)) }
}

/**
 * The big Media player: the background blurs, and a glass panel shows the cover, the title,
 * the time bar, the buttons and the volume. Same idea on the PC.
 */
@Composable
fun PlayerSheet(visible: Boolean, onClose: () -> Unit) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(200)),
        exit = fadeOut(tween(160))
    ) {
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = if (pal.dark) 0.62f else 0.42f)).plainClick { onClose() },
            contentAlignment = Alignment.Center
        ) {}
    }
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(220)) + scaleIn(tween(260), initialScale = 0.93f) + slideInVertically(tween(260)) { it / 14 },
        exit = fadeOut(tween(160)) + scaleOut(tween(180), targetScale = 0.95f) + slideOutVertically(tween(180)) { it / 14 }
    ) {
        Box(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp), contentAlignment = Alignment.Center) {
            PanelBody(onClose, ctx)
        }
    }
}

@Composable
private fun PanelBody(onClose: () -> Unit, ctx: Context) {
    val pal = LocalPal.current
    rememberNowMs()
    val src = Hub.mediaSource()
    val pc = src == 2
    val m = Hub.shownMedia()
    var seekDrag by remember { mutableStateOf<Float?>(null) }
    var volDrag by remember { mutableStateOf<Float?>(null) }
    val shape = RoundedCornerShape(40.dp)

    Column(
        Modifier.fillMaxWidth()
            .background(if (pal.dark) Color(0xF2141225) else Color(0xF2F6F3FC), shape)
            .glass(shape, pal, strong = true).plainClick { }.padding(horizontal = 22.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.width(38.dp).height(4.dp).clip(CircleShape).background(pal.muted.copy(alpha = 0.5f)).plainClick { onClose() })
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            T("Media player", 18, weight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier.size(38.dp).glass(CircleShape, pal).plainClick {
                        // Auto -> this phone -> the PC -> Auto
                        Hub.mediaPick = when (Hub.mediaPick) { 0 -> 1; 1 -> 2; else -> 0 }
                        Hub.save()
                    },
                    contentAlignment = Alignment.Center
                ) { Ico(if (pc) "pc" else "phone", 20.dp, pal.ink) }
                T(if (Hub.mediaPick == 0) "Auto" else if (pc) "PC" else "Phone", 10, pal.muted, FontWeight.Medium)
            }
        }
        Spacer(Modifier.height(14.dp))
        BoxWithConstraints(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            val side = if (maxWidth * 0.72f > 250.dp) 250.dp else maxWidth * 0.72f
            Cover(m, side, 26.dp)
        }
        Spacer(Modifier.height(18.dp))
        T(if (m.has) m.title else "Nothing playing", 22, weight = FontWeight.Bold, align = TextAlign.Center, maxLines = 2, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(2.dp))
        T(
            if (m.has) (if (m.artist.isNotEmpty()) m.artist else sourceLine(m, pc))
            else if (!Hub.notifAccess && !pc) "Allow media access to see your music here" else "Start music in any app",
            15, pal.muted, FontWeight.Medium, align = TextAlign.Center, maxLines = 1, modifier = Modifier.fillMaxWidth()
        )
        if (m.has && m.artist.isNotEmpty()) T(sourceLine(m, pc), 12, pal.muted.copy(alpha = 0.8f), FontWeight.Medium, align = TextAlign.Center, maxLines = 1, modifier = Modifier.fillMaxWidth())
        if (!m.has && !Hub.notifAccess && !pc) {
            Spacer(Modifier.height(10.dp))
            GPill("Allow media access") { openNotifAccess(ctx) }
        }

        Spacer(Modifier.height(10.dp))
        val dur = m.durMs
        val posFrac = if (dur > 0) (m.now().toFloat() / dur).coerceIn(0f, 1f) else 0f
        GSlider(seekDrag ?: posFrac, 1f, if (pc) pal.violet else pal.mint, enabled = dur > 0,
            onDone = {
                val f = seekDrag
                if (f != null && dur > 0) MediaBridge.act("seek", (f * dur).toLong())
                seekDrag = null
            }) { seekDrag = it }
        Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp)) {
            T(mmss(if (seekDrag != null) (seekDrag!! * dur).toLong() else m.now()), 13, pal.muted, FontWeight.Medium, Modifier.weight(1f))
            T(if (dur > 0) mmss(dur) else "--:--", 13, pal.muted, FontWeight.Medium)
        }

        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            // the add / like button shows only when the playing app really has one
            Box(Modifier.size(46.dp), contentAlignment = Alignment.Center) {
                if (!pc && m.canLike) {
                    Box(Modifier.size(46.dp).clip(CircleShape).plainClick { MediaBridge.act("like") }, contentAlignment = Alignment.Center) {
                        Ico(if (m.liked) "check" else "plus", 28.dp, if (m.liked) pal.mintText else pal.ink)
                    }
                }
            }
            RoundBtn("prev", 52, m.has) { MediaBridge.act("prev") }
            Box(
                Modifier.size(74.dp).clip(CircleShape).background(pal.ink).plainClick { if (m.has) MediaBridge.act("toggle") },
                contentAlignment = Alignment.Center
            ) { Ico(if (m.playing) "pause" else "play", 34.dp, if (pal.dark) pal.onAcc else Color.White) }
            RoundBtn("next", 52, m.has) { MediaBridge.act("next") }
            Spacer(Modifier.size(46.dp))
        }

        Spacer(Modifier.height(10.dp))
        val vol = if (pc) (if (m.vol >= 0) m.vol else 50) else Hub.phoneVol
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Ico("spklow", 22.dp, pal.muted)
            Box(Modifier.weight(1f).padding(horizontal = 6.dp)) {
                GSlider(volDrag ?: (vol / 100f), 1f, pal.ink.copy(alpha = 0.75f), onDone = { volDrag = null }) {
                    volDrag = it
                    MediaBridge.act("vol", (it * 100).toLong())
                    if (!pc) Hub.phoneVol = (it * 100).toInt()
                }
            }
            Ico("spk", 22.dp, pal.muted)
        }
        Spacer(Modifier.height(2.dp))
        Box(Modifier.size(34.dp).plainClick { onClose() }, contentAlignment = Alignment.Center) { Ico("down", 22.dp, pal.muted) }
    }
}

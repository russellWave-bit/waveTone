package com.breadwinner.wavetone

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Splits the sound into 8 bands (deep bass up to treble) so the waves and bars can
 * follow what you actually hear. Feed it 48 kHz stereo 16-bit chunks.
 */
class BandAnalyzer {
    companion object {
        const val N = 1024
        val FREQ = floatArrayOf(60f, 120f, 240f, 480f, 960f, 1900f, 3800f, 7600f)
        // higher notes carry less energy in music, so lift them a little
        private val LIFT = floatArrayOf(1f, 1.2f, 1.6f, 2.2f, 3.2f, 4.5f, 6.5f, 10f)
    }

    private val ring = FloatArray(N)
    private var pos = 0
    private val hann = FloatArray(N) { (0.5 - 0.5 * cos(2.0 * PI * it / (N - 1))).toFloat() }
    private val coef = FloatArray(8) { (2.0 * cos(2.0 * PI * FREQ[it] / 48000.0)).toFloat() }
    private var ref = 0.02f

    /** 0..1 per band, already smoothed (quick up, slow down). Read from any thread. */
    val out = FloatArray(8)

    fun feed(b: ByteArray, n: Int) {
        val frames = n / 4
        var i = 0
        while (i < frames) {
            val o = i * 4
            val l = ((b[o].toInt() and 0xFF) or (b[o + 1].toInt() shl 8)).toShort().toInt()
            val r = ((b[o + 2].toInt() and 0xFF) or (b[o + 3].toInt() shl 8)).toShort().toInt()
            ring[pos] = (l + r) * (0.5f / 32768f)
            pos = (pos + 1) and (N - 1)
            i++
        }
        val amp = FloatArray(8)
        var top = 0f
        for (f in 0 until 8) {
            val c = coef[f]
            var s1 = 0f
            var s2 = 0f
            var k = 0
            while (k < N) {
                val x = ring[(pos + k) and (N - 1)] * hann[k]
                val s0 = x + c * s1 - s2
                s2 = s1
                s1 = s0
                k++
            }
            val p = max(0f, s1 * s1 + s2 * s2 - c * s1 * s2)
            val a = 4f * sqrt(p) / N * LIFT[f]
            amp[f] = a
            if (a > top) top = a
        }
        ref = max(ref * 0.9996f, top)
        val floor = 0.0025f
        for (f in 0 until 8) {
            val d = if (top < floor) 0f else min(1f, (amp[f] / max(ref, 0.03f)).pow(0.75f))
            out[f] = max(d, out[f] * 0.88f)
        }
    }

    fun clear() {
        for (f in 0 until 8) out[f] = 0f
        ref = 0.02f
        java.util.Arrays.fill(ring, 0f)
    }
}

package com.breadwinner.wavetone

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.abs
import kotlin.math.sin

/**
 * A small glass bubble that floats over other apps. Tap it to connect or disconnect,
 * drag it where you like. It needs "Display over other apps".
 */
class BubbleService : Service() {
    private var wm: WindowManager? = null
    private var bubble: BubbleView? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        MediaBridge.init(applicationContext)
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        val w = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm = w
        val size = (58 * resources.displayMetrics.density).toInt()
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = Hub.bubbleX
        lp.y = Hub.bubbleY
        val v = BubbleView(this, w, lp)
        try {
            w.addView(v, lp)
            bubble = v
        } catch (e: Exception) {
            Hub.logErr("Bubble: " + (e.message ?: e.javaClass.simpleName))
            stopSelf()
        }
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onDestroy() {
        bubble?.stopTicking()
        try { bubble?.let { wm?.removeView(it) } } catch (e: Exception) { }
        bubble = null
        super.onDestroy()
    }
}

private class BubbleView(
    private val ctx: Context,
    private val wm: WindowManager,
    private val lp: WindowManager.LayoutParams
) : View(ctx) {
    private val h = Handler(Looper.getMainLooper())
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = resources.displayMetrics.density
    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0
    private var moved = false
    private var running = true

    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            invalidate()
            h.postDelayed(this, 120)
        }
    }

    init { h.post(loop) }

    fun stopTicking() { running = false; h.removeCallbacksAndMessages(null) }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val r = w / 2f
        val state = when {
            Hub.connected -> 2
            Hub.running && Hub.everConnected -> 1
            Hub.running -> 1
            else -> 0
        }
        val ring = when (state) {
            2 -> Color.parseColor("#1FD2AE")
            1 -> Color.parseColor("#FFB347")
            else -> Color.parseColor("#9AA3C7")
        }
        // glass body
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(r * 0.7f, r * 0.55f, r * 1.3f, intArrayOf(Color.argb(235, 255, 255, 255), Color.argb(170, 226, 232, 255)), null, Shader.TileMode.CLAMP)
        c.drawCircle(r, r, r - 3 * d, p)
        p.shader = null
        // rim
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2.5f * d
        val pulse = if (state == 1) (0.55f + 0.45f * (0.5f + 0.5f * sin(SystemClock.uptimeMillis() / 260.0).toFloat())) else 1f
        p.color = Color.argb((255 * pulse).toInt(), Color.red(ring), Color.green(ring), Color.blue(ring))
        c.drawCircle(r, r, r - 3 * d, p)
        // three little sound bars
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#121830")
        val bw = 4.5f * d
        val gap = 3.5f * d
        val hs = floatArrayOf(10f * d, 18f * d, 12f * d)
        val total = bw * 3 + gap * 2
        var x = r - total / 2f
        for (i in 0 until 3) {
            val hh = if (state == 2) hs[i] * (0.8f + 0.2f * sin(SystemClock.uptimeMillis() / 180.0 + i).toFloat()) else hs[i] * 0.6f
            c.drawRoundRect(RectF(x, r - hh / 2f, x + bw, r + hh / 2f), bw / 2f, bw / 2f, p)
            x += bw + gap
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX; downY = e.rawY
                startX = lp.x; startY = lp.y
                moved = false
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downX
                val dy = e.rawY - downY
                if (abs(dx) > 8 * d || abs(dy) > 8 * d) moved = true
                if (moved) {
                    lp.x = (startX + dx).toInt()
                    lp.y = (startY + dy).toInt()
                    try { wm.updateViewLayout(this, lp) } catch (ex: Exception) { }
                }
            }
            MotionEvent.ACTION_UP -> {
                if (moved) {
                    val sw = resources.displayMetrics.widthPixels
                    lp.x = if (lp.x + width / 2 < sw / 2) 0 else sw - width
                    try { wm.updateViewLayout(this, lp) } catch (ex: Exception) { }
                    Hub.bubbleX = lp.x
                    Hub.bubbleY = lp.y
                    Hub.save()
                } else {
                    tapped()
                }
            }
        }
        return true
    }

    private fun tapped() {
        when {
            !Hub.running -> {
                val i = Intent(ctx, MainActivity::class.java).putExtra("autostart", true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { ctx.startActivity(i) } catch (ex: Exception) { }
            }
            Hub.connected -> Engine.disconnect()
            else -> Engine.requestConnect()
        }
        MediaBridge.pokeWidgets()
    }
}

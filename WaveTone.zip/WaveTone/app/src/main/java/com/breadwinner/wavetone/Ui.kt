package com.breadwinner.wavetone

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.sin
import kotlinx.coroutines.delay

// Indigo night with violet, mint (PC to phone) and rose (phone to PC).
val Bg = Color(0xFF0E0B1A)
val CardC = Color(0xFF191430)
val Track = Color(0xFF2B2450)
val TextC = Color(0xFFEFEAFF)
val Muted = Color(0xFF9F96C4)
val Acc = Color(0xFF8B6CF6)
val OnAcc = Color(0xFF0E0820)
val Mint = Color(0xFF5EEAD4)
val Rose = Color(0xFFFF7AB6)
val Warm = Color(0xFFFFB347)
val Good = Color(0xFF6FD3A0)

@Composable
fun T(text: String, size: Int = 13, color: Color = TextC, weight: FontWeight = FontWeight.Bold, modifier: Modifier = Modifier) {
    Text(text, color = color, fontSize = size.sp, fontWeight = weight, modifier = modifier)
}

@Composable
fun Card(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.fillMaxWidth().clip(RoundedCornerShape(topStart = 22.dp, topEnd = 8.dp, bottomEnd = 22.dp, bottomStart = 8.dp))
            .background(CardC).padding(16.dp),
        content = content
    )
}

@Composable
fun Pill(text: String, filled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(12.dp)).background(if (filled) Acc else Track)
            .clickable { onClick() }.padding(horizontal = 20.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) { T(text, 14, if (filled) OnAcc else TextC) }
}

@Composable
fun Seg(items: List<String>, sel: Int, onSel: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Track).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        items.forEachIndexed { i, s ->
            Box(
                Modifier.weight(1f).height(38.dp).clip(RoundedCornerShape(9.dp))
                    .background(if (i == sel) Acc else Color.Transparent).clickable { onSel(i) },
                contentAlignment = Alignment.Center
            ) { T(s, 12, if (i == sel) OnAcc else Muted) }
        }
    }
}

@Composable
fun ToggleRow(label: String, on: Boolean, tint: Color = Acc, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().height(48.dp), verticalAlignment = Alignment.CenterVertically) {
        T(label, 14, modifier = Modifier.weight(1f))
        Switch(checked = on, onCheckedChange = onChange, colors = SwitchDefaults.colors(checkedTrackColor = tint, checkedThumbColor = OnAcc, uncheckedTrackColor = Track))
    }
}

@Composable
fun VolSlider(label: String, value: Int, max: Int, tint: Color, onChange: (Int) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth()) {
            T(label, 13, modifier = Modifier.weight(1f))
            T("$value%", 13, tint)
        }
        Slider(
            value = value.toFloat(), onValueChange = { onChange(it.toInt()) }, valueRange = 0f..max.toFloat(),
            colors = SliderDefaults.colors(thumbColor = tint, activeTrackColor = tint, inactiveTrackColor = Track)
        )
    }
}

@Composable
fun rememberClock(): State<Float> {
    val t = remember { mutableStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { n ->
                if (last != 0L) t.value += ((n - last) / 1e9f).coerceAtMost(0.05f)
                last = n
            }
        }
    }
    return t
}

/** Sound bars that dance with the real sound level. [level] reads the live value each frame. */
@Composable
fun Bars(modifier: Modifier, tint: Color, level: () -> Float, count: Int = 24) {
    val t = rememberClock()
    Canvas(modifier) {
        val lv = level().coerceIn(0f, 1f)
        val gap = 4.dp.toPx()
        val bw = (size.width - gap * (count - 1)) / count
        for (i in 0 until count) {
            val wob = 0.5f + 0.5f * sin(t.value * 6f + i * 0.9f) * sin(t.value * 2.3f + i * 0.35f)
            val h = size.height * (0.08f + 0.92f * lv * (0.35f + 0.65f * abs(wob)))
            drawRoundRect(
                tint.copy(alpha = if (lv > 0.01f) 1f else 0.3f), Offset(i * (bw + gap), size.height - h),
                Size(bw, h), CornerRadius(bw / 2f)
            )
        }
    }
}

private val TABS = listOf("Sound", "Connect", "Health", "More")

@Composable
fun WaveToneApp(onStart: () -> Unit, onStop: () -> Unit) {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize().background(Bg)) {
        Box(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF2A1F5C), Color(0xFF181238), Bg)))) {
            Column(Modifier.statusBarsPadding().padding(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        T("WAVETONE", 11, Mint.copy(alpha = 0.85f))
                        T(TABS[tab], 26, TextC, FontWeight.ExtraBold)
                    }
                    val live = Hub.connected
                    Box(Modifier.clip(RoundedCornerShape(20.dp)).background(if (live) Mint else Color.White.copy(alpha = 0.12f)).padding(horizontal = 12.dp, vertical = 6.dp)) {
                        T(if (live) "CONNECTED" else if (Hub.running) "WAITING" else "OFF", 11, if (live) OnAcc else TextC)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth().height(40.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Bars(Modifier.weight(1f).height(40.dp), Mint, { Hub.playLevel }, 12)
                    Bars(Modifier.weight(1f).height(40.dp), Rose, { Hub.sendLevel }, 12)
                }
                Row(Modifier.fillMaxWidth().padding(top = 4.dp)) {
                    T("PC to phone", 10, Mint, modifier = Modifier.weight(1f))
                    T("Phone to PC", 10, Rose)
                }
            }
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            when (tab) {
                0 -> SoundTab()
                1 -> ConnectTab(onStart, onStop)
                2 -> HealthTab()
                else -> MoreTab()
            }
        }
        Row(Modifier.fillMaxWidth().background(CardC).navigationBarsPadding().padding(vertical = 6.dp)) {
            TABS.forEachIndexed { i, s ->
                Column(
                    Modifier.weight(1f).clickable { tab = i }.padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(Modifier.size(width = if (i == tab) 26.dp else 8.dp, height = 6.dp).clip(CircleShape).background(if (i == tab) Acc else Track))
                    Spacer(Modifier.height(5.dp))
                    T(s, 12, if (i == tab) TextC else Muted)
                }
            }
        }
    }
}

@Composable
fun SoundTab() {
    if (!Hub.connected) {
        Card {
            T("Not connected yet", 15, Warm)
            Spacer(Modifier.height(4.dp))
            T(
                if (Hub.running) "Open WaveTone on your PC. It finds this phone by itself."
                else "Go to the Connect tab and tap Start first.",
                13, Muted, FontWeight.Medium
            )
        }
    }
    Card {
        T("PC sound on this phone", 16, Mint)
        ToggleRow("Play it here", Hub.wantPc, Mint) { Hub.wantPc = it; Hub.changed() }
        val s = when {
            !Hub.connected -> "Waiting for the PC."
            !Hub.wantPc -> "Off."
            !Hub.peerAllow -> "The PC is not sharing its sound. Switch on Share on the PC."
            else -> "Playing from ${Hub.peerName}."
        }
        T(s, 12, Muted, FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        VolSlider("Volume", Hub.playVol, 150, Mint) { Hub.playVol = it; Hub.save() }
        Pill(if (Hub.playMute) "Unmute" else "Mute", false) { Hub.playMute = !Hub.playMute }
    }
    Card {
        T("Phone sound on the PC", 16, Rose)
        ToggleRow("Share this phone's sound", Hub.allowSend, Rose) { Hub.allowSend = it; Hub.changed() }
        val s = when {
            !Hub.connected -> "Waiting for the PC."
            !Hub.allowSend -> "Off."
            !Hub.peerWant -> "The PC is not listening. Switch on Play on the PC."
            else -> "Sending to ${Hub.peerName}."
        }
        T(s, 12, Muted, FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        VolSlider("Boost", Hub.sendGain, 200, Rose) { Hub.sendGain = it; Hub.save() }
        T("Some apps block capture of their sound. Banking and some streaming apps stay silent.", 12, Muted, FontWeight.Medium)
    }
    Card {
        T("Delay", 15)
        Spacer(Modifier.height(8.dp))
        val sel = when { Hub.latency <= 60 -> 0; Hub.latency >= 250 -> 2; else -> 1 }
        Seg(listOf("Low", "Balanced", "High"), sel) { Hub.latency = listOf(60, 120, 250)[it]; Hub.changed() }
        Spacer(Modifier.height(8.dp))
        T(
            when (sel) {
                0 -> "Fastest. Good for games and calls. A weak signal can crackle."
                2 -> "Slowest but smoothest. Best for music."
                else -> "A good balance."
            },
            12, Muted, FontWeight.Medium
        )
        T("Takes effect the next time sound starts.", 11, Muted, FontWeight.Medium)
    }
}

@Composable
fun ConnectTab(onStart: () -> Unit, onStop: () -> Unit) {
    val ctx = LocalContext.current
    var addr by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Hub.running, Hub.mode) {
        while (true) {
            addr = findIp(Hub.mode)?.first
            delay(2000)
        }
    }
    Card {
        T(if (Hub.running) "WaveTone is on" else "Ready", 18, weight = FontWeight.ExtraBold)
        Spacer(Modifier.height(4.dp))
        T(
            if (Hub.connected) "Connected to ${Hub.peerName}"
            else if (Hub.running) "Waiting for your PC..."
            else "Tap Start, accept the Android popup, then open WaveTone on your PC.",
            13, Muted, FontWeight.Medium
        )
        Spacer(Modifier.height(12.dp))
        if (Hub.running) Pill("Stop", false) { onStop() } else Pill("Start") { onStart() }
        if (Hub.hotspotMsg.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            T(Hub.hotspotMsg, 12, Warm, FontWeight.Medium)
        }
    }
    if (Hub.running) {
        Card {
            T("This phone's address", 14)
            Spacer(Modifier.height(6.dp))
            T("${addr ?: "Finding..."}:${Hub.port}", 24, Acc, FontWeight.ExtraBold)
            T("The PC app finds the phone by itself. If it does not, type this address into it.", 12, Muted, FontWeight.Medium)
        }
        if (Hub.mode == 1 && Hub.ssid.isNotEmpty()) {
            Card {
                T("Join this Wi-Fi on your PC first", 14)
                Spacer(Modifier.height(6.dp))
                T("Name: ${Hub.ssid}", 15, Mint)
                T("Password: ${Hub.pass}", 15, Mint)
            }
        }
    } else {
        Card {
            T("How should the PC connect?", 14)
            Spacer(Modifier.height(10.dp))
            Seg(listOf("My hotspot", "Auto hotspot", "USB cable"), Hub.mode) { Hub.mode = it; Hub.save() }
            Spacer(Modifier.height(8.dp))
            T(
                when (Hub.mode) {
                    0 -> "Turn on your phone's own hotspot, join it from the PC, then start."
                    1 -> "The app makes a private hotspot for you. It shows the name and password."
                    else -> "Plug the cable in and turn on USB tethering in the phone's settings."
                },
                12, Muted, FontWeight.Medium
            )
            if (Hub.mode != 1) {
                Spacer(Modifier.height(10.dp))
                Pill("Open hotspot settings", false) {
                    try {
                        ctx.startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e: Exception) {
                    }
                }
            }
        }
    }
}

@Composable
fun HealthTab() {
    Card {
        ToggleRow("Show latency and errors", Hub.showHealth) { Hub.showHealth = it; Hub.save() }
    }
    if (Hub.showHealth) {
        Card {
            T("Right now", 14)
            Spacer(Modifier.height(8.dp))
            Stat("Network round trip", "${Hub.rttMs} ms")
            Stat("Cushion in use", "${Hub.bufMs} ms")
            Stat("Estimated delay", "${Hub.rttMs / 2 + Hub.bufMs + 20} ms")
            Stat("Chunks dropped to catch up", "${Hub.dropped}")
            Stat("Sent to PC", "${Hub.sentKb} KB")
            Stat("Received from PC", "${Hub.recvKb} KB")
        }
        Card {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                T("Errors", 14, modifier = Modifier.weight(1f))
                Pill("Clear", false) { Hub.errors.clear() }
            }
            Spacer(Modifier.height(8.dp))
            if (Hub.errors.isEmpty()) {
                T("No errors. Good.", 13, Good, FontWeight.Medium)
            } else {
                for (e in Hub.errors.take(25)) T(e, 12, Warm, FontWeight.Medium, Modifier.padding(vertical = 2.dp))
            }
        }
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        T(label, 13, Muted, FontWeight.Medium, Modifier.weight(1f))
        T(value, 13)
    }
}

@Composable
fun MoreTab() {
    Card {
        T("Good to know", 15)
        Spacer(Modifier.height(6.dp))
        T("Both sides must agree. The phone plays the PC's sound only when the PC is sharing, and the PC hears the phone only when the phone is sharing and the PC is listening.", 13, Muted, FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        T("Android shows the capture popup each time you start. That is a safety rule.", 13, Muted, FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        T("The phone keeps playing its own sound too. Turn the phone's volume down if you only want the PC to play it.", 13, Muted, FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        T("If sound stops after a while, set this app's battery use to Unrestricted in Android settings.", 13, Muted, FontWeight.Medium)
    }
    Card {
        T("Coming next", 15)
        Spacer(Modifier.height(6.dp))
        T("Microphone to PC, pick which app to share, and a connection PIN.", 13, Muted, FontWeight.Medium)
        Spacer(Modifier.height(8.dp))
        T("WaveTone 1.0", 12, Muted, FontWeight.Medium)
    }
}

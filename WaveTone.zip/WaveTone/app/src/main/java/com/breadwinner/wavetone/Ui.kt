package com.breadwinner.wavetone

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.delay

private val TABS = listOf("Sound", "Connect", "Health", "More")

@Composable
fun WaveToneApp(onStart: () -> Unit, onStop: () -> Unit) {
    val dark = when (Hub.theme) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val pal = if (dark) DarkPal else LightPal
    CompositionLocalProvider(LocalPal provides pal) {
        var tab by remember { mutableStateOf(0) }
        var sheet by remember { mutableStateOf(false) }
        BackHandler(enabled = sheet) { sheet = false }
        val blurMod = if (sheet && Build.VERSION.SDK_INT >= 31) Modifier.blur(28.dp) else Modifier

        Box(Modifier.fillMaxSize().background(pal.wall[0])) {
            Box(Modifier.fillMaxSize().then(blurMod)) {
                Wall()
                Viz()
                Column(Modifier.fillMaxSize()) {
                    Header(tab)
                    Column(
                        Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 6.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        when (tab) {
                            0 -> SoundTab { sheet = true }
                            1 -> ConnectTab(onStart, onStop)
                            2 -> HealthTab()
                            else -> MoreTab()
                        }
                        Spacer(Modifier.height(96.dp))
                    }
                }
                // things fade away before they reach the tab bar, so nothing clashes with it
                Box(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(150.dp).background(
                        Brush.verticalGradient(listOf(Color.Transparent, pal.wall[1].copy(alpha = 0.9f), pal.wall[1]))
                    )
                )
                TabBar(tab, Modifier.align(Alignment.BottomCenter)) { tab = it }
            }
            PlayerSheet(sheet) { sheet = false }
        }
    }
}

@Composable
private fun Header(tab: Int) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(start = 22.dp, end = 18.dp, top = 12.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            T("WAVETONE", 11, pal.mintText, FontWeight.ExtraBold)
            T(TABS[tab], 36, weight = FontWeight.ExtraBold)
        }
        val (txt, dot) = when {
            Hub.connected -> "Connected" to pal.mint
            Hub.running -> (if (Hub.everConnected) "Reconnecting" else "Waiting") to pal.amber
            else -> "Off" to pal.muted
        }
        Row(
            Modifier.glass(RoundedCornerShape(50), pal).padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(9.dp).clip(CircleShape).background(dot))
            Spacer(Modifier.size(7.dp))
            T(txt, 13)
        }
    }
}

@Composable
private fun TabBar(tab: Int, modifier: Modifier, onTab: (Int) -> Unit) {
    val pal = LocalPal.current
    Row(
        modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 22.dp, vertical = 12.dp)
            .background(if (pal.dark) Color(0xF2181B38) else Color(0xF2F4F2FC), RoundedCornerShape(50))
            .glass(RoundedCornerShape(50), pal, strong = true).padding(5.dp)
    ) {
        TABS.forEachIndexed { i, s ->
            Box(
                Modifier.weight(1f).height(46.dp).clip(RoundedCornerShape(50))
                    .background(if (i == tab) pal.selFill else Color.Transparent).plainClick { onTab(i) },
                contentAlignment = Alignment.Center
            ) { T(s, 14, if (i == tab) pal.ink else pal.muted, if (i == tab) FontWeight.Bold else FontWeight.SemiBold) }
        }
    }
}

// ---------------------------------------------------------------- Sound

@Composable
fun SoundTab(openPlayer: () -> Unit) {
    val pal = LocalPal.current
    if (!Hub.connected) {
        GCard {
            T(if (Hub.running && Hub.everConnected) "Reconnecting..." else "Not connected yet", 15, pal.amber, FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            T(
                if (Hub.running) "Open WaveTone on your PC. It joins by itself."
                else "Go to the Connect tab and tap Start first.",
                13, pal.muted, FontWeight.Medium
            )
        }
    }

    MiniPlayer(openPlayer)

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        DirCard("PC to phone", Hub.wantPc, pal.mint, Modifier.weight(1f),
            when {
                !Hub.connected -> "Waiting"
                !Hub.wantPc -> "Off"
                !Hub.peerAllow -> "PC not sharing"
                else -> "Playing"
            }) { Hub.wantPc = it; Hub.changed() }
        DirCard("Phone to PC", Hub.allowSend, pal.rose, Modifier.weight(1f),
            when {
                !Hub.connected -> "Waiting"
                !Hub.allowSend -> "Off"
                !Hub.peerWant -> "PC not listening"
                else -> "Sending"
            }) { Hub.allowSend = it; Hub.changed() }
    }

    GCard {
        VolRow("PC sound volume on this phone", Hub.playVol, 150, pal.mint, pal.mintText) { Hub.playVol = it; Hub.save() }
        Row(Modifier.fillMaxWidth().padding(top = 2.dp, bottom = 6.dp)) {
            GPill(if (Hub.playMute) "Unmute" else "Mute", false) { Hub.playMute = !Hub.playMute }
        }
        VolRow("Phone sound boost", Hub.sendGain, 200, pal.rose, pal.roseText) { Hub.sendGain = it; Hub.save() }
        Spacer(Modifier.height(4.dp))
        T("Some apps block capture of their sound. Banking and some streaming apps stay silent.", 12, pal.muted, FontWeight.Medium)
    }

    GCard {
        T("Movie sound timing", 16, weight = FontWeight.Bold)
        Spacer(Modifier.height(2.dp))
        T("If the voices come after the lips, tap Earlier. If they come before, tap Later.", 12, pal.muted, FontWeight.Medium)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GPill("Earlier", false, Modifier.weight(1f)) { Hub.nudge = (Hub.nudge - 20).coerceAtLeast(-100); Hub.save() }
            GPill("Later", false, Modifier.weight(1f)) { Hub.nudge = (Hub.nudge + 20).coerceAtMost(300); Hub.save() }
        }
        Spacer(Modifier.height(10.dp))
        T(
            if (Hub.nudge == 0) "Sound is on time"
            else if (Hub.nudge < 0) "Sound is ${-Hub.nudge} ms earlier" else "Sound is ${Hub.nudge} ms later",
            15, if (Hub.nudge == 0) pal.mintText else pal.ink, FontWeight.Bold, align = TextAlign.Center, modifier = Modifier.fillMaxWidth()
        )
        if (Hub.nudge != 0) {
            Spacer(Modifier.height(8.dp))
            GPill("Reset", true, Modifier.fillMaxWidth()) { Hub.nudge = 0; Hub.save() }
        }
        Spacer(Modifier.height(6.dp))
        T("Each tap moves the sound 20 ms. Going earlier has a limit, or the sound would crackle.", 11, pal.muted, FontWeight.Medium)
    }

    GCard {
        T("Delay", 16, weight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        GSeg(listOf("Smart", "Fast", "Steady"), Hub.delayMode) { Hub.delayMode = it; Hub.save(); Engine.cushion.mode = it; Engine.cushion.reset() }
        Spacer(Modifier.height(8.dp))
        T(
            when (Hub.delayMode) {
                1 -> "Always small. Good for games and calls. A weak signal can crackle."
                2 -> "Always big and smooth. Best for music when you do not watch anything."
                else -> "Adjusts itself: small when the Wi-Fi is steady, bigger for a moment when it is not."
            },
            12, pal.muted, FontWeight.Medium
        )
        if (Hub.connected && Hub.wantPc && Hub.peerAllow) {
            Spacer(Modifier.height(6.dp))
            T("Cushion right now: ${Hub.targetMs} ms", 12, pal.mintText, FontWeight.Bold)
        }
    }

    GCard {
        T("Look", 16, weight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        GSeg(listOf("Bars", "Waves"), Hub.viz) { Hub.viz = it; Hub.save() }
    }
}

@Composable
private fun DirCard(title: String, on: Boolean, tint: Color, modifier: Modifier, status: String, onChange: (Boolean) -> Unit) {
    val pal = LocalPal.current
    Column(modifier.glass(RoundedCornerShape(26.dp), pal).padding(horizontal = 14.dp, vertical = 14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                T(title, 14, weight = FontWeight.Bold, maxLines = 1)
                T(status, 11, if (on) (if (tint == pal.mint) pal.mintText else pal.roseText) else pal.muted, FontWeight.Medium, maxLines = 1)
            }
        }
        Spacer(Modifier.height(10.dp))
        GSwitch(on, tint, onChange)
    }
}

// ---------------------------------------------------------------- Connect

@Composable
fun ConnectTab(onStart: () -> Unit, onStop: () -> Unit) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    var addr by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Hub.running, Hub.mode) {
        while (true) {
            addr = findIp(Hub.mode)?.first
            delay(2000)
        }
    }
    GCard {
        T(if (Hub.running) "WaveTone is on" else "Ready", 20, weight = FontWeight.ExtraBold)
        Spacer(Modifier.height(4.dp))
        T(
            if (Hub.connected) "Connected to ${Hub.peerName}"
            else if (Hub.running && Hub.everConnected) "Link dropped. Reconnecting by itself..."
            else if (Hub.running) "Waiting for your PC..."
            else "Tap Start, accept the Android popup, then open WaveTone on your PC.",
            13, pal.muted, FontWeight.Medium
        )
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (Hub.running) GPill("Stop", false) { onStop() } else GPill("Start") { onStart() }
            if (Hub.running) {
                if (Hub.connected) GPill("Disconnect", false) { Engine.disconnect() }
                else GPill("Connect") { Engine.requestConnect() }
            }
        }
        if (Hub.hotspotMsg.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            T(Hub.hotspotMsg, 12, pal.amber, FontWeight.Medium)
        }
    }
    if (Hub.running) {
        GCard {
            T("This phone's address", 14, weight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            T("${addr ?: "Finding..."}:${Hub.port}", 24, pal.violet, FontWeight.ExtraBold)
            T("The PC app finds the phone by itself. If it does not, type this address into it.", 12, pal.muted, FontWeight.Medium)
        }
        if (Hub.mode == 1 && Hub.ssid.isNotEmpty()) {
            GCard {
                T("Join this Wi-Fi on your PC first", 14, weight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                T("Name: ${Hub.ssid}", 15, pal.mintText, FontWeight.Bold)
                T("Password: ${Hub.pass}", 15, pal.mintText, FontWeight.Bold)
            }
        }
    } else {
        GCard {
            T("How should the PC connect?", 14, weight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            GSeg(listOf("My hotspot", "Auto hotspot", "USB cable"), Hub.mode) { Hub.mode = it; Hub.save() }
            Spacer(Modifier.height(8.dp))
            T(
                when (Hub.mode) {
                    0 -> "Turn on your phone's own hotspot, join it from the PC, then start."
                    1 -> "The app makes a private hotspot for you. It shows the name and password."
                    else -> "Plug the cable in and turn on USB tethering in the phone's settings."
                },
                12, pal.muted, FontWeight.Medium
            )
            if (Hub.mode != 1) {
                Spacer(Modifier.height(10.dp))
                GPill("Open hotspot settings", false) {
                    try {
                        ctx.startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e: Exception) {
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Health

@Composable
fun HealthTab() {
    val pal = LocalPal.current
    GCard {
        GToggleRow("Show latency and errors", Hub.showHealth, pal.mint) { Hub.showHealth = it; Hub.save() }
    }
    if (Hub.showHealth) {
        GCard {
            T("Right now", 15, weight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Stat("Network round trip", "${Hub.rttMs} ms")
            Stat("Cushion goal (smart)", "${Hub.targetMs} ms")
            Stat("Sound waiting in line", "${Hub.bufMs} ms")
            Stat("Estimated delay", "${Hub.rttMs / 2 + Hub.bufMs + 20} ms")
            Stat("Hiccups it learned from", "${Hub.underruns}")
            Stat("Chunks dropped to catch up", "${Hub.dropped}")
            Stat("Sent to PC", "${Hub.sentKb} KB")
            Stat("Received from PC", "${Hub.recvKb} KB")
        }
        GCard {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                T("Errors", 15, weight = FontWeight.Bold, modifier = Modifier.weight(1f))
                GPill("Clear", false) { Hub.errors.clear() }
            }
            Spacer(Modifier.height(8.dp))
            if (Hub.errors.isEmpty()) {
                T("No errors. Good.", 13, pal.good, FontWeight.Medium)
            } else {
                for (e in Hub.errors.take(25)) T(e, 12, pal.amber, FontWeight.Medium, Modifier.padding(vertical = 2.dp))
            }
        }
    }
}

@Composable
private fun Stat(label: String, value: String) {
    val pal = LocalPal.current
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        T(label, 13, pal.muted, FontWeight.Medium, Modifier.weight(1f))
        T(value, 13)
    }
}

// ---------------------------------------------------------------- More

private fun notifAccessOn(c: Context): Boolean =
    NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.packageName)

@Composable
fun MoreTab() {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    var access by remember { mutableStateOf(notifAccessOn(ctx)) }
    var overlay by remember { mutableStateOf(Settings.canDrawOverlays(ctx)) }
    LaunchedEffect(Unit) {
        while (true) {
            access = notifAccessOn(ctx)
            overlay = Settings.canDrawOverlays(ctx)
            Hub.notifAccess = access
            delay(1000)
        }
    }

    GCard {
        T("Colour", 16, weight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        GSeg(listOf("Like my phone", "Light", "Dark"), Hub.theme) { Hub.theme = it; Hub.save() }
    }

    GCard {
        T("Media access", 16, weight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        T(
            if (access) "On. WaveTone can see which song plays on this phone and press its buttons."
            else "Off. Switch it on so the player can show your music and use its buttons.",
            13, pal.muted, FontWeight.Medium
        )
        Spacer(Modifier.height(10.dp))
        GPill(if (access) "Open settings" else "Allow media access", !access) { openNotifAccess(ctx) }
        Spacer(Modifier.height(6.dp))
        T("In the list, tap WaveTone and switch it on. WaveTone does not read or keep your notifications.", 11, pal.muted, FontWeight.Medium)
    }

    GCard {
        GToggleRow("Floating connect bubble", Hub.bubbleOn, pal.mint) {
            if (it && !overlay) {
                try {
                    ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                }
            } else {
                Hub.bubbleOn = it
                Hub.save()
                if (it) ctx.startService(Intent(ctx, BubbleService::class.java))
                else ctx.stopService(Intent(ctx, BubbleService::class.java))
            }
        }
        T(
            if (!overlay) "Needs \"Display over other apps\". Tap the switch, then allow WaveTone, then come back and tap the switch again."
            else "A small bubble over other apps. Tap it to connect or disconnect. Drag it anywhere.",
            12, pal.muted, FontWeight.Medium
        )
    }

    GCard {
        T("Home-screen widgets", 16, weight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        T("Press and hold an empty spot on your home screen, tap Widgets, find WaveTone, and drag one out: Now playing, Sound switches, or Mini status.", 13, pal.muted, FontWeight.Medium)
    }

    GCard {
        T("Good to know", 16, weight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        T("Both sides must agree. The phone plays the PC's sound only when the PC is sharing, and the PC hears the phone only when the phone is sharing and the PC is listening.", 13, pal.muted, FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        T("Android shows the capture popup each time you start. That is a safety rule.", 13, pal.muted, FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        T("If the link drops, the PC joins again by itself. Disconnect on purpose and it stays off until you connect.", 13, pal.muted, FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        T("If sound stops after a while, set this app's battery use to Unrestricted in Android settings.", 13, pal.muted, FontWeight.Medium)
        Spacer(Modifier.height(8.dp))
        T("WaveTone 2.0", 12, pal.muted, FontWeight.Medium)
    }
}

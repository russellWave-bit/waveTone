package com.breadwinner.wavetone

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Colours for one look. The glass is a see-through tint with a bright rim. */
class Pal(
    val dark: Boolean,
    val ink: Color,
    val muted: Color,
    val mint: Color,
    val mintText: Color,
    val rose: Color,
    val roseText: Color,
    val violet: Color,
    val amber: Color,
    val good: Color,
    val wall: List<Color>,
    val glassTop: Color,
    val glassBot: Color,
    val rimA: Color,
    val rimB: Color,
    val track: Color,
    val onAcc: Color,
    val selFill: Color
)

val LightPal = Pal(
    dark = false,
    ink = Color(0xFF121830), muted = Color(0xFF5A6285),
    mint = Color(0xFF1FD2AE), mintText = Color(0xFF0B8F78),
    rose = Color(0xFFFF5FA2), roseText = Color(0xFFD42A78),
    violet = Color(0xFF8C6BFF), amber = Color(0xFFF59E0B), good = Color(0xFF0B8F78),
    wall = listOf(Color(0xFFDBE7FF), Color(0xFFF6E3F6), Color(0xFFD6F6EC)),
    glassTop = Color(0xA8FFFFFF), glassBot = Color(0x8FFFFFFF),
    rimA = Color(0xE6FFFFFF), rimB = Color(0x40FFFFFF),
    track = Color(0x33121830), onAcc = Color(0xFF121830), selFill = Color(0xC7FFFFFF)
)

val DarkPal = Pal(
    dark = true,
    ink = Color(0xFFF2F4FF), muted = Color(0xFFA9B0D6),
    mint = Color(0xFF3BE3C0), mintText = Color(0xFF3BE3C0),
    rose = Color(0xFFFF6FAE), roseText = Color(0xFFFF6FAE),
    violet = Color(0xFFA58BFF), amber = Color(0xFFFFB347), good = Color(0xFF6FD3A0),
    wall = listOf(Color(0xFF0A0C1F), Color(0xFF150B2E), Color(0xFF07131C)),
    glassTop = Color(0xA6343A68), glassBot = Color(0x9A232850),
    rimA = Color(0x66FFFFFF), rimB = Color(0x1AFFFFFF),
    track = Color(0x40FFFFFF), onAcc = Color(0xFF0A0C1F), selFill = Color(0x38FFFFFF)
)

val LocalPal = staticCompositionLocalOf { LightPal }

/** The see-through glass: tinted body, a bright corner highlight and a rim that catches the light. */
fun Modifier.glass(shape: Shape, pal: Pal, strong: Boolean = false): Modifier =
    this.clip(shape)
        .drawBehind {
            val k = if (strong) 1.35f else 1f
            drawRect(
                Brush.verticalGradient(
                    listOf(pal.glassTop.copy(alpha = (pal.glassTop.alpha * k).coerceAtMost(1f)), pal.glassBot.copy(alpha = (pal.glassBot.alpha * k).coerceAtMost(1f)))
                )
            )
            drawRect(
                Brush.radialGradient(
                    listOf(Color.White.copy(alpha = if (pal.dark) 0.14f else 0.38f), Color.Transparent),
                    center = Offset(size.width * 0.12f, 0f), radius = size.width * 0.8f
                )
            )
            drawRect(
                Brush.radialGradient(
                    listOf(Color.Transparent, Color.Black.copy(alpha = if (pal.dark) 0.18f else 0.04f)),
                    center = Offset(size.width * 0.5f, size.height * 0.5f), radius = size.maxDimension * 0.8f
                )
            )
        }
        .border(
            1.2.dp,
            Brush.linearGradient(listOf(pal.rimA, pal.rimB, pal.rimA.copy(alpha = pal.rimA.alpha * 0.55f))),
            shape
        )

@Composable
fun rememberClock(): State<Float> {
    val t = remember { mutableStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { n ->
                if (last != 0L) t.value += ((n - last) / 1e9f).coerceAtMost(0.05f)
                last = n
            }
        }
    }
    return t
}

@Composable
fun T(
    text: String, size: Int = 14, color: Color = Color.Unspecified, weight: FontWeight = FontWeight.SemiBold,
    modifier: Modifier = Modifier, align: TextAlign? = null, maxLines: Int = Int.MAX_VALUE
) {
    val pal = LocalPal.current
    Text(
        text, color = if (color == Color.Unspecified) pal.ink else color, fontSize = size.sp, fontWeight = weight,
        modifier = modifier, textAlign = align, maxLines = maxLines,
        overflow = if (maxLines == Int.MAX_VALUE) TextOverflow.Clip else TextOverflow.Ellipsis
    )
}

// ---------- the room behind the glass ----------

@Composable
fun Wall(modifier: Modifier = Modifier) {
    val pal = LocalPal.current
    Canvas(modifier.fillMaxSize()) {
        drawRect(Brush.linearGradient(pal.wall, start = Offset(0f, 0f), end = Offset(size.width, size.height)))
        val a = if (pal.dark) 0.5f else 0.55f
        fun bloom(c: Color, cx: Float, cy: Float, r: Float) {
            drawCircle(Brush.radialGradient(listOf(c.copy(alpha = a), Color.Transparent), center = Offset(cx * size.width, cy * size.height), radius = r * size.width), r * size.width, Offset(cx * size.width, cy * size.height))
        }
        bloom(pal.violet, 0.1f, 0.08f, 0.7f)
        bloom(pal.rose, 0.95f, 0.38f, 0.6f)
        bloom(pal.mint, 0.05f, 0.85f, 0.7f)
        bloom(if (pal.dark) pal.violet else pal.amber, 0.9f, 0.95f, 0.5f)
    }
}

/** Layered waves (or bars) that move with the sound. Mint = PC to phone, rose = phone to PC. */
@Composable
fun Viz(modifier: Modifier = Modifier) {
    val pal = LocalPal.current
    val t = rememberClock()
    // phases keep running, faster when the sound is louder, so the motion feels tied to the music
    val ph = remember { FloatArray(8) }
    val sm = remember { FloatArray(16) }     // smoothed bass/mid/high for play (0..2) and send (3..5)
    val peaks = remember { FloatArray(32) }
    val last = remember { FloatArray(1) }
    Canvas(modifier.fillMaxSize()) {
        val tt = t.value
        val dt = if (last[0] == 0f) 0.016f else (tt - last[0]).coerceIn(0f, 0.05f)
        last[0] = tt
        val pb = Hub.playBands.out
        val sb = Hub.sendBands.out
        fun grp(b: FloatArray, a: Int, z: Int): Float { var m = 0f; for (i in a..z) m += b[i]; return m / (z - a + 1) }
        val target = floatArrayOf(
            grp(pb, 0, 1), grp(pb, 2, 4), grp(pb, 5, 7),
            grp(sb, 0, 1), grp(sb, 2, 4), grp(sb, 5, 7)
        )
        for (i in 0 until 6) sm[i] += (target[i] - sm[i]) * (if (target[i] > sm[i]) 0.45f else 0.12f)
        val total = (sm[0] + sm[1] + sm[2] + sm[3] + sm[4] + sm[5]) / 6f
        ph[0] += dt * (0.5f + 1.2f * total)
        ph[1] += dt * (0.9f + 2.4f * (sm[0] + sm[1]))
        ph[2] += dt * (1.4f + 3.2f * (sm[1] + sm[2]))
        ph[3] += dt * (2.2f + 5.0f * sm[2])
        ph[4] += dt * (1.0f + 2.4f * (sm[3] + sm[4]))
        ph[5] += dt * (1.5f + 3.2f * (sm[4] + sm[5]))
        ph[6] += dt * (2.4f + 5.0f * sm[5])
        if (Hub.viz == 1) {
            // calm violet swell at the back
            wave(pal.violet, 0.50f, 14.dp.toPx() + 22.dp.toPx() * total, 0.7f, ph[0], 0f, 0.34f, 1f)
            // PC to phone: deep, middle and bright layers
            wave(pal.mint, 0.58f, 8.dp.toPx() + 64.dp.toPx() * sm[0], 0.8f, ph[1], 1.1f, 0.42f, 1f)
            wave(pal.mint, 0.64f, 6.dp.toPx() + 46.dp.toPx() * sm[1], 1.7f, ph[2], 2.3f, 0.5f, 1f)
            wave(pal.mint, 0.70f, 3.dp.toPx() + 28.dp.toPx() * sm[2], 3.6f, ph[3], 0.4f, 0.55f, 1f)
            // phone to PC
            wave(pal.rose, 0.63f, 8.dp.toPx() + 64.dp.toPx() * sm[3], 0.9f, ph[4], 3.0f, 0.38f, 1f)
            wave(pal.rose, 0.70f, 6.dp.toPx() + 46.dp.toPx() * sm[4], 1.9f, ph[5], 1.6f, 0.46f, 1f)
            wave(pal.rose, 0.76f, 3.dp.toPx() + 28.dp.toPx() * sm[5], 4.0f, ph[6], 5.0f, 0.5f, 1f)
            // a soft white sheen on top
            wave(Color.White, 0.80f, 8.dp.toPx() + 10.dp.toPx() * total, 1.4f, ph[0] * 1.3f, 0.6f, if (pal.dark) 0.12f else 0.4f, 0.6f)
        } else {
            val count = 16
            val gap = 4.dp.toPx()
            val half = size.width / 2f
            val bw = (half - gap * (count + 1)) / count
            for (side in 0..1) {
                val b = if (side == 0) pb else sb
                val c = if (side == 0) pal.mint else pal.rose
                val x0 = if (side == 0) 0f else half
                for (i in 0 until count) {
                    val pos = i / (count - 1f) * 7f
                    val lo = pos.toInt().coerceIn(0, 6)
                    val fr = pos - lo
                    val lv = b[lo] * (1f - fr) + b[lo + 1] * fr
                    val hh = size.height * 0.30f * (0.03f + 0.97f * lv)
                    val pi = side * 16 + i
                    peaks[pi] = max(hh, peaks[pi] - size.height * 0.004f)
                    val x = x0 + gap + i * (bw + gap)
                    val base = size.height * 0.8f
                    drawRoundRect(
                        Brush.verticalGradient(listOf(c.copy(alpha = 0.85f), c.copy(alpha = 0.3f)), startY = base - hh, endY = base),
                        Offset(x, base - hh), Size(bw, hh), CornerRadius(bw / 2f)
                    )
                    // the little cap that floats down after each beat
                    drawRoundRect(
                        c.copy(alpha = if (lv > 0.02f) 0.9f else 0.3f),
                        Offset(x, base - peaks[pi] - bw * 1.4f), Size(bw, bw * 0.7f), CornerRadius(bw / 2f)
                    )
                }
            }
        }
    }
}

private fun DrawScope.wave(c: Color, base: Float, amp: Float, freq: Float, ph: Float, off: Float, alpha: Float, line: Float) {
    val w = size.width
    val y0 = size.height * base
    val fill = Path()
    val top = Path()
    fill.moveTo(0f, size.height)
    var x = 0f
    val step = 8f
    var first = true
    while (x <= w + step) {
        val u = x / w
        // three stacked sine parts make the line intricate instead of a plain ripple
        val y = y0 + amp * (
            sin(u * 6.2832f * freq + ph * 2.2f + off) * 0.58f +
            sin(u * 6.2832f * freq * 1.9f - ph * 1.5f + off * 1.7f) * 0.27f +
            sin(u * 6.2832f * freq * 3.4f + ph * 2.9f + off * 0.6f) * 0.15f
        )
        fill.lineTo(x, y)
        if (first) { top.moveTo(x, y); first = false } else top.lineTo(x, y)
        x += step
    }
    fill.lineTo(w, size.height)
    fill.close()
    drawPath(fill, Brush.verticalGradient(listOf(c.copy(alpha = alpha), c.copy(alpha = alpha * 0.22f)), startY = y0 - amp, endY = size.height))
    drawPath(top, c.copy(alpha = min(1f, alpha * 1.6f) * line), style = Stroke(width = 1.4.dp.toPx()))
}

// ---------- icons drawn in code ----------

@Composable
fun Ico(kind: String, size: Dp, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val s = this.size.width / 24f
        fun poly(vararg pts: Float, closed: Boolean = true) {
            val p = Path()
            p.moveTo(pts[0] * s, pts[1] * s)
            var i = 2
            while (i < pts.size) { p.lineTo(pts[i] * s, pts[i + 1] * s); i += 2 }
            if (closed) p.close()
            drawPath(p, color)
        }
        val st = Stroke(width = 2f * s, cap = StrokeCap.Round)
        when (kind) {
            "play" -> poly(8f, 5f, 19f, 12f, 8f, 19f)
            "pause" -> { poly(7f, 5f, 11f, 5f, 11f, 19f, 7f, 19f); poly(13f, 5f, 17f, 5f, 17f, 19f, 13f, 19f) }
            "next" -> { poly(6f, 5f, 15f, 12f, 6f, 19f); poly(16f, 5f, 19f, 5f, 19f, 19f, 16f, 19f) }
            "prev" -> { poly(18f, 5f, 9f, 12f, 18f, 19f); poly(8f, 5f, 5f, 5f, 5f, 19f, 8f, 19f) }
            "plus" -> {
                drawCircle(color, 10f * s, Offset(12f * s, 12f * s), style = st)
                drawLine(color, Offset(12f * s, 7.5f * s), Offset(12f * s, 16.5f * s), 2f * s, StrokeCap.Round)
                drawLine(color, Offset(7.5f * s, 12f * s), Offset(16.5f * s, 12f * s), 2f * s, StrokeCap.Round)
            }
            "check" -> {
                drawCircle(color, 10f * s, Offset(12f * s, 12f * s), style = st)
                val p = Path()
                p.moveTo(7.5f * s, 12.5f * s); p.lineTo(10.7f * s, 15.7f * s); p.lineTo(16.5f * s, 9f * s)
                drawPath(p, color, style = st)
            }
            "spk", "spklow" -> {
                poly(3f, 9f, 7f, 9f, 12f, 5f, 12f, 19f, 7f, 15f, 3f, 15f)
                val a = Path()
                a.moveTo(15.5f * s, 9f * s); a.cubicTo(17.5f * s, 11f * s, 17.5f * s, 13f * s, 15.5f * s, 15f * s)
                drawPath(a, color, style = st)
                if (kind == "spk") {
                    val b = Path()
                    b.moveTo(18.5f * s, 6f * s); b.cubicTo(22.5f * s, 10f * s, 22.5f * s, 14f * s, 18.5f * s, 18f * s)
                    drawPath(b, color, style = st)
                }
            }
            "pc" -> {
                drawRoundRect(color, Offset(3f * s, 4f * s), Size(18f * s, 12f * s), CornerRadius(2.5f * s), style = st)
                drawLine(color, Offset(8f * s, 20f * s), Offset(16f * s, 20f * s), 2f * s, StrokeCap.Round)
                drawLine(color, Offset(12f * s, 16f * s), Offset(12f * s, 20f * s), 2f * s, StrokeCap.Round)
            }
            "phone" -> {
                drawRoundRect(color, Offset(7f * s, 2.5f * s), Size(10f * s, 19f * s), CornerRadius(2.5f * s), style = st)
                drawLine(color, Offset(10.5f * s, 18.5f * s), Offset(13.5f * s, 18.5f * s), 2f * s, StrokeCap.Round)
            }
            "note" -> {
                drawLine(color, Offset(15f * s, 5f * s), Offset(15f * s, 16f * s), 2.2f * s, StrokeCap.Round)
                drawCircle(color, 3.4f * s, Offset(11.6f * s, 16.5f * s))
                val p = Path()
                p.moveTo(15f * s, 5f * s); p.cubicTo(16f * s, 8f * s, 19f * s, 8f * s, 19.5f * s, 10.5f * s)
                drawPath(p, color, style = st)
            }
            "down" -> {
                val p = Path()
                p.moveTo(6f * s, 9f * s); p.lineTo(12f * s, 15f * s); p.lineTo(18f * s, 9f * s)
                drawPath(p, color, style = Stroke(width = 2.4f * s, cap = StrokeCap.Round))
            }
        }
    }
}

// ---------- building blocks ----------

@Composable
fun GCard(modifier: Modifier = Modifier, radius: Dp = 26.dp, content: @Composable ColumnScope.() -> Unit) {
    val pal = LocalPal.current
    Column(modifier.fillMaxWidth().glass(RoundedCornerShape(radius), pal).padding(16.dp), content = content)
}

@Composable
fun GPill(text: String, filled: Boolean = true, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val pal = LocalPal.current
    val shape = RoundedCornerShape(50)
    val m = if (filled) modifier.clip(shape).background(pal.ink) else modifier.glass(shape, pal)
    Box(m.clickable { onClick() }.padding(horizontal = 20.dp, vertical = 11.dp), contentAlignment = Alignment.Center) {
        T(text, 14, if (filled) (if (pal.dark) pal.onAcc else Color.White) else pal.ink)
    }
}

@Composable
fun GSeg(items: List<String>, sel: Int, onSel: (Int) -> Unit) {
    val pal = LocalPal.current
    Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(50), pal).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        items.forEachIndexed { i, s ->
            Box(
                Modifier.weight(1f).height(36.dp).clip(RoundedCornerShape(50))
                    .background(if (i == sel) pal.selFill else Color.Transparent).clickable { onSel(i) },
                contentAlignment = Alignment.Center
            ) { T(s, 13, if (i == sel) pal.ink else pal.muted) }
        }
    }
}

@Composable
fun GSwitch(on: Boolean, tint: Color, onChange: (Boolean) -> Unit) {
    val pal = LocalPal.current
    val x by animateDpAsState(if (on) 22.dp else 0.dp, label = "sw")
    Box(
        Modifier.size(width = 52.dp, height = 30.dp).clip(RoundedCornerShape(50))
            .background(if (on) tint else pal.track)
            .clickable { onChange(!on) }.padding(3.dp)
    ) {
        Box(Modifier.offset(x = x).size(24.dp).clip(CircleShape).background(Color.White))
    }
}

@Composable
fun GSlider(value: Float, max: Float, tint: Color, enabled: Boolean = true, onDone: (() -> Unit)? = null, onChange: (Float) -> Unit) {
    val pal = LocalPal.current
    Slider(
        value = value.coerceIn(0f, max), onValueChange = onChange, valueRange = 0f..max, enabled = enabled,
        onValueChangeFinished = { onDone?.invoke() },
        colors = SliderDefaults.colors(
            thumbColor = Color.White, activeTrackColor = tint, inactiveTrackColor = pal.track,
            disabledThumbColor = Color.White.copy(alpha = 0.6f), disabledActiveTrackColor = pal.track, disabledInactiveTrackColor = pal.track
        )
    )
}

@Composable
fun VolRow(label: String, value: Int, max: Int, tint: Color, textTint: Color, onChange: (Int) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth()) {
            T(label, 13, modifier = Modifier.weight(1f))
            T("$value%", 13, textTint)
        }
        GSlider(value.toFloat(), max.toFloat(), tint) { onChange(it.toInt()) }
    }
}

@Composable
fun GToggleRow(label: String, on: Boolean, tint: Color, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().height(48.dp), verticalAlignment = Alignment.CenterVertically) {
        T(label, 14, modifier = Modifier.weight(1f))
        GSwitch(on, tint, onChange)
    }
}

/** Cover art, or a soft sunset when the app gives none, with the app's badge in the corner. */
@Composable
fun Cover(m: MediaInfo, size: Dp, radius: Dp, badge: Boolean = true, modifier: Modifier = Modifier) {
    val pal = LocalPal.current
    val shape = RoundedCornerShape(radius)
    Box(modifier.size(size)) {
        val bmp = m.cover
        if (bmp != null) {
            val img = remember(bmp) { bmp.asImageBitmap() }
            Image(bitmap = img, contentDescription = null, modifier = Modifier.fillMaxSize().clip(shape), contentScale = ContentScale.Crop)
        } else {
            Box(
                Modifier.fillMaxSize().clip(shape).background(
                    Brush.linearGradient(listOf(Color(0xFF8C6BFF), Color(0xFFFF5FA2), Color(0xFFFFB86B)))
                ),
                contentAlignment = Alignment.Center
            ) { Ico("note", size * 0.45f, Color.White.copy(alpha = 0.9f)) }
        }
        if (badge && m.has) {
            val bs = size * 0.34f
            val ic = m.appIcon
            Box(
                Modifier.align(Alignment.BottomEnd).offset(x = bs * 0.12f, y = bs * 0.12f).size(bs)
                    .clip(RoundedCornerShape(bs * 0.28f)).background(Color.White).padding(1.5.dp),
                contentAlignment = Alignment.Center
            ) {
                if (ic != null) {
                    val img = remember(ic) { ic.asImageBitmap() }
                    Image(bitmap = img, contentDescription = null, modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(bs * 0.24f)))
                } else {
                    Box(Modifier.fillMaxSize().clip(RoundedCornerShape(bs * 0.24f)).background(pal.violet), contentAlignment = Alignment.Center) {
                        T(m.app.take(1).uppercase(), (bs.value * 0.5f).toInt().coerceAtLeast(8), Color.White, FontWeight.Bold)
                    }
                }
            }
        }
    }
}

fun mmss(ms: Long): String {
    val s = (ms / 1000L).coerceAtLeast(0L)
    val m = s / 60
    val r = s % 60
    return (if (m < 10) "0" else "") + m + ":" + (if (r < 10) "0" else "") + r
}

@Composable
fun Modifier.plainClick(onClick: () -> Unit): Modifier {
    val src = remember { MutableInteractionSource() }
    return this.clickable(interactionSource = src, indication = null) { onClick() }
}

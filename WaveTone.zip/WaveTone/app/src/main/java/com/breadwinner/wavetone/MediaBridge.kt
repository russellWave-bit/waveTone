package com.breadwinner.wavetone

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Icon
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.io.ByteArrayOutputStream

/**
 * Everything about media on this phone.
 *  - reads what is playing (through Notification access)
 *  - runs the buttons for it (play, next, seek, like, volume)
 *  - shows what plays on the PC as a real media card in the notification panel and on the lock screen
 */
object MediaBridge {
    private const val PEER_ID = 22
    private const val CH = "pcmedia"

    const val A_TOGGLE = "wavetone.media.toggle"
    const val A_NEXT = "wavetone.media.next"
    const val A_PREV = "wavetone.media.prev"
    const val A_PC = "wavetone.sw.pc"
    const val A_PHONE = "wavetone.sw.phone"
    const val A_LINK = "wavetone.sw.link"

    private var app: Context? = null
    private val main = Handler(Looper.getMainLooper())
    private var msm: MediaSessionManager? = null
    private var listenerCn: ComponentName? = null
    private var controller: MediaController? = null
    private var likeAction: String? = null
    private val iconCache = HashMap<String, Bitmap?>()
    private var peerSession: MediaSession? = null
    private var widgetPoke = false

    @Volatile var coverJpeg: ByteArray? = null
    @Volatile var coverJpegKey = 0

    private val cb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) { refreshLocal() }
        override fun onPlaybackStateChanged(state: PlaybackState?) { refreshLocal() }
        override fun onSessionDestroyed() { main.post { pick(null) } }
    }

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list -> pick(list) }

    private val tick = object : Runnable {
        override fun run() {
            readVolume()
            if (Hub.connected) Engine.pushLocalMedia()
            main.postDelayed(this, 3000)
        }
    }

    fun init(c: Context) {
        if (app != null) return
        app = c.applicationContext
        Hub.init(c.applicationContext)
        main.postDelayed(tick, 3000)
    }

    // ---------- this phone's media ----------

    fun attach(cn: ComponentName) {
        val c = app ?: return
        listenerCn = cn
        try {
            val m = c.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            msm = m
            m.addOnActiveSessionsChangedListener(sessionsListener, cn, main)
            pick(m.getActiveSessions(cn))
        } catch (e: Exception) {
            Hub.logErr("Media access: " + (e.message ?: e.javaClass.simpleName))
        }
    }

    fun detach() {
        try { msm?.removeOnActiveSessionsChangedListener(sessionsListener) } catch (e: Exception) { }
        try { controller?.unregisterCallback(cb) } catch (e: Exception) { }
        controller = null
        Hub.local = MediaInfo()
        Engine.pushLocalMedia()
        pokeWidgets()
    }

    private fun pick(list: List<MediaController>?) {
        val c = app ?: return
        val mine = c.packageName
        val usable = (list ?: emptyList()).filter { it.packageName != mine }
        val best = usable.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: usable.firstOrNull()
        if (best?.sessionToken == controller?.sessionToken && best != null) {
            refreshLocal()
            return
        }
        try { controller?.unregisterCallback(cb) } catch (e: Exception) { }
        controller = best
        try { best?.registerCallback(cb, main) } catch (e: Exception) { }
        refreshLocal()
    }

    private fun appLabel(pkg: String): String {
        val c = app ?: return pkg
        return try {
            val pm = c.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
    }

    private fun appIcon(pkg: String): Bitmap? {
        if (iconCache.containsKey(pkg)) return iconCache[pkg]
        val c = app ?: return null
        var bmp: Bitmap? = null
        try {
            val d = c.packageManager.getApplicationIcon(pkg)
            val b = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
            val cv = Canvas(b)
            d.setBounds(0, 0, 96, 96)
            d.draw(cv)
            bmp = b
        } catch (e: Exception) {
        }
        iconCache[pkg] = bmp
        return bmp
    }

    private fun refreshLocal() {
        val c = controller
        if (c == null) {
            likeAction = null
            if (Hub.local.has) {
                Hub.local = MediaInfo()
                Engine.pushLocalMedia()
            }
            pokeWidgets()
            return
        }
        try {
            val md = c.metadata
            val st = c.playbackState
            val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
                ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: ""
            val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
            val dur = (md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L).coerceAtLeast(0L)
            val bmp = md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: md?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
            val playing = st?.state == PlaybackState.STATE_PLAYING || st?.state == PlaybackState.STATE_BUFFERING
            val now = SystemClock.elapsedRealtime()
            var pos = st?.position ?: 0L
            if (st != null && playing && st.lastPositionUpdateTime > 0) {
                pos += ((now - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
            }
            if (pos < 0) pos = 0
            if (dur > 0 && pos > dur) pos = dur

            // a like or favourite button, only if this app really offers one
            var like: String? = null
            var liked = false
            val re = Regex("like|favou?rite|heart|thumb|save|add", RegexOption.IGNORE_CASE)
            val undo = Regex("unlike|remove|unsave|liked|unfavou?rite|saved", RegexOption.IGNORE_CASE)
            for (a in st?.customActions ?: emptyList()) {
                val text = a.action + " " + (a.name ?: "")
                if (re.containsMatchIn(text)) {
                    like = a.action
                    liked = undo.containsMatchIn(text)
                    break
                }
            }
            likeAction = like

            var key = 0
            if (bmp != null) {
                key = (title + "|" + artist).hashCode()
                if (key == 0) key = 1
                if (key != coverJpegKey) {
                    coverJpeg = toJpeg(bmp)
                    coverJpegKey = key
                }
            }
            val pkg = c.packageName
            Hub.local = MediaInfo(
                title = title, artist = artist, app = appLabel(pkg),
                playing = playing, posMs = pos, durMs = dur, posAt = now,
                canLike = like != null, liked = liked, vol = Hub.phoneVol,
                coverKey = key, cover = bmp, appIcon = appIcon(pkg)
            )
            Engine.pushLocalMedia()
        } catch (e: Exception) {
            Hub.logErr("Media: " + (e.message ?: e.javaClass.simpleName))
        }
        pokeWidgets()
    }

    private fun toJpeg(src: Bitmap): ByteArray? {
        return try {
            val m = 320
            val big = maxOf(src.width, src.height)
            val b = if (big > m) {
                val f = m.toFloat() / big
                Bitmap.createScaledBitmap(src, (src.width * f).toInt().coerceAtLeast(1), (src.height * f).toInt().coerceAtLeast(1), true)
            } else src
            val bo = ByteArrayOutputStream()
            b.compress(Bitmap.CompressFormat.JPEG, 80, bo)
            bo.toByteArray()
        } catch (e: Exception) {
            null
        }
    }

    /** Runs a button on this phone's media. */
    fun command(cmd: String, v: Long) {
        val t = controller?.transportControls
        try {
            when (cmd) {
                "toggle" -> if (Hub.local.playing) t?.pause() else t?.play()
                "play" -> t?.play()
                "pause" -> t?.pause()
                "next" -> t?.skipToNext()
                "prev" -> t?.skipToPrevious()
                "seek" -> t?.seekTo(v)
                "like" -> likeAction?.let { t?.sendCustomAction(it, null) }
                "vol" -> setVolume(v.toInt())
            }
        } catch (e: Exception) {
            Hub.logErr("Media button: " + (e.message ?: e.javaClass.simpleName))
        }
    }

    /** What the player screens call: the button goes to whichever device is shown. */
    fun act(cmd: String, v: Long = 0L) {
        if (Hub.mediaSource() == 2) Engine.sendCmd(cmd, v) else command(cmd, v)
    }

    private fun am(): AudioManager? = app?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    fun readVolume() {
        val a = am() ?: return
        val max = a.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        if (max > 0) Hub.phoneVol = a.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / max
    }

    fun setVolume(pct: Int) {
        val a = am() ?: return
        val max = a.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        a.setStreamVolume(AudioManager.STREAM_MUSIC, (pct.coerceIn(0, 100) * max / 100f).toInt(), 0)
        Hub.phoneVol = pct.coerceIn(0, 100)
    }

    // ---------- the PC's media as a real media card ----------

    fun peerChanged() {
        main.post { updatePeer() }
        pokeWidgets()
    }

    private val peerCb = object : MediaSession.Callback() {
        override fun onPlay() { Engine.sendCmd("play") }
        override fun onPause() { Engine.sendCmd("pause") }
        override fun onSkipToNext() { Engine.sendCmd("next") }
        override fun onSkipToPrevious() { Engine.sendCmd("prev") }
        override fun onSeekTo(pos: Long) { Engine.sendCmd("seek", pos) }
    }

    private fun pi(c: Context, action: String, code: Int): PendingIntent =
        PendingIntent.getBroadcast(c, code, Intent(c, ActionReceiver::class.java).setAction(action).putExtra("pc", true), PendingIntent.FLAG_IMMUTABLE)

    private fun updatePeer() {
        val c = app ?: return
        val nm = c.getSystemService(NotificationManager::class.java)
        val m = Hub.peerMedia
        if (!Hub.connected || !m.has || !Hub.wantPc) {
            try { peerSession?.release() } catch (e: Exception) { }
            peerSession = null
            nm.cancel(PEER_ID)
            return
        }
        try {
            nm.createNotificationChannel(NotificationChannel(CH, "PC media", NotificationManager.IMPORTANCE_LOW))
            val s = peerSession ?: MediaSession(c, "WaveTone PC").also {
                it.setCallback(peerCb)
                it.isActive = true
                peerSession = it
            }
            val mdb = MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, m.title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, m.artist)
                .putString(MediaMetadata.METADATA_KEY_ALBUM, (if (m.app.isEmpty()) "Your PC" else m.app + " on your PC"))
                .putLong(MediaMetadata.METADATA_KEY_DURATION, m.durMs)
            if (m.cover != null) mdb.putBitmap(MediaMetadata.METADATA_KEY_ART, m.cover)
            s.setMetadata(mdb.build())
            val acts = PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
                PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_SEEK_TO
            s.setPlaybackState(
                PlaybackState.Builder().setActions(acts)
                    .setState(
                        if (m.playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED,
                        m.now(), if (m.playing) 1f else 0f, SystemClock.elapsedRealtime()
                    ).build()
            )
            val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val b = Notification.Builder(c, CH)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(m.title)
                .setContentText(m.artist)
                .setSubText("From your PC")
                .setContentIntent(open)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOnlyAlertOnce(true)
                .setOngoing(m.playing)
                .addAction(Notification.Action.Builder(Icon.createWithResource(c, R.drawable.ic_prev), "Previous", pi(c, A_PREV, 11)).build())
                .addAction(
                    Notification.Action.Builder(
                        Icon.createWithResource(c, if (m.playing) R.drawable.ic_pause else R.drawable.ic_play),
                        if (m.playing) "Pause" else "Play", pi(c, A_TOGGLE, 12)
                    ).build()
                )
                .addAction(Notification.Action.Builder(Icon.createWithResource(c, R.drawable.ic_next), "Next", pi(c, A_NEXT, 13)).build())
                .setStyle(Notification.MediaStyle().setMediaSession(s.sessionToken).setShowActionsInCompactView(0, 1, 2))
            if (m.cover != null) b.setLargeIcon(m.cover)
            nm.notify(PEER_ID, b.build())
        } catch (e: Exception) {
            Hub.logErr("PC media card: " + (e.message ?: e.javaClass.simpleName))
        }
    }

    fun clearPeer() {
        main.post {
            try { peerSession?.release() } catch (e: Exception) { }
            peerSession = null
            try { app?.getSystemService(NotificationManager::class.java)?.cancel(PEER_ID) } catch (e: Exception) { }
        }
    }

    // ---------- widgets ----------

    fun pokeWidgets() {
        val c = app ?: return
        if (widgetPoke) return
        widgetPoke = true
        main.postDelayed({
            widgetPoke = false
            try { Widgets.updateAll(c) } catch (e: Exception) { }
        }, 400)
    }
}

package com.breadwinner.wavetone

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Catches button presses from the home-screen widgets and the PC media card. */
class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        MediaBridge.init(c)
        val pc = i.getBooleanExtra("pc", false)
        fun go(cmd: String) {
            if (pc) Engine.sendCmd(cmd) else MediaBridge.act(cmd)
        }
        when (i.action) {
            MediaBridge.A_TOGGLE -> go("toggle")
            MediaBridge.A_NEXT -> go("next")
            MediaBridge.A_PREV -> go("prev")
            MediaBridge.A_PC -> { Hub.wantPc = !Hub.wantPc; Hub.changed() }
            MediaBridge.A_PHONE -> { Hub.allowSend = !Hub.allowSend; Hub.changed() }
            MediaBridge.A_LINK -> {
                if (Hub.connected) Engine.disconnect() else Engine.requestConnect()
                MediaBridge.pokeWidgets()
            }
        }
    }
}

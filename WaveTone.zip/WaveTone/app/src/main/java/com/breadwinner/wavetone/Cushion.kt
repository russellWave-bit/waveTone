package com.breadwinner.wavetone

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * The smart cushion. It watches how evenly the sound chunks arrive and keeps just enough
 * sound waiting in line: small when the Wi-Fi is steady, bigger for a moment when it is not.
 * Mode 0 = Smart, 1 = Fast, 2 = Steady.
 */
class Cushion {
    @Volatile var targetMs = 40f
    @Volatile var nudgeMs = 0
    @Volatile var mode = 0
    @Volatile var underruns = 0
    @Volatile var lastArrivalMs = 0L
    private var lastArr = 0L
    private var peak = 0f
    private var lastShrink = 0L

    private fun lo(): Float = when (mode) { 1 -> 15f; 2 -> 220f; else -> 25f }
    private fun hi(): Float = when (mode) { 1 -> 60f; 2 -> 300f; else -> 220f }

    fun reset() {
        lastArr = 0L
        peak = 0f
        underruns = 0
        targetMs = when (mode) { 1 -> 25f; 2 -> 240f; else -> 40f }
    }

    /** Call for every chunk that arrives, with a clock in nanoseconds. */
    fun arrived(nowNs: Long) {
        lastArrivalMs = nowNs / 1_000_000L
        if (lastArr != 0L) {
            val gap = (nowNs - lastArr) / 1e6f
            if (gap < 500f) {
                val dev = abs(gap - 10f)
                peak = max(dev, peak * 0.9993f)
            }
        }
        lastArr = nowNs
        val want = (20f + 1.5f * peak).coerceIn(lo(), hi())
        if (want > targetMs) targetMs = want
        else {
            val now = nowNs / 1_000_000L
            if (now - lastShrink > 500L && targetMs > want) {
                targetMs = max(want, targetMs - 1f)
                lastShrink = now
            }
        }
        if (targetMs < lo()) targetMs = lo()
        if (targetMs > hi()) targetMs = hi()
    }

    /** The line ran dry in the middle of a stream. */
    fun underrun() {
        underruns++
        targetMs = min(hi(), targetMs + 25f)
        peak = max(peak, targetMs / 1.5f)
    }

    /** The cushion actually used, with the lip-sync nudge added. */
    fun effective(): Float = max(10f, targetMs + nudgeMs)
}

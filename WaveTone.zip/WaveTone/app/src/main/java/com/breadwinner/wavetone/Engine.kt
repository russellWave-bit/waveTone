package com.breadwinner.wavetone

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.projection.MediaProjection
import android.os.Build
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.nio.ByteBuffer
import java.util.concurrent.LinkedBlockingDeque
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max

/** Sound in both directions. Listens for the PC, answers its control messages, captures and plays. */
object Engine {
    private const val RATE = 48000
    private const val CHUNK = 1920            // 10 ms of 48 kHz stereo 16-bit
    private const val BEACON_PORT = 8766

    @Volatile private var link: Link? = null
    @Volatile private var stopped = true
    private var server: ServerSocket? = null
    private var projection: MediaProjection? = null
    @Volatile private var capturing = false
    @Volatile private var playing = false
    private val queue = LinkedBlockingDeque<ByteArray>()
    private var acceptThread: Thread? = null
    private var beaconThread: Thread? = null

    fun start(mp: MediaProjection) {
        stopped = false
        projection = mp
        var s: ServerSocket? = null
        for (p in 8765..8775) {
            try {
                s = ServerSocket(p)
                Hub.port = p
                break
            } catch (e: Exception) {
            }
        }
        if (s == null) {
            Hub.logErr("Could not open a port")
            return
        }
        val srv: ServerSocket = s
        server = srv
        acceptThread = Thread({
            while (!stopped) {
                try {
                    val c = srv.accept()
                    c.tcpNoDelay = true
                    c.soTimeout = 9000
                    handle(c)
                } catch (e: Exception) {
                    if (!stopped) Hub.logErr("Connection: " + (e.message ?: e.javaClass.simpleName))
                }
            }
        }, "wt-accept").also { it.start() }
        beaconThread = Thread({ beacon() }, "wt-beacon").also { it.start() }
        Hub.running = true
    }

    fun stop() {
        stopped = true
        Hub.running = false
        try { link?.close() } catch (e: Exception) { }
        try { server?.close() } catch (e: Exception) { }
        server = null
        stopCapture()
        stopPlayback()
        projection = null
    }

    private fun handle(sock: java.net.Socket) {
        val l = Link(sock)
        link = l
        Hub.connected = true
        Hub.dropped = 0
        Hub.sentKb = 0
        Hub.recvKb = 0
        sendControl()
        val pinger = Thread({
            while (l.alive) {
                l.send(3, ByteBuffer.allocate(8).putLong(System.nanoTime()).array())
                try { Thread.sleep(2000) } catch (e: InterruptedException) { }
            }
        }, "wt-ping")
        pinger.start()
        l.readLoop { t, b -> onFrame(l, t, b) }
        link = null
        Hub.connected = false
        Hub.peerName = ""
        Hub.peerWant = false
        Hub.peerAllow = false
        Hub.rttMs = 0
        stopCapture()
        stopPlayback()
    }

    private fun onFrame(l: Link, t: Int, b: ByteArray) {
        when (t) {
            1 -> {
                try {
                    val o = JSONObject(String(b, Charsets.UTF_8))
                    Hub.peerName = o.optString("name", "PC")
                    Hub.peerWant = o.optBoolean("want", false)
                    Hub.peerAllow = o.optBoolean("allow", false)
                    refresh()
                } catch (e: Exception) {
                    Hub.logErr("Bad message from the PC")
                }
            }
            2 -> {
                if (!playing) return
                Hub.recvKb += b.size / 1024
                val cap = max(4, Hub.latency / 10 + 2)
                while (queue.size > cap) {
                    queue.pollFirst()
                    Hub.dropped++
                }
                queue.addLast(b)
            }
            3 -> l.send(4, b)
            4 -> {
                if (b.size == 8) {
                    val sent = ByteBuffer.wrap(b).long
                    Hub.rttMs = ((System.nanoTime() - sent) / 1_000_000L).toInt()
                }
            }
        }
    }

    fun sendControl() {
        val l = link ?: return
        val o = JSONObject()
            .put("name", Build.MODEL ?: "Phone")
            .put("want", Hub.wantPc)
            .put("allow", Hub.allowSend)
            .put("latency", Hub.latency)
        l.send(1, o.toString().toByteArray(Charsets.UTF_8))
    }

    /** Starts or stops each direction depending on what both sides chose. */
    fun refresh() {
        val l = link
        val capNeeded = l != null && Hub.allowSend && Hub.peerWant && projection != null
        if (capNeeded) startCapture() else stopCapture()
        val playNeeded = l != null && Hub.wantPc && Hub.peerAllow
        if (playNeeded) startPlayback() else stopPlayback()
    }

    // ---------- phone sound to the PC ----------

    @Synchronized private fun startCapture() {
        if (capturing) return
        val mp = projection ?: return
        val l = link ?: return
        val rec: AudioRecord
        try {
            val cfg = AudioPlaybackCaptureConfiguration.Builder(mp)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .excludeUid(android.os.Process.myUid())
                .build()
            val fmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build()
            val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            rec = AudioRecord.Builder()
                .setAudioPlaybackCaptureConfig(cfg)
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(max(min, CHUNK * 8))
                .build()
            rec.startRecording()
        } catch (e: Exception) {
            Hub.logErr("Phone sound capture failed: " + (e.message ?: e.javaClass.simpleName))
            return
        }
        capturing = true
        Thread({
            val buf = ByteArray(CHUNK)
            try {
                while (capturing && l.alive) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n <= 0) continue
                    val out = if (n == buf.size) buf.copyOf() else buf.copyOf(n)
                    val peak = scale(out, Hub.sendGain / 100f)
                    Hub.sendLevel = max(peak / 32768f, Hub.sendLevel * 0.85f)
                    Hub.sentKb += n / 1024
                    l.send(2, out)
                }
            } catch (e: Exception) {
                Hub.logErr("Capture stopped: " + (e.message ?: ""))
            } finally {
                try { rec.stop() } catch (e: Exception) { }
                try { rec.release() } catch (e: Exception) { }
                Hub.sendLevel = 0f
            }
        }, "wt-capture").start()
    }

    @Synchronized private fun stopCapture() {
        capturing = false
    }

    // ---------- PC sound on the phone ----------

    @Synchronized private fun startPlayback() {
        if (playing) return
        queue.clear()
        val track: AudioTrack
        try {
            val min = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            val want = Hub.latency * 192
            val b = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                        .build()
                )
                .setBufferSizeInBytes(max(min, max(CHUNK * 4, want / 2)))
                .setTransferMode(AudioTrack.MODE_STREAM)
            if (Hub.latency <= 60) b.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            track = b.build()
            track.play()
        } catch (e: Exception) {
            Hub.logErr("Could not play the PC sound: " + (e.message ?: e.javaClass.simpleName))
            return
        }
        playing = true
        Thread({
            var primed = false
            try {
                while (playing) {
                    val c = queue.poll(100, TimeUnit.MILLISECONDS)
                    if (c == null) {
                        primed = false
                        Hub.playLevel *= 0.8f
                        continue
                    }
                    if (!primed) {
                        val need = max(2, Hub.latency / 20)
                        if (queue.size + 1 < need) {
                            queue.addFirst(c)
                            Thread.sleep(4)
                            continue
                        }
                        primed = true
                    }
                    val g = if (Hub.playMute) 0f else Hub.playVol / 100f
                    val peak = scale(c, g)
                    Hub.playLevel = max(peak / 32768f, Hub.playLevel * 0.85f)
                    Hub.bufMs = queue.size * 10
                    track.write(c, 0, c.size)
                }
            } catch (e: Exception) {
                Hub.logErr("Playback stopped: " + (e.message ?: ""))
            } finally {
                try { track.stop() } catch (e: Exception) { }
                try { track.release() } catch (e: Exception) { }
                Hub.playLevel = 0f
                Hub.bufMs = 0
            }
        }, "wt-play").start()
    }

    @Synchronized private fun stopPlayback() {
        playing = false
        queue.clear()
    }

    /** Multiplies 16-bit samples by [g] in place and returns the loudest one. */
    private fun scale(b: ByteArray, g: Float): Int {
        var peak = 0
        var i = 0
        while (i + 1 < b.size) {
            val v = (b[i + 1].toInt() shl 8) or (b[i].toInt() and 0xFF)
            val s = (v * g).toInt().coerceIn(-32768, 32767)
            peak = max(peak, abs(s))
            b[i] = s.toByte()
            b[i + 1] = (s shr 8).toByte()
            i += 2
        }
        return peak
    }

    /** Tells every PC on the network that this phone is here, so the PC app can list it. */
    private fun beacon() {
        var sock: DatagramSocket? = null
        try {
            sock = DatagramSocket()
            sock.broadcast = true
            while (!stopped) {
                val msg = ("WAVETONE|" + (Build.MODEL ?: "Phone") + "|" + Hub.port).toByteArray()
                val targets = HashSet<InetAddress>()
                try {
                    targets.add(InetAddress.getByName("255.255.255.255"))
                    val all = NetworkInterface.getNetworkInterfaces()
                    while (all != null && all.hasMoreElements()) {
                        val ni = all.nextElement()
                        if (!ni.isUp || ni.isLoopback) continue
                        for (ia in ni.interfaceAddresses) {
                            ia.broadcast?.let { targets.add(it) }
                        }
                    }
                } catch (e: Exception) {
                }
                for (t in targets) {
                    try { sock.send(DatagramPacket(msg, msg.size, t, BEACON_PORT)) } catch (e: Exception) { }
                }
                Thread.sleep(1000)
            }
        } catch (e: Exception) {
        } finally {
            try { sock?.close() } catch (e: Exception) { }
        }
    }
}

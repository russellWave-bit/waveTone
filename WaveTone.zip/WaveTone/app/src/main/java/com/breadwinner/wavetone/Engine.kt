package com.breadwinner.wavetone

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.projection.MediaProjection
import android.os.Build
import android.os.SystemClock
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.nio.ByteBuffer
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingDeque
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max

/** Sound in both directions. Listens for the PC, answers its control messages, captures and plays. */
object Engine {
    private const val RATE = 48000
    private const val CHUNK = 1920            // 10 ms of 48 kHz stereo 16-bit
    private const val BEACON_PORT = 8766

    @Volatile private var link: Link? = null
    @Volatile private var stopped = true
    private var server: ServerSocket? = null
    private var projection: MediaProjection? = null
    @Volatile private var capturing = false
    @Volatile private var playing = false
    private val queue = LinkedBlockingDeque<ByteArray>()
    val cushion = Cushion()
    /** Anything sent from a screen, widget or media callback goes out on this thread, never the main one. */
    private val io = Executors.newSingleThreadExecutor()
    @Volatile private var sentCoverKey = -1
    private var acceptThread: Thread? = null
    private var beaconThread: Thread? = null

    fun start(mp: MediaProjection) {
        stopped = false
        projection = mp
        var s: ServerSocket? = null
        for (p in 8765..8775) {
            try {
                s = ServerSocket(p)
                Hub.port = p
                break
            } catch (e: Exception) {
            }
        }
        if (s == null) {
            Hub.logErr("Could not open a port")
            return
        }
        val srv: ServerSocket = s
        server = srv
        acceptThread = Thread({
            while (!stopped) {
                try {
                    val c = srv.accept()
                    c.tcpNoDelay = true
                    c.soTimeout = 9000
                    try { link?.close() } catch (e: Exception) { }
                    Hub.linkWanted = true
                    val nl = Link(c)
                    link = nl
                    Thread({ handle(nl) }, "wt-link").start()
                } catch (e: Exception) {
                    if (!stopped) Hub.logErr("Connection: " + (e.message ?: e.javaClass.simpleName))
                }
            }
        }, "wt-accept").also { it.start() }
        beaconThread = Thread({ beacon() }, "wt-beacon").also { it.start() }
        Hub.running = true
    }

    fun stop() {
        stopped = true
        Hub.running = false
        try { link?.close() } catch (e: Exception) { }
        try { server?.close() } catch (e: Exception) { }
        server = null
        stopCapture()
        stopPlayback()
        projection = null
    }

    private fun handle(l: Link) {
        Hub.connected = true
        Hub.everConnected = true
        Hub.dropped = 0
        Hub.sentKb = 0
        Hub.recvKb = 0
        sentCoverKey = -1
        cushion.mode = Hub.delayMode
        cushion.nudgeMs = Hub.nudge
        cushion.reset()
        sendControl()
        pushLocalMedia()
        MediaBridge.pokeWidgets()
        val pinger = Thread({
            while (l.alive) {
                l.send(3, ByteBuffer.allocate(8).putLong(System.nanoTime()).array())
                try { Thread.sleep(2000) } catch (e: InterruptedException) { }
            }
        }, "wt-ping")
        pinger.start()
        l.readLoop { t, b -> onFrame(l, t, b) }
        if (link === l) {
            link = null
            Hub.connected = false
            Hub.peerName = ""
            Hub.peerWant = false
            Hub.peerAllow = false
            Hub.rttMs = 0
            Hub.peerMedia = MediaInfo()
            MediaBridge.peerChanged()
            MediaBridge.pokeWidgets()
            stopCapture()
            stopPlayback()
        }
    }

    private fun onFrame(l: Link, t: Int, b: ByteArray) {
        when (t) {
            1 -> {
                try {
                    val o = JSONObject(String(b, Charsets.UTF_8))
                    Hub.peerName = o.optString("name", "PC")
                    Hub.peerWant = o.optBoolean("want", false)
                    Hub.peerAllow = o.optBoolean("allow", false)
                    if (o.optBoolean("bye", false)) {
                        l.close()
                        return
                    }
                    refresh()
                } catch (e: Exception) {
                    Hub.logErr("Bad message from the PC")
                }
            }
            2 -> {
                if (!playing) return
                Hub.recvKb += b.size / 1024
                cushion.arrived(System.nanoTime())
                val eff = cushion.effective()
                val maxChunks = ((eff + 90f) / 10f).toInt()
                if (queue.size > maxChunks) {
                    val keep = ((eff + 30f) / 10f).toInt()
                    while (queue.size > keep) {
                        queue.pollFirst()
                        Hub.dropped++
                    }
                }
                queue.addLast(b)
                Hub.targetMs = eff.toInt()
            }
            5 -> {
                try {
                    val o = JSONObject(String(b, Charsets.UTF_8))
                    val ck = o.optInt("ck", 0)
                    val prev = Hub.peerMedia
                    Hub.peerMedia = MediaInfo(
                        title = o.optString("title", ""),
                        artist = o.optString("artist", ""),
                        app = o.optString("app", ""),
                        playing = o.optBoolean("playing", false),
                        posMs = o.optLong("pos", 0L),
                        durMs = o.optLong("dur", 0L),
                        posAt = SystemClock.elapsedRealtime(),
                        canLike = false,
                        vol = o.optInt("vol", -1),
                        coverKey = ck,
                        cover = if (prev.coverKey == ck) prev.cover else null
                    )
                    MediaBridge.peerChanged()
                } catch (e: Exception) {
                    Hub.logErr("Bad media message from the PC")
                }
            }
            6 -> {
                if (b.size > 8) {
                    val key = ByteBuffer.wrap(b, 0, 4).int
                    val bmp = android.graphics.BitmapFactory.decodeByteArray(b, 4, b.size - 4)
                    if (bmp != null && Hub.peerMedia.coverKey == key) {
                        Hub.peerMedia = Hub.peerMedia.copy(cover = bmp)
                        MediaBridge.peerChanged()
                    }
                }
            }
            7 -> {
                try {
                    val o = JSONObject(String(b, Charsets.UTF_8))
                    MediaBridge.command(o.optString("cmd", ""), o.optLong("v", 0L))
                } catch (e: Exception) {
                }
            }
            3 -> l.send(4, b)
            4 -> {
                if (b.size == 8) {
                    val sent = ByteBuffer.wrap(b).long
                    Hub.rttMs = ((System.nanoTime() - sent) / 1_000_000L).toInt()
                }
            }
        }
    }

    fun sendControl() { io.execute { sendControlNow() } }

    private fun sendControlNow() {
        val l = link ?: return
        val o = JSONObject()
            .put("name", Build.MODEL ?: "Phone")
            .put("want", Hub.wantPc)
            .put("allow", Hub.allowSend)
        l.send(1, o.toString().toByteArray(Charsets.UTF_8))
    }

    /** User pressed Disconnect: tell the PC so it does not reconnect, then hang up. */
    fun disconnect() {
        Hub.linkWanted = false
        io.execute { disconnectNow() }
    }

    private fun disconnectNow() {
        val l = link ?: return
        val o = JSONObject().put("name", Build.MODEL ?: "Phone").put("want", false).put("allow", false).put("bye", true)
        l.send(1, o.toString().toByteArray(Charsets.UTF_8))
        Thread({
            try { Thread.sleep(250) } catch (e: Exception) { }
            l.close()
        }, "wt-bye").start()
    }

    /** User pressed Connect: ask the PC (through the beacon) to join again. */
    fun requestConnect() {
        Hub.linkWanted = true
        Hub.wantedSeq++
    }

    /** Sends what plays on this phone to the PC. Cover goes only when it changed. */
    fun pushLocalMedia() { io.execute { pushLocalMediaNow() } }

    private fun pushLocalMediaNow() {
        val l = link ?: return
        val m = Hub.local
        val o = JSONObject()
            .put("title", m.title).put("artist", m.artist).put("app", m.app)
            .put("playing", m.playing).put("pos", m.now()).put("dur", m.durMs)
            .put("like", m.canLike).put("liked", m.liked)
            .put("vol", Hub.phoneVol).put("ck", m.coverKey)
        l.send(5, o.toString().toByteArray(Charsets.UTF_8))
        if (m.coverKey != 0 && m.coverKey != sentCoverKey) {
            val jpg = MediaBridge.coverJpeg
            if (jpg != null && MediaBridge.coverJpegKey == m.coverKey) {
                val bb = ByteBuffer.allocate(4 + jpg.size)
                bb.putInt(m.coverKey)
                bb.put(jpg)
                l.send(6, bb.array())
                sentCoverKey = m.coverKey
            }
        }
    }

    /** Ask the PC to do something with its media (play, next, seek, volume...). */
    fun sendCmd(cmd: String, v: Long = 0L) { io.execute { sendCmdNow(cmd, v) } }

    private fun sendCmdNow(cmd: String, v: Long) {
        val l = link ?: return
        l.send(7, JSONObject().put("cmd", cmd).put("v", v).toString().toByteArray(Charsets.UTF_8))
    }

    /** Starts or stops each direction depending on what both sides chose. */
    fun refresh() {
        val l = link
        val capNeeded = l != null && Hub.allowSend && Hub.peerWant && projection != null
        if (capNeeded) startCapture() else stopCapture()
        val playNeeded = l != null && Hub.wantPc && Hub.peerAllow
        if (playNeeded) startPlayback() else stopPlayback()
    }

    // ---------- phone sound to the PC ----------

    @Synchronized private fun startCapture() {
        if (capturing) return
        val mp = projection ?: return
        val l = link ?: return
        val rec: AudioRecord
        try {
            val cfg = AudioPlaybackCaptureConfiguration.Builder(mp)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .excludeUid(android.os.Process.myUid())
                .build()
            val fmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build()
            val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            rec = AudioRecord.Builder()
                .setAudioPlaybackCaptureConfig(cfg)
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(max(min, CHUNK * 8))
                .build()
            rec.startRecording()
        } catch (e: Exception) {
            Hub.logErr("Phone sound capture failed: " + (e.message ?: e.javaClass.simpleName))
            return
        }
        capturing = true
        Thread({
            val buf = ByteArray(CHUNK)
            try {
                while (capturing && l.alive) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n <= 0) continue
                    val out = if (n == buf.size) buf.copyOf() else buf.copyOf(n)
                    val peak = scale(out, Hub.sendGain / 100f)
                    Hub.sendLevel = max(peak / 32768f, Hub.sendLevel * 0.85f)
                    Hub.sentKb += n / 1024
                    l.send(2, out)
                }
            } catch (e: Exception) {
                Hub.logErr("Capture stopped: " + (e.message ?: ""))
            } finally {
                try { rec.stop() } catch (e: Exception) { }
                try { rec.release() } catch (e: Exception) { }
                Hub.sendLevel = 0f
            }
        }, "wt-capture").start()
    }

    @Synchronized private fun stopCapture() {
        capturing = false
    }

    // ---------- PC sound on the phone ----------

    @Synchronized private fun startPlayback() {
        if (playing) return
        queue.clear()
        cushion.mode = Hub.delayMode
        cushion.nudgeMs = Hub.nudge
        cushion.reset()
        val track: AudioTrack
        try {
            val min = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            val b = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                        .build()
                )
                .setBufferSizeInBytes(max(min, CHUNK * 6))
                .setTransferMode(AudioTrack.MODE_STREAM)
            if (Hub.delayMode != 2) b.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            track = b.build()
            track.play()
        } catch (e: Exception) {
            Hub.logErr("Could not play the PC sound: " + (e.message ?: e.javaClass.simpleName))
            return
        }
        playing = true
        Thread({
            var primed = false
            var dryAt = 0L
            try {
                while (playing) {
                    cushion.mode = Hub.delayMode
                    cushion.nudgeMs = Hub.nudge
                    val c = queue.poll(30, TimeUnit.MILLISECONDS)
                    if (c == null) {
                        if (primed) {
                            primed = false
                            dryAt = System.nanoTime() / 1_000_000L
                        }
                        Hub.playLevel *= 0.8f
                        continue
                    }
                    if (!primed) {
                        val need = (cushion.effective() / 10f).toInt().coerceAtLeast(1)
                        if (queue.size + 1 < need) {
                            queue.addFirst(c)
                            Thread.sleep(5)
                            continue
                        }
                        primed = true
                        if (dryAt != 0L) {
                            // the stream carried on soon after running dry: that was a real hiccup
                            if (System.nanoTime() / 1_000_000L - dryAt < 300L) cushion.underrun()
                            dryAt = 0L
                        }
                    }
                    val g = if (Hub.playMute) 0f else Hub.playVol / 100f
                    val peak = scale(c, g)
                    Hub.playLevel = max(peak / 32768f, Hub.playLevel * 0.85f)
                    Hub.bufMs = queue.size * 10
                    Hub.targetMs = cushion.effective().toInt()
                    Hub.underruns = cushion.underruns
                    track.write(c, 0, c.size)
                }
            } catch (e: Exception) {
                Hub.logErr("Playback stopped: " + (e.message ?: ""))
            } finally {
                try { track.stop() } catch (e: Exception) { }
                try { track.release() } catch (e: Exception) { }
                Hub.playLevel = 0f
                Hub.bufMs = 0
            }
        }, "wt-play").start()
    }

    @Synchronized private fun stopPlayback() {
        playing = false
        queue.clear()
    }

    /** Multiplies 16-bit samples by [g] in place and returns the loudest one. */
    private fun scale(b: ByteArray, g: Float): Int {
        var peak = 0
        var i = 0
        while (i + 1 < b.size) {
            val v = (b[i + 1].toInt() shl 8) or (b[i].toInt() and 0xFF)
            val s = (v * g).toInt().coerceIn(-32768, 32767)
            peak = max(peak, abs(s))
            b[i] = s.toByte()
            b[i + 1] = (s shr 8).toByte()
            i += 2
        }
        return peak
    }

    /** Tells every PC on the network that this phone is here, so the PC app can list it. */
    private fun beacon() {
        var sock: DatagramSocket? = null
        try {
            sock = DatagramSocket()
            sock.broadcast = true
            while (!stopped) {
                val msg = ("WAVETONE|" + (Build.MODEL ?: "Phone") + "|" + Hub.port + "|" + (if (Hub.linkWanted) 1 else 0) + "|" + Hub.wantedSeq).toByteArray()
                val targets = HashSet<InetAddress>()
                try {
                    targets.add(InetAddress.getByName("255.255.255.255"))
                    val all = NetworkInterface.getNetworkInterfaces()
                    while (all != null && all.hasMoreElements()) {
                        val ni = all.nextElement()
                        if (!ni.isUp || ni.isLoopback) continue
                        for (ia in ni.interfaceAddresses) {
                            ia.broadcast?.let { targets.add(it) }
                        }
                    }
                } catch (e: Exception) {
                }
                for (t in targets) {
                    try { sock.send(DatagramPacket(msg, msg.size, t, BEACON_PORT)) } catch (e: Exception) { }
                }
                Thread.sleep(1000)
            }
        } catch (e: Exception) {
        } finally {
            try { sock?.close() } catch (e: Exception) { }
        }
    }
}

package com.breadwinner.wavetone

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

/** Keeps the sound link alive while the screen is off, and starts the optional hotspot. */
class ToneService : Service() {
    private var projection: MediaProjection? = null
    private var reservation: WifiManager.LocalOnlyHotspotReservation? = null
    private var lock: PowerManager.WakeLock? = null

    companion object {
        const val STOP = "wavetone.stop"
        const val CH = "tone"
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Sound link", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, notif(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        @Suppress("DEPRECATION")
        val data = i?.getParcelableExtra<Intent>("data")
        val code = i?.getIntExtra("code", 0) ?: 0
        if (data == null || code == 0) {
            Hub.hotspotMsg = "Sound capture was not allowed."
            stopSelf()
            return START_NOT_STICKY
        }
        if (projection != null) return START_NOT_STICKY
        try {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            val mp = mpm.getMediaProjection(code, data)
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    Hub.logErr("Android stopped the sound capture")
                    stopSelf()
                }
            }, Handler(Looper.getMainLooper()))
            projection = mp
            val pm = getSystemService(PowerManager::class.java)
            lock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "wavetone:link").apply { acquire() }
            Engine.start(mp)
            Hub.mode = i?.getIntExtra("mode", 1) ?: 1
            if (Hub.mode == 1 && reservation == null) startHotspot()
        } catch (e: Exception) {
            Hub.logErr("Could not start: " + (e.message ?: e.javaClass.simpleName))
            Hub.hotspotMsg = "Could not start the sound link."
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun notif(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ToneService::class.java).setAction(STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("WaveTone is on")
            .setContentText("Open WaveTone on your PC to connect")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat), "Stop", stop).build())
            .build()
    }

    @Suppress("DEPRECATION")
    private fun startHotspot() {
        Hub.hotspotMsg = "Starting the hotspot..."
        val wm = applicationContext.getSystemService(WifiManager::class.java)
        try {
            wm.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(r: WifiManager.LocalOnlyHotspotReservation) {
                    reservation = r
                    if (Build.VERSION.SDK_INT >= 30) {
                        val c = r.softApConfiguration
                        Hub.ssid = c.ssid ?: ""
                        Hub.pass = c.passphrase ?: ""
                    } else {
                        val c = r.wifiConfiguration
                        Hub.ssid = (c?.SSID ?: "").trim('"')
                        Hub.pass = c?.preSharedKey ?: ""
                    }
                    Hub.hotspotMsg = ""
                }

                override fun onStopped() {
                    Hub.ssid = ""
                    Hub.pass = ""
                    Hub.hotspotMsg = "The hotspot stopped."
                }

                override fun onFailed(reason: Int) {
                    Hub.hotspotMsg = when (reason) {
                        ERROR_NO_CHANNEL -> "No Wi-Fi channel is free right now. Try again."
                        ERROR_INCOMPATIBLE_MODE -> "Turn off your normal hotspot first, then try again."
                        ERROR_TETHERING_DISALLOWED -> "This phone does not allow apps to start a hotspot."
                        else -> "The hotspot could not start. Make sure Location is switched on."
                    }
                }
            }, Handler(Looper.getMainLooper()))
        } catch (e: SecurityException) {
            Hub.hotspotMsg = "Allow the permission and switch Location on, then try again."
        } catch (e: Exception) {
            Hub.hotspotMsg = "The hotspot could not start on this phone."
        }
    }

    override fun onDestroy() {
        Engine.stop()
        try { projection?.stop() } catch (e: Exception) { }
        projection = null
        try { reservation?.close() } catch (e: Exception) { }
        reservation = null
        try { lock?.release() } catch (e: Exception) { }
        lock = null
        Hub.running = false
        Hub.connected = false
        Hub.ssid = ""
        Hub.pass = ""
        super.onDestroy()
    }
}

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using Path = System.Windows.Shapes.Path;

namespace WaveTonePC
{
    public partial class MainWindow : Window
    {
        private readonly Engine E = Engine.I;
        private readonly DispatcherTimer timer = new DispatcherTimer();
        private readonly DateTime t0 = DateTime.UtcNow;
        private bool loading = true;
        private string phoneKey = "";
        private int tickCount;

        private static Brush B(byte r, byte g, byte b, byte a = 255)
        {
            SolidColorBrush x = new SolidColorBrush(Color.FromArgb(a, r, g, b));
            x.Freeze();
            return x;
        }
        private readonly Brush mint = B(0x1F, 0xD2, 0xAE);
        private readonly Brush rose = B(0xFF, 0x5F, 0xA2);
        private readonly Brush violet = B(0x8C, 0x6B, 0xFF);
        private readonly Brush amber = B(0xF5, 0x9E, 0x0B);
        private readonly Brush grey = B(0x9A, 0xA3, 0xC7);

        // viz
        private readonly List<Path> waves = new List<Path>();
        private readonly List<Rectangle> barsL = new List<Rectangle>();
        private readonly List<Rectangle> barsR = new List<Rectangle>();
        private double sm0, sm1;
        private const double VW = 980, VH = 700;

        // player
        private bool playerOpen;
        private bool settingSeek, settingVol;
        private long seekHold, volHold;
        private double pendingSeek = -1;
        private double pendingVol = -1;
        private long lastVolSend;
        private readonly DispatcherTimer seekTimer = new DispatcherTimer();
        private byte[] coverBytes;
        private Brush coverBrush;
        private static readonly Brush Placeholder = MakePlaceholder();

        private static Brush MakePlaceholder()
        {
            LinearGradientBrush g = new LinearGradientBrush();
            g.StartPoint = new Point(0, 0);
            g.EndPoint = new Point(1, 1);
            g.GradientStops.Add(new GradientStop(Color.FromRgb(0x8C, 0x6B, 0xFF), 0));
            g.GradientStops.Add(new GradientStop(Color.FromRgb(0xFF, 0x5F, 0xA2), 0.6));
            g.GradientStops.Add(new GradientStop(Color.FromRgb(0xFF, 0xB8, 0x6B), 1));
            g.Freeze();
            return g;
        }

        public MainWindow()
        {
            InitializeComponent();
            E.Load();
            E.StartDiscovery();
            PcMedia.I.Start();

            SwWant.IsChecked = E.Want;
            SwAllow.IsChecked = E.Allow;
            SwHealth.IsChecked = E.ShowHealth;
            SwPill.IsChecked = E.PillOn;
            VolA.Value = E.PlayVol * 100.0;
            VolB.Value = E.SendGain * 100.0;
            VolAText.Text = (int)(E.PlayVol * 100) + "%";
            VolBText.Text = (int)(E.SendGain * 100) + "%";
            NudgeS.Value = E.Nudge;
            TxtIp.Text = E.Ip.Length > 0 ? E.Ip + ":" + E.Port : "";
            if (E.DelayMode == 1) DelFast.IsChecked = true; else if (E.DelayMode == 2) DelSteady.IsChecked = true; else DelSmart.IsChecked = true;
            if (E.Viz == 0) VizBars.IsChecked = true; else VizWaves.IsChecked = true;

            FillDevices(OutList, E.OutId);
            FillDevices(CapList, E.CapId);
            BuildViz();
            ShowDelayText();
            ShowNudgeText();
            loading = false;

            seekTimer.Interval = TimeSpan.FromMilliseconds(250);
            seekTimer.Tick += (s, e) =>
            {
                seekTimer.Stop();
                if (pendingSeek >= 0)
                {
                    MediaInfo m = E.ShownMedia();
                    if (m.DurMs > 0) E.Act("seek", (long)(pendingSeek / 1000.0 * m.DurMs));
                    pendingSeek = -1;
                }
            };

            timer.Interval = TimeSpan.FromMilliseconds(40);
            timer.Tick += Tick;
            timer.Start();

            PreviewKeyDown += (s, e) =>
            {
                if (e.Key == Key.Escape && playerOpen) ClosePlayerNow();
            };
            Closing += (s, e) =>
            {
                if (!App.Quitting)
                {
                    e.Cancel = true;
                    Hide();
                }
                else
                {
                    E.Save();
                }
            };

            App.TrayIcon = new Tray();
            App.Pill = new PillWindow();
            if (E.PillOn) App.Pill.Show();
        }

        // ----- window -----
        private void Drag(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed) DragMove();
        }
        private void Minimise(object sender, RoutedEventArgs e) { WindowState = WindowState.Minimized; }
        private void CloseApp(object sender, RoutedEventArgs e) { Close(); }
        private void QuitClick(object sender, RoutedEventArgs e) { App.Quit(); }

        private void TabChanged(object sender, RoutedEventArgs e)
        {
            if (PageSound == null || PageDev == null || PageHealth == null || PageAbout == null || PageTitle == null || TabAbout == null) return;
            PageSound.Visibility = TabSound.IsChecked == true ? Visibility.Visible : Visibility.Collapsed;
            PageDev.Visibility = TabDev.IsChecked == true ? Visibility.Visible : Visibility.Collapsed;
            PageHealth.Visibility = TabHealth.IsChecked == true ? Visibility.Visible : Visibility.Collapsed;
            PageAbout.Visibility = TabAbout.IsChecked == true ? Visibility.Visible : Visibility.Collapsed;
            PageTitle.Text = TabSound.IsChecked == true ? "Now playing" : TabDev.IsChecked == true ? "Devices" : TabHealth.IsChecked == true ? "Health" : "About";
        }

        // ----- the layered waves and bars behind the glass -----
        private static Brush FadeBrush(byte r, byte g, byte b, byte a)
        {
            LinearGradientBrush x = new LinearGradientBrush();
            x.StartPoint = new Point(0, 0);
            x.EndPoint = new Point(0, 1);
            x.GradientStops.Add(new GradientStop(Color.FromArgb(a, r, g, b), 0));
            x.GradientStops.Add(new GradientStop(Color.FromArgb((byte)(a / 4), r, g, b), 1));
            x.Freeze();
            return x;
        }

        private void BuildViz()
        {
            Brush[] fills =
            {
                FadeBrush(0x8C, 0x6B, 0xFF, 0x6A),
                FadeBrush(0x1F, 0xD2, 0xAE, 0x8C),
                FadeBrush(0xFF, 0x5F, 0xA2, 0x8C),
                FadeBrush(0xFF, 0xFF, 0xFF, 0x80)
            };
            foreach (Brush f in fills)
            {
                Path p = new Path { Fill = f };
                VizCanvas.Children.Add(p);
                waves.Add(p);
            }
            int count = 22;
            double gap = 6;
            double bw = (VW / 2 - gap * count) / count;
            for (int side = 0; side < 2; side++)
            {
                for (int i = 0; i < count; i++)
                {
                    Rectangle r = new Rectangle { Width = bw, Height = 4, RadiusX = bw / 2, RadiusY = bw / 2, Fill = side == 0 ? mint : rose, Visibility = Visibility.Collapsed };
                    Canvas.SetLeft(r, side * VW / 2 + gap / 2 + i * (bw + gap));
                    Canvas.SetTop(r, VH * 0.9);
                    VizCanvas.Children.Add(r);
                    (side == 0 ? barsL : barsR).Add(r);
                }
            }
        }

        private void Wave(Path p, double baseFrac, double amp, double freq, double speed, double phase, double t)
        {
            StreamGeometry g = new StreamGeometry();
            using (StreamGeometryContext c = g.Open())
            {
                double y0 = VH * baseFrac;
                c.BeginFigure(new Point(0, VH), true, true);
                for (double x = 0; x <= VW + 12; x += 12)
                {
                    double u = x / VW;
                    double y = y0 + amp * (Math.Sin(u * 6.2832 * freq + t * speed * 2.2 + phase) * 0.7 + Math.Sin(u * 6.2832 * freq * 1.9 - t * speed * 1.4 + phase) * 0.3);
                    c.LineTo(new Point(x, y), true, false);
                }
                c.LineTo(new Point(VW, VH), true, false);
            }
            g.Freeze();
            p.Data = g;
        }

        private void UpdateViz(double t)
        {
            // mint is the PC sound going to the phone, rose is the phone sound arriving here
            sm0 += (E.SendLevel - sm0) * 0.2;
            sm1 += (E.PlayLevel - sm1) * 0.2;
            bool w = E.Viz == 1;
            for (int i = 0; i < waves.Count; i++) waves[i].Visibility = w ? Visibility.Visible : Visibility.Collapsed;
            if (w)
            {
                Wave(waves[0], 0.54, 22, 0.9, 0.5, 0.0, t);
                Wave(waves[1], 0.62, 10 + 52 * sm0, 1.2, 0.8, 1.7, t);
                Wave(waves[2], 0.70, 10 + 52 * sm1, 1.0, -0.7, 3.1, t);
                Wave(waves[3], 0.79, 14, 1.5, 0.6, 4.4, t);
                for (int i = 0; i < barsL.Count; i++) { barsL[i].Visibility = Visibility.Collapsed; barsR[i].Visibility = Visibility.Collapsed; }
            }
            else
            {
                for (int side = 0; side < 2; side++)
                {
                    List<Rectangle> list = side == 0 ? barsL : barsR;
                    double lv = side == 0 ? sm0 : sm1;
                    for (int i = 0; i < list.Count; i++)
                    {
                        double wob = 0.5 + 0.5 * Math.Sin(t * 6.0 + i * 0.9 + side * 1.3) * Math.Sin(t * 2.3 + i * 0.35);
                        double h = Math.Max(4, VH * 0.32 * (0.05 + 0.95 * lv * (0.3 + 0.7 * Math.Abs(wob))));
                        list[i].Height = h;
                        Canvas.SetTop(list[i], VH * 0.9 - h);
                        list[i].Opacity = lv > 0.01 ? 0.65 : 0.28;
                        list[i].Visibility = Visibility.Visible;
                    }
                }
            }
        }

        // ----- devices -----
        private void FillDevices(ListBox lb, string selId)
        {
            List<Dev> devs = Engine.Devices();
            lb.ItemsSource = devs;
            Dev pick = devs.FirstOrDefault(d => d.Id == (selId ?? "")) ?? devs[0];
            lb.SelectedItem = pick;
        }

        private void OutPicked(object sender, SelectionChangedEventArgs e)
        {
            if (loading) return;
            Dev d = OutList.SelectedItem as Dev;
            if (d == null) return;
            E.OutId = d.Id;
            E.Save();
            E.RestartPlayer();
        }

        private void CapPicked(object sender, SelectionChangedEventArgs e)
        {
            if (loading) return;
            Dev d = CapList.SelectedItem as Dev;
            if (d == null) return;
            E.CapId = d.Id;
            E.Save();
            E.RestartCapture();
        }

        // ----- connecting -----
        private void PhonePicked(object sender, SelectionChangedEventArgs e)
        {
            Phone p = PhoneList.SelectedItem as Phone;
            if (p != null) TxtIp.Text = p.Ip + ":" + p.Port;
        }

        private void ConnectClick(object sender, RoutedEventArgs e)
        {
            if (E.Connected)
            {
                E.Disconnect();
                return;
            }
            string text = (TxtIp.Text ?? "").Trim();
            if (text.Length == 0)
            {
                E.Message = "Pick a phone from the list, or type its address.";
                return;
            }
            string ip = text;
            int port = 8765;
            int colon = text.LastIndexOf(':');
            if (colon > 0)
            {
                ip = text.Substring(0, colon);
                int.TryParse(text.Substring(colon + 1), out port);
            }
            E.Connect(ip, port);
        }

        /// <summary>The Connect / Disconnect button at the top.</summary>
        private void LinkClick(object sender, RoutedEventArgs e)
        {
            if (E.State == 0)
            {
                if (!E.HasTarget)
                {
                    TabDev.IsChecked = true;
                    return;
                }
                E.ToggleLink();
            }
            else
            {
                E.Disconnect();
            }
        }

        // ----- choices -----
        private void WantClick(object sender, RoutedEventArgs e) { E.Want = SwWant.IsChecked == true; E.Changed(); }
        private void AllowClick(object sender, RoutedEventArgs e) { E.Allow = SwAllow.IsChecked == true; E.Changed(); }
        private void HealthClick(object sender, RoutedEventArgs e) { E.ShowHealth = SwHealth.IsChecked == true; E.Save(); }
        private void PillClick(object sender, RoutedEventArgs e) { App.SetPill(SwPill.IsChecked == true); }

        private void VolAChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (loading) return;
            E.PlayVol = (float)(VolA.Value / 100.0);
            VolAText.Text = (int)VolA.Value + "%";
            E.Refresh();
        }

        private void VolBChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (loading) return;
            E.SendGain = (float)(VolB.Value / 100.0);
            VolBText.Text = (int)VolB.Value + "%";
            E.Refresh();
        }

        private void MuteClick(object sender, RoutedEventArgs e)
        {
            E.PlayMute = !E.PlayMute;
            BtnMute.Content = E.PlayMute ? "Unmute" : "Mute";
            E.Refresh();
        }

        private void DelayChecked(object sender, RoutedEventArgs e)
        {
            if (loading) return;
            E.DelayMode = DelFast.IsChecked == true ? 1 : DelSteady.IsChecked == true ? 2 : 0;
            E.ResetCushion();
            E.Save();
            ShowDelayText();
        }

        private void VizChecked(object sender, RoutedEventArgs e)
        {
            if (loading) return;
            E.Viz = VizBars.IsChecked == true ? 0 : 1;
            E.Save();
        }

        private void NudgeChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (loading) return;
            int v = (int)NudgeS.Value;
            if (Math.Abs(v) <= 6) v = 0;
            E.Nudge = v;
            E.Cush.Nudge = v;
            E.Save();
            ShowNudgeText();
        }

        private void ShowNudgeText()
        {
            NudgeText.Text = E.Nudge == 0 ? "Centre. Slide left if the phone's sound comes after the picture."
                : E.Nudge < 0 ? "Sound " + (-E.Nudge) + " ms earlier" : "Sound " + E.Nudge + " ms later";
        }

        private void ShowDelayText()
        {
            DelayText.Text = E.DelayMode == 1 ? "Always small. Good for games. A weak signal can crackle."
                : E.DelayMode == 2 ? "Always big and smooth. Best for music alone."
                : "Adjusts itself: small when Wi-Fi is steady, bigger for a moment when it is not.";
        }

        private void ClearErrors(object sender, RoutedEventArgs e) { E.ClearErrors(); }

        // ----- media -----
        private Brush CoverFor(MediaInfo m)
        {
            if (m.CoverJpeg == null) return Placeholder;
            if (ReferenceEquals(m.CoverJpeg, coverBytes) && coverBrush != null) return coverBrush;
            try
            {
                BitmapImage bi = new BitmapImage();
                bi.BeginInit();
                bi.CacheOption = BitmapCacheOption.OnLoad;
                bi.StreamSource = new MemoryStream(m.CoverJpeg);
                bi.EndInit();
                bi.Freeze();
                ImageBrush ib = new ImageBrush(bi);
                ib.Stretch = Stretch.UniformToFill;
                ib.Freeze();
                coverBytes = m.CoverJpeg;
                coverBrush = ib;
                return ib;
            }
            catch
            {
                return Placeholder;
            }
        }

        private string SourceLine(MediaInfo m, bool phone)
        {
            string app = m.App.Length > 0 ? m.App : (phone ? "Phone" : "PC");
            return phone ? app + " on your phone" : app;
        }

        private void UpdateMedia()
        {
            bool phone = E.MediaSource() == 2;
            MediaInfo m = E.ShownMedia();
            MiniTitle.Text = m.Has ? m.Title : "Nothing playing";
            MiniSub.Text = m.Has
                ? SourceLine(m, phone) + (m.Artist.Length > 0 ? "  -  " + m.Artist : "")
                : "Play something on this PC" + (E.Connected ? " or your phone" : "");
            MiniCover.Background = CoverFor(m);
            MiniBadge.Visibility = m.Has ? Visibility.Visible : Visibility.Collapsed;
            MiniBadgeText.Text = m.App.Length > 0 ? m.App.Substring(0, 1).ToUpperInvariant() : "?";
            MiniPlayIcon.Data = (Geometry)FindResource(m.Playing ? "IcoPause" : "IcoPlay");
            double frac = m.DurMs > 0 ? Math.Min(1.0, (double)m.Now() / m.DurMs) : 0;
            MiniFill.Width = Math.Max(0, MiniTrack.ActualWidth * frac);
            MiniFill.Background = phone ? violet : mint;
            if (playerOpen) UpdatePlayer(m, phone);
        }

        private static string Mmss(long ms)
        {
            long s = Math.Max(0, ms / 1000);
            return (s / 60).ToString("00") + ":" + (s % 60).ToString("00");
        }

        private void UpdatePlayer(MediaInfo m, bool phone)
        {
            PTitle.Text = m.Has ? m.Title : "Nothing playing";
            PArtist.Text = m.Has ? (m.Artist.Length > 0 ? m.Artist : SourceLine(m, phone)) : "Start music in any app";
            PSource.Text = m.Has && m.Artist.Length > 0 ? SourceLine(m, phone) : "";
            PCover.Background = CoverFor(m);
            PBadge.Visibility = m.Has ? Visibility.Visible : Visibility.Collapsed;
            PBadgeText.Text = m.App.Length > 0 ? m.App.Substring(0, 1).ToUpperInvariant() : "?";
            SrcIcon.Data = (Geometry)FindResource(phone ? "IcoPhone" : "IcoPc");
            SrcText.Text = E.MediaPick == 0 ? "Auto" : phone ? "Phone" : "PC";
            PPlayIcon.Data = (Geometry)FindResource(m.Playing ? "IcoPause" : "IcoPlay");
            PSeek.Foreground = phone ? violet : mint;

            long now = Environment.TickCount64;
            long pos = m.Now();
            PSeek.IsEnabled = m.DurMs > 0;
            if (now > seekHold)
            {
                settingSeek = true;
                PSeek.Value = m.DurMs > 0 ? Math.Min(1000.0, pos * 1000.0 / m.DurMs) : 0;
                settingSeek = false;
            }
            PPos.Text = Mmss(pos);
            PDur.Text = m.DurMs > 0 ? Mmss(m.DurMs) : "--:--";

            // the add button only when the phone's app really has one
            bool like = phone && m.CanLike;
            PLike.Visibility = like ? Visibility.Visible : Visibility.Hidden;
            PLikeIcon.Data = (Geometry)FindResource(m.Liked ? "IcoCheck" : "IcoPlus");

            if (now > volHold)
            {
                settingVol = true;
                PVol.Value = m.Vol >= 0 ? m.Vol : 50;
                settingVol = false;
            }
        }

        private void MiniPrev(object sender, RoutedEventArgs e) { E.Act("prev"); }
        private void MiniNext(object sender, RoutedEventArgs e) { E.Act("next"); }
        private void MiniPlay(object sender, RoutedEventArgs e) { E.Act("toggle"); }
        private void PLikeClick(object sender, RoutedEventArgs e) { E.SendCmd("like"); }

        private void PickSource(object sender, RoutedEventArgs e)
        {
            // Auto -> this PC -> the phone -> Auto
            E.MediaPick = E.MediaPick == 0 ? 1 : E.MediaPick == 1 ? 2 : 0;
            E.Save();
        }

        private void SeekChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (settingSeek || loading) return;
            seekHold = Environment.TickCount64 + 900;
            pendingSeek = PSeek.Value;
            seekTimer.Stop();
            seekTimer.Start();
        }

        private void PVolChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (settingVol || loading) return;
            volHold = Environment.TickCount64 + 900;
            pendingVol = PVol.Value;
        }

        private void OpenPlayer(object sender, MouseButtonEventArgs e)
        {
            playerOpen = true;
            PlayerLayer.Visibility = Visibility.Visible;
            MainLayer.Effect = new BlurEffect { Radius = 16 };
            UpdateMedia();
        }

        private void ClosePlayerNow()
        {
            playerOpen = false;
            PlayerLayer.Visibility = Visibility.Collapsed;
            MainLayer.Effect = null;
        }

        private void ClosePlayer(object sender, MouseButtonEventArgs e) { ClosePlayerNow(); }
        private void ClosePlayerBtn(object sender, RoutedEventArgs e) { ClosePlayerNow(); }
        private void PanelClick(object sender, MouseButtonEventArgs e) { e.Handled = true; }

        // ----- the heartbeat of the window -----
        private void Tick(object sender, EventArgs e)
        {
            if (!IsVisible) return;
            double t = (DateTime.UtcNow - t0).TotalSeconds;
            UpdateViz(t);
            tickCount++;

            if (pendingVol >= 0 && Environment.TickCount64 - lastVolSend >= 80)
            {
                E.Act("vol", (long)pendingVol);
                pendingVol = -1;
                lastVolSend = Environment.TickCount64;
            }

            if (tickCount % 3 != 0) return;
            UpdateMedia();

            int st = E.State;
            StatusPill.Text = st == 2 ? "Connected to " + E.PeerName : st == 1 ? (E.Connecting ? "Connecting..." : "Reconnecting...") : "Off";
            StatusDot.Fill = st == 2 ? mint : st == 1 ? amber : grey;
            BtnLink.Content = st == 2 ? "Disconnect" : st == 1 ? "Stop" : "Connect";

            if (E.Connected)
            {
                StatusText.Text = "Connected to " + E.PeerName;
                BtnConnect.Content = "Disconnect";
                BtnConnect.Style = (Style)FindResource("PillAlt");
            }
            else
            {
                StatusText.Text = E.Connecting ? "Connecting..." : (E.Message.Length > 0 ? E.Message : "Pick your phone and press Connect.");
                BtnConnect.Content = E.Connecting ? "Connecting..." : "Connect";
                BtnConnect.Style = (Style)FindResource("Pill");
                BtnConnect.IsEnabled = !E.Connecting;
            }

            // phones list, only rebuilt when it changes
            List<Phone> ph = E.Phones();
            string key = string.Join(",", ph.Select(p => p.Ip + p.Name + p.Port));
            if (key != phoneKey)
            {
                phoneKey = key;
                string selIp = (PhoneList.SelectedItem as Phone) != null ? ((Phone)PhoneList.SelectedItem).Ip : null;
                PhoneList.ItemsSource = ph;
                if (selIp != null) PhoneList.SelectedItem = ph.FirstOrDefault(p => p.Ip == selIp);
            }

            // direction texts
            if (!E.Connected) WantText.Text = "Waiting for the phone.";
            else if (!E.Want) WantText.Text = "Off.";
            else if (!E.PeerAllow) WantText.Text = "The phone is not sharing. Switch on Share on the phone.";
            else WantText.Text = "Playing from " + E.PeerName + ".";

            if (!E.Connected) AllowText.Text = "Waiting for the phone.";
            else if (!E.Allow) AllowText.Text = "Off.";
            else if (!E.PeerWant) AllowText.Text = "The phone is not listening. Switch on Play on the phone.";
            else AllowText.Text = "Sending to " + E.PeerName + ".";

            EchoText.Visibility = E.EchoRisk ? Visibility.Visible : Visibility.Collapsed;

            if (E.Connected && E.Want && E.PeerAllow) ShowDelayText2(); else ShowDelayText();

            // health
            HealthBody.Visibility = E.ShowHealth ? Visibility.Visible : Visibility.Collapsed;
            if (E.ShowHealth)
            {
                int est = E.RttMs / 2 + E.BufMs + 40 + 10;
                StatsText.Text =
                    "Network round trip     " + E.RttMs + " ms\n" +
                    "Cushion goal (smart)   " + E.TargetMs + " ms\n" +
                    "Sound waiting in line  " + E.BufMs + " ms\n" +
                    "Estimated delay        " + est + " ms\n" +
                    "Hiccups it learned     " + E.Underruns + "\n" +
                    "Times it caught up     " + E.Dropped + "\n" +
                    "Sent to phone          " + E.SentKb + " KB\n" +
                    "Received from phone    " + E.RecvKb + " KB";
                string[] errs = E.Errors();
                ErrText.Text = errs.Length == 0 ? "No errors. Good." : string.Join("\n", errs.Take(12));
                ErrText.Foreground = errs.Length == 0 ? (Brush)FindResource("GoodBrush") : (Brush)FindResource("WarmBrush");
            }
        }

        private void ShowDelayText2()
        {
            string baseText = E.DelayMode == 1 ? "Always small. Good for games. A weak signal can crackle."
                : E.DelayMode == 2 ? "Always big and smooth. Best for music alone."
                : "Adjusts itself: small when Wi-Fi is steady, bigger for a moment when it is not.";
            DelayText.Text = baseText + "\nCushion right now: " + E.TargetMs + " ms";
        }
    }
}

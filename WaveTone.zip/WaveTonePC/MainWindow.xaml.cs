using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace WaveTonePC
{
    public partial class MainWindow : Window
    {
        private readonly Engine E = Engine.I;
        private readonly List<Rectangle> eqL = new List<Rectangle>();
        private readonly List<Rectangle> eqR = new List<Rectangle>();
        private readonly List<Rectangle> barsA = new List<Rectangle>();
        private readonly List<Rectangle> barsB = new List<Rectangle>();
        private readonly DispatcherTimer timer = new DispatcherTimer();
        private readonly DateTime t0 = DateTime.UtcNow;
        private bool loading = true;
        private string phoneKey = "";
        private readonly Brush mint = new SolidColorBrush(Color.FromRgb(0x5E, 0xEA, 0xD4));
        private readonly Brush rose = new SolidColorBrush(Color.FromRgb(0xFF, 0x7A, 0xB6));
        private readonly Brush dim = new SolidColorBrush(Color.FromArgb(0x55, 0xB0, 0xA8, 0xE0));

        public MainWindow()
        {
            InitializeComponent();
            E.Load();
            E.StartDiscovery();

            SwWant.IsChecked = E.Want;
            SwAllow.IsChecked = E.Allow;
            SwHealth.IsChecked = E.ShowHealth;
            VolA.Value = E.PlayVol * 100.0;
            VolB.Value = E.SendGain * 100.0;
            VolAText.Text = (int)(E.PlayVol * 100) + "%";
            VolBText.Text = (int)(E.SendGain * 100) + "%";
            TxtIp.Text = E.Ip;

            FillDevices(OutList, E.OutId);
            FillDevices(CapList, E.CapId);
            MakeBars(Eq, eqL, 9, 0.0, mint);
            MakeBars(Eq, eqR, 9, 134.0, rose);
            MakeBars(BarsA, barsA, 40, 0.0, rose);
            MakeBars(BarsB, barsB, 40, 0.0, mint);
            ShowLatency();
            loading = false;

            timer.Interval = TimeSpan.FromMilliseconds(40);
            timer.Tick += Tick;
            timer.Start();
            Closing += (s, e) =>
            {
                E.Save();
                E.Disconnect();
            };
        }

        // ----- window -----
        private void Drag(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed) DragMove();
        }
        private void Minimise(object sender, RoutedEventArgs e) { WindowState = WindowState.Minimized; }
        private void CloseApp(object sender, RoutedEventArgs e) { Close(); }

        // ----- bars -----
        private void MakeBars(Canvas c, List<Rectangle> list, int count, double x0, Brush fill)
        {
            double w = c == Eq ? 8 : 5;
            double gap = c == Eq ? 6 : 4;
            for (int i = 0; i < count; i++)
            {
                Rectangle r = new Rectangle { Width = w, Height = 3, RadiusX = w / 2, RadiusY = w / 2, Fill = fill };
                Canvas.SetLeft(r, x0 + i * (w + gap));
                Canvas.SetBottom(r, 0);
                c.Children.Add(r);
                list.Add(r);
            }
        }

        private void Animate(List<Rectangle> bars, double level, double height, double t)
        {
            for (int i = 0; i < bars.Count; i++)
            {
                double wob = 0.5 + 0.5 * Math.Sin(t * 6.0 + i * 0.9) * Math.Sin(t * 2.3 + i * 0.35);
                double h = height * (0.08 + 0.92 * level * (0.35 + 0.65 * Math.Abs(wob)));
                bars[i].Height = Math.Max(3, h);
                bars[i].Opacity = level > 0.01 ? 1.0 : 0.3;
            }
        }

        // ----- devices -----
        private void FillDevices(ListBox lb, string selId)
        {
            List<Dev> devs = Engine.Devices();
            lb.ItemsSource = devs;
            Dev pick = devs.FirstOrDefault(d => d.Id == (selId ?? "")) ?? devs[0];
            lb.SelectedItem = pick;
        }

        private void OutPicked(object sender, SelectionChangedEventArgs e)
        {
            if (loading) return;
            Dev d = OutList.SelectedItem as Dev;
            if (d == null) return;
            E.OutId = d.Id;
            E.Save();
            E.RestartPlayer();
        }

        private void CapPicked(object sender, SelectionChangedEventArgs e)
        {
            if (loading) return;
            Dev d = CapList.SelectedItem as Dev;
            if (d == null) return;
            E.CapId = d.Id;
            E.Save();
            E.RestartCapture();
        }

        // ----- connecting -----
        private void PhonePicked(object sender, SelectionChangedEventArgs e)
        {
            Phone p = PhoneList.SelectedItem as Phone;
            if (p != null) TxtIp.Text = p.Ip + ":" + p.Port;
        }

        private void ConnectClick(object sender, RoutedEventArgs e)
        {
            if (E.Connected)
            {
                E.Disconnect();
                return;
            }
            string text = (TxtIp.Text ?? "").Trim();
            if (text.Length == 0)
            {
                E.Message = "Pick a phone from the list, or type its address.";
                return;
            }
            string ip = text;
            int port = 8765;
            int colon = text.LastIndexOf(':');
            if (colon > 0)
            {
                ip = text.Substring(0, colon);
                int.TryParse(text.Substring(colon + 1), out port);
            }
            E.Connect(ip, port);
        }

        // ----- choices -----
        private void WantClick(object sender, RoutedEventArgs e)
        {
            E.Want = SwWant.IsChecked == true;
            E.Changed();
        }

        private void AllowClick(object sender, RoutedEventArgs e)
        {
            E.Allow = SwAllow.IsChecked == true;
            E.Changed();
        }

        private void HealthClick(object sender, RoutedEventArgs e)
        {
            E.ShowHealth = SwHealth.IsChecked == true;
            E.Save();
        }

        private void VolAChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (loading) return;
            E.PlayVol = (float)(VolA.Value / 100.0);
            VolAText.Text = (int)VolA.Value + "%";
            E.Refresh();
        }

        private void VolBChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (loading) return;
            E.SendGain = (float)(VolB.Value / 100.0);
            VolBText.Text = (int)VolB.Value + "%";
            E.Refresh();
        }

        private void MuteClick(object sender, RoutedEventArgs e)
        {
            E.PlayMute = !E.PlayMute;
            BtnMute.Content = E.PlayMute ? "Unmute" : "Mute";
            E.Refresh();
        }

        private void LatLow(object sender, RoutedEventArgs e) { SetLatency(60); }
        private void LatBal(object sender, RoutedEventArgs e) { SetLatency(120); }
        private void LatHigh(object sender, RoutedEventArgs e) { SetLatency(250); }

        private void SetLatency(int ms)
        {
            E.LatencyMs = ms;
            E.Changed();
            E.RestartPlayer();
            ShowLatency();
        }

        private void ShowLatency()
        {
            Brush on = (Brush)FindResource("AccBrush");
            Brush off = (Brush)FindResource("TrackBrush");
            Border b1 = (Border)BtnLow.Template.FindName("bd", BtnLow);
            Border b2 = (Border)BtnBal.Template.FindName("bd", BtnBal);
            Border b3 = (Border)BtnHigh.Template.FindName("bd", BtnHigh);
            if (b1 != null) b1.Background = E.LatencyMs <= 60 ? on : off;
            if (b2 != null) b2.Background = (E.LatencyMs > 60 && E.LatencyMs < 250) ? on : off;
            if (b3 != null) b3.Background = E.LatencyMs >= 250 ? on : off;
            LatText.Text = E.LatencyMs <= 60
                ? "Fastest. Good for games and calls. A weak signal can crackle."
                : E.LatencyMs >= 250 ? "Slowest but smoothest. Best for music." : "A good balance.";
        }

        private void ClearErrors(object sender, RoutedEventArgs e) { E.ClearErrors(); }

        // ----- the heartbeat of the window -----
        private int tickCount;

        private void Tick(object sender, EventArgs e)
        {
            double t = (DateTime.UtcNow - t0).TotalSeconds;
            Animate(eqL, E.SendLevel, 44, t);
            Animate(eqR, E.PlayLevel, 44, t);
            Animate(barsA, E.PlayLevel, 34, t);
            Animate(barsB, E.SendLevel, 34, t);
            tickCount++;
            if (tickCount % 3 != 0) return;

            // latency buttons get their colours once the template exists
            if (tickCount % 30 == 0) ShowLatency();

            // status
            if (E.Connected)
            {
                StatusText.Text = "Connected to " + E.PeerName;
                BtnConnect.Content = "Disconnect";
                BtnConnect.Style = (Style)FindResource("PillAlt");
            }
            else
            {
                StatusText.Text = E.Connecting ? "Connecting..." : (E.Message.Length > 0 ? E.Message : "Pick your phone and press Connect.");
                BtnConnect.Content = E.Connecting ? "Connecting..." : "Connect";
                BtnConnect.Style = (Style)FindResource("Pill");
                BtnConnect.IsEnabled = !E.Connecting;
            }

            // phones list, only rebuilt when it changes
            List<Phone> ph = E.Phones();
            string key = string.Join(",", ph.Select(p => p.Ip + p.Name + p.Port));
            if (key != phoneKey)
            {
                phoneKey = key;
                string selIp = (PhoneList.SelectedItem as Phone) != null ? ((Phone)PhoneList.SelectedItem).Ip : null;
                PhoneList.ItemsSource = ph;
                if (selIp != null) PhoneList.SelectedItem = ph.FirstOrDefault(p => p.Ip == selIp);
            }

            // direction texts
            if (!E.Connected) WantText.Text = "Waiting for the phone.";
            else if (!E.Want) WantText.Text = "Off.";
            else if (!E.PeerAllow) WantText.Text = "The phone is not sharing. Switch on Share on the phone.";
            else WantText.Text = "Playing from " + E.PeerName + ".";

            if (!E.Connected) AllowText.Text = "Waiting for the phone.";
            else if (!E.Allow) AllowText.Text = "Off.";
            else if (!E.PeerWant) AllowText.Text = "The phone is not listening. Switch on Play on the phone.";
            else AllowText.Text = "Sending to " + E.PeerName + ".";

            EchoText.Visibility = E.EchoRisk ? Visibility.Visible : Visibility.Collapsed;

            // health
            HealthBody.Visibility = E.ShowHealth ? Visibility.Visible : Visibility.Collapsed;
            if (E.ShowHealth)
            {
                int est = E.RttMs / 2 + E.BufMs + Math.Max(30, E.LatencyMs / 2) + 10;
                StatsText.Text =
                    "Network round trip     " + E.RttMs + " ms\n" +
                    "Cushion in use         " + E.BufMs + " ms\n" +
                    "Estimated delay        " + est + " ms\n" +
                    "Times it caught up     " + E.Dropped + "\n" +
                    "Sent to phone          " + E.SentKb + " KB\n" +
                    "Received from phone    " + E.RecvKb + " KB";
                string[] errs = E.Errors();
                ErrText.Text = errs.Length == 0 ? "No errors. Good." : string.Join("\n", errs.Take(12));
                ErrText.Foreground = errs.Length == 0 ? (Brush)FindResource("GoodBrush") : (Brush)FindResource("WarmBrush");
            }
        }
    }
}

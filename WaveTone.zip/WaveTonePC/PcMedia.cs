using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;
using NAudio.CoreAudioApi;
using Windows.Media.Control;

namespace WaveTonePC
{
    /// <summary>
    /// Reads what plays on this PC (Spotify, a browser, the media player...) through Windows media controls,
    /// and presses its buttons. Also sets the PC's main volume.
    /// </summary>
    public sealed class PcMedia
    {
        public static readonly PcMedia I = new PcMedia();
        private GlobalSystemMediaTransportControlsSessionManager mgr;
        private GlobalSystemMediaTransportControlsSession cur;
        private int lastKey;
        private byte[] lastJpeg;
        private string lastSig = "";
        private long lastPush;
        private bool started;

        public void Start()
        {
            if (started) return;
            started = true;
            Task.Run(Loop);
        }

        private async Task Loop()
        {
            try
            {
                mgr = await mgr0().ConfigureAwait(false);
            }
            catch (Exception e)
            {
                Engine.I.LogErr("Windows media controls: " + e.Message);
                return;
            }
            while (true)
            {
                try { await Tick().ConfigureAwait(false); }
                catch (Exception e) { Engine.I.LogErr("Media: " + e.Message); }
                await Task.Delay(600).ConfigureAwait(false);
            }
        }

        private static Task<GlobalSystemMediaTransportControlsSessionManager> mgr0()
        {
            return GlobalSystemMediaTransportControlsSessionManager.RequestAsync().AsTask();
        }

        private static string Friendly(string id)
        {
            if (string.IsNullOrEmpty(id)) return "PC";
            string s = id;
            int bang = s.LastIndexOf('!');
            if (bang >= 0 && bang + 1 < s.Length) s = s.Substring(bang + 1);
            if (s.EndsWith(".exe", StringComparison.OrdinalIgnoreCase)) s = s.Substring(0, s.Length - 4);
            int dot = s.LastIndexOf('.');
            if (dot >= 0 && dot + 1 < s.Length) s = s.Substring(dot + 1);
            string l = s.ToLowerInvariant();
            if (l == "chrome") return "Chrome";
            if (l == "msedge") return "Edge";
            if (l == "firefox") return "Firefox";
            if (l == "spotify") return "Spotify";
            if (l.Contains("zunemusic") || l.Contains("mediaplayer")) return "Media Player";
            if (l == "vlc") return "VLC";
            if (l == "brave") return "Brave";
            if (s.Length == 0) return "PC";
            return char.ToUpperInvariant(s[0]) + s.Substring(1);
        }

        private async Task Tick()
        {
            if (mgr == null) return;
            GlobalSystemMediaTransportControlsSession s = null;
            foreach (GlobalSystemMediaTransportControlsSession x in mgr.GetSessions())
            {
                if (x.GetPlaybackInfo().PlaybackStatus == GlobalSystemMediaTransportControlsSessionPlaybackStatus.Playing)
                {
                    s = x;
                    break;
                }
            }
            if (s == null) s = mgr.GetCurrentSession();
            cur = s;
            if (s == null)
            {
                if (Engine.I.LocalMedia.Has) Engine.I.SetLocalMedia(new MediaInfo());
                lastSig = "";
                return;
            }

            GlobalSystemMediaTransportControlsSessionMediaProperties props = await s.TryGetMediaPropertiesAsync().AsTask().ConfigureAwait(false);
            string title = props.Title ?? "";
            string artist = props.Artist;
            if (string.IsNullOrEmpty(artist)) artist = props.AlbumArtist ?? "";
            string app = Friendly(s.SourceAppUserModelId);
            var pb = s.GetPlaybackInfo();
            var tl = s.GetTimelineProperties();
            bool playing = pb.PlaybackStatus == GlobalSystemMediaTransportControlsSessionPlaybackStatus.Playing;

            int key = (title + "|" + artist + "|" + app).GetHashCode();
            if (key == 0) key = 1;
            if (key != lastKey)
            {
                lastKey = key;
                lastJpeg = null;
                try
                {
                    var tr = props.Thumbnail;
                    if (tr != null)
                    {
                        using (var rs = await tr.OpenReadAsync().AsTask().ConfigureAwait(false))
                        using (var ms = new MemoryStream())
                        {
                            await rs.AsStreamForRead().CopyToAsync(ms).ConfigureAwait(false);
                            lastJpeg = ToJpeg(ms.ToArray());
                        }
                    }
                }
                catch { lastJpeg = null; }
            }

            long pos = (long)tl.Position.TotalMilliseconds;
            long dur = (long)(tl.EndTime - tl.StartTime).TotalMilliseconds;
            if (dur < 0) dur = 0;
            if (playing)
            {
                // Position was true at LastUpdatedTime; catch up to now
                double ago = (DateTimeOffset.UtcNow - tl.LastUpdatedTime).TotalMilliseconds;
                if (ago > 0 && ago < 3600000) pos += (long)ago;
            }
            if (dur > 0 && pos > dur) pos = dur;
            if (pos < 0) pos = 0;

            MediaInfo m = new MediaInfo
            {
                Title = title, Artist = artist, App = app, Playing = playing,
                PosMs = pos, DurMs = dur, PosAt = Environment.TickCount64,
                CanLike = false, Vol = GetVolume(), CoverKey = lastJpeg != null ? key : 0, CoverJpeg = lastJpeg
            };
            string sig = title + "|" + artist + "|" + playing + "|" + (lastJpeg != null) + "|" + dur;
            long now = Environment.TickCount64;
            bool force = sig != lastSig || now - lastPush > 3000;
            Engine.I.SetLocalMedia(m, force);
            if (force)
            {
                lastSig = sig;
                lastPush = now;
            }
        }

        private static byte[] ToJpeg(byte[] src)
        {
            try
            {
                BitmapImage bi = new BitmapImage();
                bi.BeginInit();
                bi.CacheOption = BitmapCacheOption.OnLoad;
                bi.StreamSource = new MemoryStream(src);
                bi.DecodePixelWidth = 320;
                bi.EndInit();
                bi.Freeze();
                JpegBitmapEncoder enc = new JpegBitmapEncoder();
                enc.QualityLevel = 82;
                enc.Frames.Add(BitmapFrame.Create(bi));
                using (MemoryStream o = new MemoryStream())
                {
                    enc.Save(o);
                    return o.ToArray();
                }
            }
            catch
            {
                return null;
            }
        }

        /// <summary>Presses a button on this PC's media.</summary>
        public async void Command(string cmd, long v)
        {
            try
            {
                if (cmd == "vol")
                {
                    SetVolume((int)v);
                    return;
                }
                GlobalSystemMediaTransportControlsSession s = cur;
                if (s == null) return;
                switch (cmd)
                {
                    case "toggle": await s.TryTogglePlayPauseAsync().AsTask(); break;
                    case "play": await s.TryPlayAsync().AsTask(); break;
                    case "pause": await s.TryPauseAsync().AsTask(); break;
                    case "next": await s.TrySkipNextAsync().AsTask(); break;
                    case "prev": await s.TrySkipPreviousAsync().AsTask(); break;
                    case "seek": await s.TryChangePlaybackPositionAsync(v * 10000L).AsTask(); break;
                }
            }
            catch (Exception e)
            {
                Engine.I.LogErr("Media button: " + e.Message);
            }
        }

        public static int GetVolume()
        {
            try
            {
                using (MMDeviceEnumerator en = new MMDeviceEnumerator())
                using (MMDevice d = en.GetDefaultAudioEndpoint(DataFlow.Render, Role.Multimedia))
                {
                    return (int)Math.Round(d.AudioEndpointVolume.MasterVolumeLevelScalar * 100f);
                }
            }
            catch
            {
                return -1;
            }
        }

        public static void SetVolume(int pct)
        {
            try
            {
                using (MMDeviceEnumerator en = new MMDeviceEnumerator())
                using (MMDevice d = en.GetDefaultAudioEndpoint(DataFlow.Render, Role.Multimedia))
                {
                    d.AudioEndpointVolume.MasterVolumeLevelScalar = Math.Max(0, Math.Min(100, pct)) / 100f;
                }
            }
            catch
            {
            }
        }
    }
}

using System;
using System.Diagnostics;

namespace WaveTonePC
{
    /// <summary>The little icon by the clock. Left click opens the window; right click gives the menu.</summary>
    public sealed class Tray : IDisposable
    {
        private readonly System.Windows.Forms.NotifyIcon ni;
        private readonly System.Windows.Forms.ToolStripMenuItem miPill;
        private readonly System.Windows.Forms.ToolStripMenuItem miLink;

        public Tray()
        {
            ni = new System.Windows.Forms.NotifyIcon();
            try
            {
                string exe = Environment.ProcessPath;
                if (!string.IsNullOrEmpty(exe)) ni.Icon = System.Drawing.Icon.ExtractAssociatedIcon(exe);
            }
            catch { }
            if (ni.Icon == null) ni.Icon = System.Drawing.SystemIcons.Application;
            ni.Text = "WaveTone";

            System.Windows.Forms.ContextMenuStrip menu = new System.Windows.Forms.ContextMenuStrip();
            System.Windows.Forms.ToolStripMenuItem open = new System.Windows.Forms.ToolStripMenuItem("Open WaveTone");
            open.Click += (s, e) => App.ShowMain();
            miLink = new System.Windows.Forms.ToolStripMenuItem("Connect");
            miLink.Click += (s, e) => Engine.I.ToggleLink();
            miPill = new System.Windows.Forms.ToolStripMenuItem("Floating pill");
            miPill.Click += (s, e) => App.SetPill(!Engine.I.PillOn);
            System.Windows.Forms.ToolStripMenuItem quit = new System.Windows.Forms.ToolStripMenuItem("Quit WaveTone");
            quit.Click += (s, e) => App.Quit();
            menu.Items.Add(open);
            menu.Items.Add(miLink);
            menu.Items.Add(miPill);
            menu.Items.Add(new System.Windows.Forms.ToolStripSeparator());
            menu.Items.Add(quit);
            menu.Opening += (s, e) =>
            {
                miLink.Text = Engine.I.Connected ? "Disconnect" : "Connect";
                miPill.Checked = Engine.I.PillOn;
            };
            ni.ContextMenuStrip = menu;
            ni.MouseClick += (s, e) =>
            {
                if (e.Button == System.Windows.Forms.MouseButtons.Left) App.ShowMain();
            };
            ni.Visible = true;
        }

        public void Dispose()
        {
            try
            {
                ni.Visible = false;
                ni.Dispose();
            }
            catch { }
        }
    }
}

; Makes WaveTone-Setup.exe, a normal Windows installer (no admin rights needed)
[Setup]
AppId={{8F2B5C0E-7A3D-4C71-9E55-0A1B2C3D4E5F}
AppName=WaveTone
AppVersion=2.1
AppPublisher=BreadWinner
DefaultDirName={autopf}\WaveTone
DefaultGroupName=WaveTone
PrivilegesRequired=lowest
OutputDir=..\setupout
OutputBaseFilename=WaveTone-Setup
SetupIconFile=wavetone.ico
UninstallDisplayIcon={app}\WaveTone.exe
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
DisableProgramGroupPage=yes
CloseApplications=force

[Tasks]
Name: "desktopicon"; Description: "Put a WaveTone icon on the Desktop"; GroupDescription: "Shortcuts:"
Name: "autostart"; Description: "Start WaveTone quietly when Windows starts"; GroupDescription: "Extras:"; Flags: unchecked

[Files]
Source: "..\pcout\WaveTone.exe"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\WaveTone"; Filename: "{app}\WaveTone.exe"
Name: "{group}\Uninstall WaveTone"; Filename: "{uninstallexe}"
Name: "{autodesktop}\WaveTone"; Filename: "{app}\WaveTone.exe"; Tasks: desktopicon

[Registry]
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; ValueType: string; ValueName: "WaveTone"; ValueData: """{app}\WaveTone.exe"" --tray"; Tasks: autostart; Flags: uninsdeletevalue

[Run]
Filename: "{app}\WaveTone.exe"; Description: "Open WaveTone now"; Flags: nowait postinstall skipifsilent

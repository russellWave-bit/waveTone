using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading;
using NAudio.CoreAudioApi;
using NAudio.Wave;
using NAudio.Wave.SampleProviders;

namespace WaveTonePC
{
    public sealed class Phone
    {
        public string Name;
        public string Ip;
        public int Port;
        public DateTime Seen;
        public string Label { get { return Name + "   " + Ip; } }
    }

    public sealed class Dev
    {
        public string Id;
        public string Name;
        public override string ToString() { return Name; }
    }

    public sealed class Settings
    {
        public string Ip { get; set; } = "";
        public int Latency { get; set; } = 120;
        public bool Want { get; set; } = true;
        public bool Allow { get; set; } = true;
        public double PlayVol { get; set; } = 1.0;
        public double SendGain { get; set; } = 1.0;
        public bool ShowHealth { get; set; } = true;
        public string OutId { get; set; } = "";
        public string CapId { get; set; } = "";
    }

    /// <summary>Finds the phone, keeps the link, and moves sound both ways.</summary>
    public sealed class Engine
    {
        public static readonly Engine I = new Engine();
        private const int Rate = 48000;
        private const int Chunk = 1920; // 10 ms of 48 kHz stereo 16-bit

        // what you choose here
        public volatile bool Want = true;      // play the phone's sound on this PC
        public volatile bool Allow = true;     // let the phone hear this PC
        public int LatencyMs = 120;
        public float PlayVol = 1f;
        public bool PlayMute;
        public float SendGain = 1f;
        public bool ShowHealth = true;
        public string OutId = "";
        public string CapId = "";
        public string Ip = "";

        // the phone on the other end
        public volatile bool Connected;
        public volatile bool Connecting;
        public string PeerName = "";
        public volatile bool PeerWant;
        public volatile bool PeerAllow;

        // live numbers
        public volatile float PlayLevel;
        public volatile float SendLevel;
        public int RttMs;
        public int BufMs;
        public int Dropped;
        public long SentKb;
        public long RecvKb;
        public string Message = "";

        private readonly Dictionary<string, Phone> phones = new Dictionary<string, Phone>();
        private readonly object plock = new object();
        private readonly List<string> errors = new List<string>();
        private Link link;
        private UdpClient udp;
        private bool discoveryOn;

        private readonly object playLock = new object();
        private WasapiOut player;
        private BufferedWaveProvider bwp;
        private VolumeSampleProvider pvol;
        private bool primed;

        private readonly object capLock = new object();
        private WasapiLoopbackCapture cap;
        private BufferedWaveProvider cbw;
        private IWaveProvider conv;
        private VolumeSampleProvider cvol;

        private static string SettingsPath
        {
            get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "WaveTone", "settings.json"); }
        }

        public void Load()
        {
            try
            {
                if (!File.Exists(SettingsPath)) return;
                Settings s = JsonSerializer.Deserialize<Settings>(File.ReadAllText(SettingsPath));
                if (s == null) return;
                Ip = s.Ip ?? "";
                LatencyMs = s.Latency;
                Want = s.Want;
                Allow = s.Allow;
                PlayVol = (float)s.PlayVol;
                SendGain = (float)s.SendGain;
                ShowHealth = s.ShowHealth;
                OutId = s.OutId ?? "";
                CapId = s.CapId ?? "";
            }
            catch { }
        }

        public void Save()
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(SettingsPath));
                Settings s = new Settings
                {
                    Ip = Ip, Latency = LatencyMs, Want = Want, Allow = Allow, PlayVol = PlayVol,
                    SendGain = SendGain, ShowHealth = ShowHealth, OutId = OutId, CapId = CapId
                };
                File.WriteAllText(SettingsPath, JsonSerializer.Serialize(s));
            }
            catch { }
        }

        public void LogErr(string msg)
        {
            lock (errors)
            {
                errors.Insert(0, DateTime.Now.ToString("HH:mm:ss") + "  " + msg);
                while (errors.Count > 60) errors.RemoveAt(errors.Count - 1);
            }
        }

        public string[] Errors()
        {
            lock (errors) { return errors.ToArray(); }
        }

        public void ClearErrors()
        {
            lock (errors) { errors.Clear(); }
        }

        // ---------- finding the phone ----------

        public void StartDiscovery()
        {
            if (discoveryOn) return;
            discoveryOn = true;
            Thread t = new Thread(DiscoverLoop);
            t.IsBackground = true;
            t.Start();
        }

        private void DiscoverLoop()
        {
            try
            {
                udp = new UdpClient();
                udp.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
                udp.Client.Bind(new IPEndPoint(IPAddress.Any, 8766));
                IPEndPoint any = new IPEndPoint(IPAddress.Any, 0);
                while (true)
                {
                    byte[] data = udp.Receive(ref any);
                    string s = Encoding.UTF8.GetString(data);
                    string[] p = s.Split('|');
                    if (p.Length < 3 || p[0] != "WAVETONE") continue;
                    int port;
                    if (!int.TryParse(p[2], out port)) continue;
                    string ip = any.Address.ToString();
                    lock (plock)
                    {
                        phones[ip] = new Phone { Name = p[1], Ip = ip, Port = port, Seen = DateTime.UtcNow };
                    }
                }
            }
            catch (Exception e)
            {
                LogErr("Finding phones: " + e.Message);
            }
        }

        public List<Phone> Phones()
        {
            lock (plock)
            {
                List<string> dead = new List<string>();
                foreach (KeyValuePair<string, Phone> kv in phones)
                {
                    if ((DateTime.UtcNow - kv.Value.Seen).TotalSeconds > 5) dead.Add(kv.Key);
                }
                foreach (string k in dead) phones.Remove(k);
                return new List<Phone>(phones.Values);
            }
        }

        // ---------- the link ----------

        public void Connect(string ip, int port)
        {
            if (Connected || Connecting) return;
            Connecting = true;
            Message = "Connecting...";
            Thread t = new Thread(() => RunLink(ip, port));
            t.IsBackground = true;
            t.Start();
        }

        public void Disconnect()
        {
            Link l = link;
            if (l != null) l.Close();
        }

        private void RunLink(string ip, int port)
        {
            TcpClient c = new TcpClient();
            try
            {
                IAsyncResult ar = c.BeginConnect(ip, port, null, null);
                if (!ar.AsyncWaitHandle.WaitOne(4000))
                {
                    c.Close();
                    Message = "Could not reach the phone. Check it is on and on the same Wi-Fi.";
                    Connecting = false;
                    return;
                }
                c.EndConnect(ar);
                c.NoDelay = true;
                c.ReceiveTimeout = 9000;
            }
            catch (Exception e)
            {
                Message = "Could not connect: " + e.Message;
                Connecting = false;
                return;
            }

            Link l = new Link(c);
            link = l;
            Ip = ip;
            Dropped = 0;
            SentKb = 0;
            RecvKb = 0;
            Connected = true;
            Connecting = false;
            Message = "";
            Save();
            SendControl();

            Thread pinger = new Thread(() =>
            {
                while (l.Alive)
                {
                    l.Send(3, BitConverter.GetBytes(Stopwatch.GetTimestamp()));
                    Thread.Sleep(2000);
                }
            });
            pinger.IsBackground = true;
            pinger.Start();

            l.ReadLoop((t, b) => OnFrame(l, t, b));

            link = null;
            Connected = false;
            PeerName = "";
            PeerWant = false;
            PeerAllow = false;
            RttMs = 0;
            StopCapture();
            StopPlayer();
            Message = "Disconnected.";
        }

        private void OnFrame(Link l, byte type, byte[] b)
        {
            switch (type)
            {
                case 1:
                    try
                    {
                        using (JsonDocument d = JsonDocument.Parse(b))
                        {
                            JsonElement r = d.RootElement;
                            JsonElement v;
                            if (r.TryGetProperty("name", out v)) PeerName = v.GetString();
                            if (r.TryGetProperty("want", out v)) PeerWant = v.GetBoolean();
                            if (r.TryGetProperty("allow", out v)) PeerAllow = v.GetBoolean();
                        }
                        Refresh();
                    }
                    catch (Exception e)
                    {
                        LogErr("Bad message from the phone: " + e.Message);
                    }
                    break;
                case 2:
                    OnAudio(b);
                    break;
                case 3:
                    l.Send(4, b);
                    break;
                case 4:
                    if (b.Length == 8)
                    {
                        long sent = BitConverter.ToInt64(b, 0);
                        RttMs = (int)((Stopwatch.GetTimestamp() - sent) * 1000L / Stopwatch.Frequency);
                    }
                    break;
            }
        }

        public void SendControl()
        {
            Link l = link;
            if (l == null) return;
            string json = JsonSerializer.Serialize(new { name = Environment.MachineName, want = Want, allow = Allow, latency = LatencyMs });
            l.Send(1, Encoding.UTF8.GetBytes(json));
        }

        /// <summary>Called after any choice changes: tell the phone, then start or stop each direction.</summary>
        public void Changed()
        {
            Save();
            SendControl();
            Refresh();
        }

        public void Refresh()
        {
            Link l = link;
            bool play = l != null && Want && PeerAllow;
            bool send = l != null && Allow && PeerWant;
            if (play) StartPlayer(); else StopPlayer();
            if (send) StartCapture(); else StopCapture();
            if (pvol != null) pvol.Volume = PlayMute ? 0f : PlayVol;
            if (cvol != null) cvol.Volume = SendGain;
        }

        public bool EchoRisk
        {
            get { return player != null && cap != null && OutId == CapId; }
        }

        // ---------- devices ----------

        public static List<Dev> Devices()
        {
            List<Dev> list = new List<Dev>();
            list.Add(new Dev { Id = "", Name = "Default device" });
            try
            {
                using (MMDeviceEnumerator en = new MMDeviceEnumerator())
                {
                    foreach (MMDevice d in en.EnumerateAudioEndPoints(DataFlow.Render, DeviceState.Active))
                    {
                        list.Add(new Dev { Id = d.ID, Name = d.FriendlyName });
                    }
                }
            }
            catch { }
            return list;
        }

        private static MMDevice GetDevice(string id)
        {
            MMDeviceEnumerator en = new MMDeviceEnumerator();
            if (!string.IsNullOrEmpty(id))
            {
                try { return en.GetDevice(id); } catch { }
            }
            return en.GetDefaultAudioEndpoint(DataFlow.Render, Role.Multimedia);
        }

        // ---------- phone sound on this PC ----------

        private void StartPlayer()
        {
            lock (playLock)
            {
                if (player != null) return;
                try
                {
                    bwp = new BufferedWaveProvider(new WaveFormat(Rate, 16, 2));
                    bwp.BufferDuration = TimeSpan.FromMilliseconds(2000);
                    bwp.DiscardOnBufferOverflow = true;
                    bwp.ReadFully = true;
                    pvol = new VolumeSampleProvider(bwp.ToSampleProvider());
                    pvol.Volume = PlayMute ? 0f : PlayVol;
                    WasapiOut o = new WasapiOut(GetDevice(OutId), AudioClientShareMode.Shared, true, Math.Max(30, LatencyMs / 2));
                    o.Init(new SampleToWaveProvider16(pvol));
                    primed = false;
                    player = o;
                }
                catch (Exception e)
                {
                    LogErr("Could not play the phone sound: " + e.Message);
                    player = null;
                }
            }
        }

        private void StopPlayer()
        {
            lock (playLock)
            {
                if (player == null) return;
                try { player.Stop(); } catch { }
                try { player.Dispose(); } catch { }
                player = null;
                bwp = null;
                pvol = null;
                PlayLevel = 0f;
                BufMs = 0;
            }
        }

        public void RestartPlayer()
        {
            StopPlayer();
            Refresh();
        }

        private void OnAudio(byte[] b)
        {
            lock (playLock)
            {
                if (player == null || bwp == null) return;
                RecvKb += b.Length / 1024;
                int peak = 0;
                for (int i = 0; i + 1 < b.Length; i += 2)
                {
                    int s = Math.Abs((int)BitConverter.ToInt16(b, i));
                    if (s > peak) peak = s;
                }
                PlayLevel = Math.Max(peak / 32768f, PlayLevel * 0.85f);

                double have = bwp.BufferedDuration.TotalMilliseconds;
                if (have > LatencyMs + 150)
                {
                    bwp.ClearBuffer();
                    Dropped++;
                    primed = false;
                    try { player.Pause(); } catch { }
                }
                bwp.AddSamples(b, 0, b.Length);
                BufMs = (int)bwp.BufferedDuration.TotalMilliseconds;
                if (!primed && bwp.BufferedDuration.TotalMilliseconds >= LatencyMs / 2.0)
                {
                    primed = true;
                    try { player.Play(); } catch (Exception e) { LogErr("Play: " + e.Message); }
                }
            }
        }

        // ---------- PC sound to the phone ----------

        private void StartCapture()
        {
            lock (capLock)
            {
                if (cap != null) return;
                try
                {
                    WasapiLoopbackCapture c = new WasapiLoopbackCapture(GetDevice(CapId));
                    WaveFormat fmt = c.WaveFormat;
                    cbw = new BufferedWaveProvider(fmt);
                    cbw.DiscardOnBufferOverflow = true;
                    cbw.BufferDuration = TimeSpan.FromSeconds(1);
                    cbw.ReadFully = false;
                    ISampleProvider sp = cbw.ToSampleProvider();
                    if (fmt.Channels == 1)
                    {
                        sp = new MonoToStereoSampleProvider(sp);
                    }
                    else if (fmt.Channels > 2)
                    {
                        MultiplexingSampleProvider mux = new MultiplexingSampleProvider(new ISampleProvider[] { sp }, 2);
                        mux.ConnectInputToOutput(0, 0);
                        mux.ConnectInputToOutput(1, 1);
                        sp = mux;
                    }
                    if (fmt.SampleRate != Rate) sp = new WdlResamplingSampleProvider(sp, Rate);
                    cvol = new VolumeSampleProvider(sp);
                    cvol.Volume = SendGain;
                    conv = new SampleToWaveProvider16(cvol);
                    c.DataAvailable += OnCapture;
                    c.RecordingStopped += (s, e) =>
                    {
                        if (e.Exception != null) LogErr("Capture stopped: " + e.Exception.Message);
                    };
                    c.StartRecording();
                    cap = c;
                }
                catch (Exception e)
                {
                    LogErr("Could not capture the PC sound: " + e.Message);
                    cap = null;
                }
            }
        }

        private void StopCapture()
        {
            lock (capLock)
            {
                if (cap == null) return;
                try { cap.StopRecording(); } catch { }
                try { cap.Dispose(); } catch { }
                cap = null;
                cbw = null;
                conv = null;
                cvol = null;
                SendLevel = 0f;
            }
        }

        public void RestartCapture()
        {
            StopCapture();
            Refresh();
        }

        private void OnCapture(object sender, WaveInEventArgs e)
        {
            Link l = link;
            if (l == null) return;
            lock (capLock)
            {
                if (cbw == null || conv == null) return;
                cbw.AddSamples(e.Buffer, 0, e.BytesRecorded);
                byte[] tmp = new byte[Chunk];
                int n;
                while ((n = conv.Read(tmp, 0, tmp.Length)) > 0)
                {
                    n -= n % 4;
                    if (n <= 0) break;
                    byte[] chunk = new byte[n];
                    Buffer.BlockCopy(tmp, 0, chunk, 0, n);
                    int peak = 0;
                    for (int i = 0; i + 1 < n; i += 2)
                    {
                        int s = Math.Abs((int)BitConverter.ToInt16(chunk, i));
                        if (s > peak) peak = s;
                    }
                    SendLevel = Math.Max(peak / 32768f, SendLevel * 0.85f);
                    SentKb += n / 1024;
                    l.Send(2, chunk);
                }
            }
        }
    }
}

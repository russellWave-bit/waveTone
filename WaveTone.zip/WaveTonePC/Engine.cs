using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using NAudio.CoreAudioApi;
using NAudio.Wave;
using NAudio.Wave.SampleProviders;

namespace WaveTonePC
{
    public sealed class Phone
    {
        public string Name;
        public string Ip;
        public int Port;
        public DateTime Seen;
        public bool Wanted = true;
        public int Seq;
        public string Label { get { return Name + "   " + Ip; } }
    }

    public sealed class Dev
    {
        public string Id;
        public string Name;
        public override string ToString() { return Name; }
    }

    public sealed class Settings
    {
        public string Ip { get; set; } = "";
        public int Port { get; set; } = 8765;
        public int DelayMode { get; set; } = 0;
        public int Nudge { get; set; } = 0;
        public int Viz { get; set; } = 1;
        public int Theme { get; set; } = 0;
        public int MediaPick { get; set; } = 0;
        public bool PillOn { get; set; } = true;
        public double PillX { get; set; } = -1;
        public double PillY { get; set; } = -1;
        public bool Want { get; set; } = true;
        public bool Allow { get; set; } = true;
        public double PlayVol { get; set; } = 1.0;
        public double SendGain { get; set; } = 1.0;
        public bool ShowHealth { get; set; } = true;
        public string OutId { get; set; } = "";
        public string CapId { get; set; } = "";
    }

    /// <summary>Finds the phone, keeps the link, and moves sound both ways.</summary>
    public sealed class Engine
    {
        public static readonly Engine I = new Engine();
        private const int Rate = 48000;
        private const int Chunk = 1920; // 10 ms of 48 kHz stereo 16-bit

        // what you choose here
        public volatile bool Want = true;      // play the phone's sound on this PC
        public volatile bool Allow = true;     // let the phone hear this PC
        public int DelayMode;
        public int Nudge;
        public int Viz = 1;
        public int Theme;
        public int MediaPick;
        public bool PillOn = true;
        public double PillX = -1;
        public double PillY = -1;
        public int Port = 8765;
        public readonly Cushion Cush = new Cushion();
        public float PlayVol = 1f;
        public bool PlayMute;
        public float SendGain = 1f;
        public bool ShowHealth = true;
        public string OutId = "";
        public string CapId = "";
        public string Ip = "";

        // the phone on the other end
        public volatile bool Connected;
        public volatile bool Connecting;
        public string PeerName = "";
        public volatile bool PeerWant;
        public volatile bool PeerAllow;

        // live numbers
        public volatile float PlayLevel;
        public volatile float SendLevel;
        public readonly BandAnalyzer PlayBands = new BandAnalyzer();
        public readonly BandAnalyzer SendBands = new BandAnalyzer();
        public int RttMs;
        public int BufMs;
        public int Dropped;
        public long SentKb;
        public long RecvKb;
        public string Message = "";
        public volatile bool EverConnected;
        private volatile bool userStopped;
        private string lastIp = "";
        private int lastPort = 8765;
        private bool reconOn;
        private readonly Dictionary<string, int> seqSeen = new Dictionary<string, int>();

        // media
        public volatile MediaInfo LocalMedia = new MediaInfo();   // what plays on this PC
        public volatile MediaInfo PeerMedia = new MediaInfo();    // what plays on the phone
        private int sentCoverKey = -1;

        /// <summary>2 connected, 1 connecting or reconnecting, 0 off</summary>
        public int State { get { return Connected ? 2 : (Connecting || (EverConnected && !userStopped)) ? 1 : 0; } }
        public bool HasTarget { get { return lastIp.Length > 0 || Ip.Length > 0; } }
        public int TargetMs { get { return (int)Cush.Effective; } }
        public int Underruns { get { return Cush.Underruns; } }

        private readonly Dictionary<string, Phone> phones = new Dictionary<string, Phone>();
        private readonly object plock = new object();
        private readonly List<string> errors = new List<string>();
        private Link link;
        private UdpClient udp;
        private bool discoveryOn;

        private readonly object playLock = new object();
        private WasapiOut player;
        private JitterSource jit;
        private VolumeSampleProvider pvol;

        private readonly object capLock = new object();
        private WasapiLoopbackCapture cap;
        private BufferedWaveProvider cbw;
        private IWaveProvider conv;
        private VolumeSampleProvider cvol;

        private static string SettingsPath
        {
            get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "WaveTone", "settings.json"); }
        }

        public void Load()
        {
            try
            {
                if (!File.Exists(SettingsPath)) return;
                Settings s = JsonSerializer.Deserialize<Settings>(File.ReadAllText(SettingsPath));
                if (s == null) return;
                Ip = s.Ip ?? "";
                Port = s.Port;
                DelayMode = s.DelayMode;
                Nudge = s.Nudge;
                Viz = s.Viz;
                Theme = s.Theme;
                MediaPick = s.MediaPick;
                PillOn = s.PillOn;
                PillX = s.PillX;
                PillY = s.PillY;
                lastIp = Ip;
                lastPort = Port;
                Want = s.Want;
                Allow = s.Allow;
                PlayVol = (float)s.PlayVol;
                SendGain = (float)s.SendGain;
                ShowHealth = s.ShowHealth;
                OutId = s.OutId ?? "";
                CapId = s.CapId ?? "";
            }
            catch { }
        }

        public void Save()
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(SettingsPath));
                Settings s = new Settings
                {
                    Ip = Ip, Port = Port, DelayMode = DelayMode, Nudge = Nudge, Viz = Viz, Theme = Theme, MediaPick = MediaPick, PillOn = PillOn, PillX = PillX, PillY = PillY, Want = Want, Allow = Allow, PlayVol = PlayVol,
                    SendGain = SendGain, ShowHealth = ShowHealth, OutId = OutId, CapId = CapId
                };
                File.WriteAllText(SettingsPath, JsonSerializer.Serialize(s));
            }
            catch { }
        }

        public void LogErr(string msg)
        {
            lock (errors)
            {
                errors.Insert(0, DateTime.Now.ToString("HH:mm:ss") + "  " + msg);
                while (errors.Count > 60) errors.RemoveAt(errors.Count - 1);
            }
        }

        public string[] Errors()
        {
            lock (errors) { return errors.ToArray(); }
        }

        public void ClearErrors()
        {
            lock (errors) { errors.Clear(); }
        }

        // ---------- finding the phone ----------

        public void StartDiscovery()
        {
            if (discoveryOn) return;
            discoveryOn = true;
            Thread t = new Thread(DiscoverLoop);
            t.IsBackground = true;
            t.Start();
        }

        private void DiscoverLoop()
        {
            StartReconnector();
            try
            {
                udp = new UdpClient();
                udp.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
                udp.Client.Bind(new IPEndPoint(IPAddress.Any, 8766));
                IPEndPoint any = new IPEndPoint(IPAddress.Any, 0);
                while (true)
                {
                    byte[] data = udp.Receive(ref any);
                    string s = Encoding.UTF8.GetString(data);
                    string[] p = s.Split('|');
                    if (p.Length < 3 || p[0] != "WAVETONE") continue;
                    int port;
                    if (!int.TryParse(p[2], out port)) continue;
                    bool wanted = p.Length < 4 || p[3] == "1";
                    int seq = 0;
                    if (p.Length > 4) int.TryParse(p[4], out seq);
                    string ip = any.Address.ToString();
                    lock (plock)
                    {
                        phones[ip] = new Phone { Name = p[1], Ip = ip, Port = port, Seen = DateTime.UtcNow, Wanted = wanted, Seq = seq };
                    }
                    bool first = !seqSeen.ContainsKey(ip);
                    int prev = first ? seq : seqSeen[ip];
                    seqSeen[ip] = seq;
                    if (!Connected && !Connecting)
                    {
                        if (wanted && !first && seq != prev)
                        {
                            // the phone's own Connect button was pressed
                            userStopped = false;
                            Connect(ip, port, true);
                        }
                        else if (wanted && ip == Ip && !userStopped)
                        {
                            Connect(ip, port, true);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                LogErr("Finding phones: " + e.Message);
            }
        }

        /// <summary>If the link drops by accident, join again every few seconds. A deliberate Disconnect stays off.</summary>
        private void StartReconnector()
        {
            if (reconOn) return;
            reconOn = true;
            Thread t = new Thread(() =>
            {
                while (true)
                {
                    Thread.Sleep(2500);
                    try
                    {
                        if (!Connected && !Connecting && !userStopped && EverConnected && lastIp.Length > 0)
                        {
                            Connect(lastIp, lastPort, true);
                        }
                    }
                    catch { }
                }
            });
            t.IsBackground = true;
            t.Start();
        }

        public List<Phone> Phones()
        {
            lock (plock)
            {
                List<string> dead = new List<string>();
                foreach (KeyValuePair<string, Phone> kv in phones)
                {
                    if ((DateTime.UtcNow - kv.Value.Seen).TotalSeconds > 5) dead.Add(kv.Key);
                }
                foreach (string k in dead) phones.Remove(k);
                return new List<Phone>(phones.Values);
            }
        }

        // ---------- the link ----------

        public void Connect(string ip, int port, bool quiet = false)
        {
            if (Connected || Connecting) return;
            if (!quiet) userStopped = false;
            Connecting = true;
            if (!quiet) Message = "Connecting...";
            lastIp = ip;
            lastPort = port;
            Thread t = new Thread(() => RunLink(ip, port, quiet));
            t.IsBackground = true;
            t.Start();
        }

        /// <summary>The user pressed Disconnect. Tell the phone so it does not ask us back, then hang up.</summary>
        public void Disconnect()
        {
            userStopped = true;
            Link l = link;
            if (l == null) return;
            try
            {
                string json = JsonSerializer.Serialize(new { name = Environment.MachineName, want = false, allow = false, bye = true });
                l.Send(1, Encoding.UTF8.GetBytes(json));
            }
            catch { }
            Task.Delay(250).ContinueWith(_ => l.Close());
        }

        public void ToggleLink()
        {
            if (Connected) Disconnect();
            else if (!Connecting && lastIp.Length > 0) Connect(lastIp, lastPort);
            else if (!Connecting && Ip.Length > 0) Connect(Ip, lastPort);
        }

        private void RunLink(string ip, int port, bool quiet)
        {
            TcpClient c = new TcpClient();
            try
            {
                IAsyncResult ar = c.BeginConnect(ip, port, null, null);
                if (!ar.AsyncWaitHandle.WaitOne(3000))
                {
                    c.Close();
                    if (!quiet) Message = "Could not reach the phone. Check it is on and on the same Wi-Fi.";
                    Connecting = false;
                    return;
                }
                c.EndConnect(ar);
                c.NoDelay = true;
                c.ReceiveTimeout = 9000;
            }
            catch (Exception e)
            {
                if (!quiet) Message = "Could not connect: " + e.Message;
                Connecting = false;
                return;
            }

            Link l = new Link(c);
            link = l;
            Ip = ip;
            Port = port;
            lastPort = port;
            Dropped = 0;
            SentKb = 0;
            RecvKb = 0;
            sentCoverKey = -1;
            Cush.Mode = DelayMode;
            Cush.Nudge = Nudge;
            Cush.Reset();
            EverConnected = true;
            userStopped = false;
            Connected = true;
            Connecting = false;
            Message = "";
            Save();
            SendControl();
            PushLocalMedia();

            Thread pinger = new Thread(() =>
            {
                while (l.Alive)
                {
                    l.Send(3, BitConverter.GetBytes(Stopwatch.GetTimestamp()));
                    Thread.Sleep(2000);
                }
            });
            pinger.IsBackground = true;
            pinger.Start();

            l.ReadLoop((t, b) => OnFrame(l, t, b));

            link = null;
            Connected = false;
            PeerName = "";
            PeerWant = false;
            PeerAllow = false;
            RttMs = 0;
            PeerMedia = new MediaInfo();
            StopCapture();
            StopPlayer();
            Message = userStopped ? "Disconnected." : "Connection lost. Joining again...";
        }

        private void OnFrame(Link l, byte type, byte[] b)
        {
            switch (type)
            {
                case 1:
                    try
                    {
                        bool bye = false;
                        using (JsonDocument d = JsonDocument.Parse(b))
                        {
                            JsonElement r = d.RootElement;
                            JsonElement v;
                            if (r.TryGetProperty("name", out v)) PeerName = v.GetString();
                            if (r.TryGetProperty("want", out v)) PeerWant = v.GetBoolean();
                            if (r.TryGetProperty("allow", out v)) PeerAllow = v.GetBoolean();
                            if (r.TryGetProperty("bye", out v)) bye = v.GetBoolean();
                        }
                        if (bye)
                        {
                            userStopped = true;
                            Message = "The phone disconnected. Press Connect to join again.";
                            l.Close();
                            return;
                        }
                        Refresh();
                    }
                    catch (Exception e)
                    {
                        LogErr("Bad message from the phone: " + e.Message);
                    }
                    break;
                case 2:
                    OnAudio(b);
                    break;
                case 3:
                    l.Send(4, b);
                    break;
                case 4:
                    if (b.Length == 8)
                    {
                        long sent = BitConverter.ToInt64(b, 0);
                        RttMs = (int)((Stopwatch.GetTimestamp() - sent) * 1000L / Stopwatch.Frequency);
                    }
                    break;
                case 5:
                    try
                    {
                        using (JsonDocument d = JsonDocument.Parse(b))
                        {
                            JsonElement r = d.RootElement;
                            JsonElement v;
                            MediaInfo m = new MediaInfo();
                            if (r.TryGetProperty("title", out v)) m.Title = v.GetString() ?? "";
                            if (r.TryGetProperty("artist", out v)) m.Artist = v.GetString() ?? "";
                            if (r.TryGetProperty("app", out v)) m.App = v.GetString() ?? "";
                            if (r.TryGetProperty("playing", out v)) m.Playing = v.GetBoolean();
                            if (r.TryGetProperty("pos", out v)) m.PosMs = v.GetInt64();
                            if (r.TryGetProperty("dur", out v)) m.DurMs = v.GetInt64();
                            if (r.TryGetProperty("like", out v)) m.CanLike = v.GetBoolean();
                            if (r.TryGetProperty("liked", out v)) m.Liked = v.GetBoolean();
                            if (r.TryGetProperty("vol", out v)) m.Vol = v.GetInt32();
                            if (r.TryGetProperty("ck", out v)) m.CoverKey = v.GetInt32();
                            m.PosAt = Environment.TickCount64;
                            MediaInfo old = PeerMedia;
                            if (old.CoverKey == m.CoverKey) m.CoverJpeg = old.CoverJpeg;
                            PeerMedia = m;
                        }
                    }
                    catch (Exception e)
                    {
                        LogErr("Bad media message: " + e.Message);
                    }
                    break;
                case 6:
                    if (b.Length > 8)
                    {
                        int key = (b[0] << 24) | (b[1] << 16) | (b[2] << 8) | b[3];
                        MediaInfo cur = PeerMedia;
                        if (cur.CoverKey == key)
                        {
                            MediaInfo m = cur.Copy();
                            byte[] jpg = new byte[b.Length - 4];
                            Buffer.BlockCopy(b, 4, jpg, 0, jpg.Length);
                            m.CoverJpeg = jpg;
                            PeerMedia = m;
                        }
                    }
                    break;
                case 7:
                    try
                    {
                        using (JsonDocument d = JsonDocument.Parse(b))
                        {
                            string cmd = d.RootElement.GetProperty("cmd").GetString();
                            long v = 0;
                            JsonElement e;
                            if (d.RootElement.TryGetProperty("v", out e)) v = e.GetInt64();
                            PcMedia.I.Command(cmd, v);
                        }
                    }
                    catch { }
                    break;
            }
        }

        public void SendControl()
        {
            Link l = link;
            if (l == null) return;
            string json = JsonSerializer.Serialize(new { name = Environment.MachineName, want = Want, allow = Allow });
            l.Send(1, Encoding.UTF8.GetBytes(json));
        }

        // ---------- media ----------

        /// <summary>1 = what plays on this PC, 2 = what plays on the phone.</summary>
        public int MediaSource()
        {
            if (MediaPick == 1) return 1;
            if (MediaPick == 2) return 2;
            MediaInfo a = LocalMedia, b = PeerMedia;
            if (a.Playing) return 1;
            if (Connected && b.Playing) return 2;
            if (a.Has) return 1;
            if (Connected && b.Has) return 2;
            return 1;
        }

        public MediaInfo ShownMedia() { return MediaSource() == 2 ? PeerMedia : LocalMedia; }

        public void SetLocalMedia(MediaInfo m, bool push = true)
        {
            LocalMedia = m;
            if (push) PushLocalMedia();
        }

        public void PushLocalMedia()
        {
            Link l = link;
            if (l == null) return;
            MediaInfo m = LocalMedia;
            string json = JsonSerializer.Serialize(new
            {
                title = m.Title, artist = m.Artist, app = m.App, playing = m.Playing,
                pos = m.Now(), dur = m.DurMs, vol = m.Vol, ck = m.CoverKey
            });
            l.Send(5, Encoding.UTF8.GetBytes(json));
            if (m.CoverKey != 0 && m.CoverKey != sentCoverKey && m.CoverJpeg != null)
            {
                byte[] buf = new byte[4 + m.CoverJpeg.Length];
                buf[0] = (byte)(m.CoverKey >> 24);
                buf[1] = (byte)(m.CoverKey >> 16);
                buf[2] = (byte)(m.CoverKey >> 8);
                buf[3] = (byte)m.CoverKey;
                Buffer.BlockCopy(m.CoverJpeg, 0, buf, 4, m.CoverJpeg.Length);
                l.Send(6, buf);
                sentCoverKey = m.CoverKey;
            }
        }

        public void SendCmd(string cmd, long v = 0)
        {
            Link l = link;
            if (l == null) return;
            string json = JsonSerializer.Serialize(new { cmd = cmd, v = v });
            l.Send(7, Encoding.UTF8.GetBytes(json));
        }

        /// <summary>A button in the player: it goes to whichever device is shown.</summary>
        public void Act(string cmd, long v = 0)
        {
            if (MediaSource() == 2) SendCmd(cmd, v);
            else PcMedia.I.Command(cmd, v);
        }

        /// <summary>Called after any choice changes: tell the phone, then start or stop each direction.</summary>
        public void Changed()
        {
            Save();
            SendControl();
            Refresh();
        }

        public void Refresh()
        {
            Link l = link;
            bool play = l != null && Want && PeerAllow;
            bool send = l != null && Allow && PeerWant;
            if (play) StartPlayer(); else StopPlayer();
            if (send) StartCapture(); else StopCapture();
            if (pvol != null) pvol.Volume = PlayMute ? 0f : PlayVol;
            if (cvol != null) cvol.Volume = SendGain;
        }

        public bool EchoRisk
        {
            get { return player != null && cap != null && OutId == CapId; }
        }

        // ---------- devices ----------

        public static List<Dev> Devices()
        {
            List<Dev> list = new List<Dev>();
            list.Add(new Dev { Id = "", Name = "Default device" });
            try
            {
                using (MMDeviceEnumerator en = new MMDeviceEnumerator())
                {
                    foreach (MMDevice d in en.EnumerateAudioEndPoints(DataFlow.Render, DeviceState.Active))
                    {
                        list.Add(new Dev { Id = d.ID, Name = d.FriendlyName });
                    }
                }
            }
            catch { }
            return list;
        }

        private static MMDevice GetDevice(string id)
        {
            MMDeviceEnumerator en = new MMDeviceEnumerator();
            if (!string.IsNullOrEmpty(id))
            {
                try { return en.GetDevice(id); } catch { }
            }
            return en.GetDefaultAudioEndpoint(DataFlow.Render, Role.Multimedia);
        }

        // ---------- phone sound on this PC ----------

        private void StartPlayer()
        {
            lock (playLock)
            {
                if (player != null) return;
                try
                {
                    Cush.Mode = DelayMode;
                    Cush.Nudge = Nudge;
                    Cush.Reset();
                    jit = new JitterSource(Cush);
                    pvol = new VolumeSampleProvider(jit.ToSampleProvider());
                    pvol.Volume = PlayMute ? 0f : PlayVol;
                    WasapiOut o = new WasapiOut(GetDevice(OutId), AudioClientShareMode.Shared, true, 40);
                    o.Init(new SampleToWaveProvider16(pvol));
                    o.Play();
                    player = o;
                }
                catch (Exception e)
                {
                    LogErr("Could not play the phone sound: " + e.Message);
                    player = null;
                }
            }
        }

        private void StopPlayer()
        {
            lock (playLock)
            {
                if (player == null) return;
                try { player.Stop(); } catch { }
                try { player.Dispose(); } catch { }
                player = null;
                jit = null;
                pvol = null;
                PlayLevel = 0f;
                PlayBands.Clear();
                BufMs = 0;
            }
        }

        public void RestartPlayer()
        {
            StopPlayer();
            Refresh();
        }

        /// <summary>Delay mode or nudge changed: tell the cushion.</summary>
        public void ApplyCushion()
        {
            Cush.Mode = DelayMode;
            Cush.Nudge = Nudge;
            if (jit != null && Cush.Target < 0) Cush.Reset();
        }

        public void ResetCushion()
        {
            Cush.Mode = DelayMode;
            Cush.Nudge = Nudge;
            Cush.Reset();
        }

        private void OnAudio(byte[] b)
        {
            JitterSource j = jit;
            if (player == null || j == null) return;
            RecvKb += b.Length / 1024;
            int peak = 0;
            for (int i = 0; i + 1 < b.Length; i += 2)
            {
                int s = Math.Abs((int)BitConverter.ToInt16(b, i));
                if (s > peak) peak = s;
            }
            PlayLevel = Math.Max(peak / 32768f, PlayLevel * 0.85f);
            PlayBands.Feed(b, b.Length);
            j.Add(b);
            BufMs = j.QueuedMs;
            Dropped = j.Dropped;
        }

        // ---------- PC sound to the phone ----------

        private void StartCapture()
        {
            lock (capLock)
            {
                if (cap != null) return;
                try
                {
                    WasapiLoopbackCapture c = new WasapiLoopbackCapture(GetDevice(CapId));
                    WaveFormat fmt = c.WaveFormat;
                    cbw = new BufferedWaveProvider(fmt);
                    cbw.DiscardOnBufferOverflow = true;
                    cbw.BufferDuration = TimeSpan.FromSeconds(1);
                    cbw.ReadFully = false;
                    ISampleProvider sp = cbw.ToSampleProvider();
                    if (fmt.Channels == 1)
                    {
                        sp = new MonoToStereoSampleProvider(sp);
                    }
                    else if (fmt.Channels > 2)
                    {
                        MultiplexingSampleProvider mux = new MultiplexingSampleProvider(new ISampleProvider[] { sp }, 2);
                        mux.ConnectInputToOutput(0, 0);
                        mux.ConnectInputToOutput(1, 1);
                        sp = mux;
                    }
                    if (fmt.SampleRate != Rate) sp = new WdlResamplingSampleProvider(sp, Rate);
                    cvol = new VolumeSampleProvider(sp);
                    cvol.Volume = SendGain;
                    conv = new SampleToWaveProvider16(cvol);
                    c.DataAvailable += OnCapture;
                    c.RecordingStopped += (s, e) =>
                    {
                        if (e.Exception != null) LogErr("Capture stopped: " + e.Exception.Message);
                    };
                    c.StartRecording();
                    cap = c;
                }
                catch (Exception e)
                {
                    LogErr("Could not capture the PC sound: " + e.Message);
                    cap = null;
                }
            }
        }

        private void StopCapture()
        {
            lock (capLock)
            {
                if (cap == null) return;
                try { cap.StopRecording(); } catch { }
                try { cap.Dispose(); } catch { }
                cap = null;
                cbw = null;
                conv = null;
                cvol = null;
                SendLevel = 0f;
                SendBands.Clear();
            }
        }

        public void RestartCapture()
        {
            StopCapture();
            Refresh();
        }

        private void OnCapture(object sender, WaveInEventArgs e)
        {
            Link l = link;
            if (l == null) return;
            lock (capLock)
            {
                if (cbw == null || conv == null) return;
                cbw.AddSamples(e.Buffer, 0, e.BytesRecorded);
                byte[] tmp = new byte[Chunk];
                int n;
                while ((n = conv.Read(tmp, 0, tmp.Length)) > 0)
                {
                    n -= n % 4;
                    if (n <= 0) break;
                    byte[] chunk = new byte[n];
                    Buffer.BlockCopy(tmp, 0, chunk, 0, n);
                    int peak = 0;
                    for (int i = 0; i + 1 < n; i += 2)
                    {
                        int s = Math.Abs((int)BitConverter.ToInt16(chunk, i));
                        if (s > peak) peak = s;
                    }
                    SendLevel = Math.Max(peak / 32768f, SendLevel * 0.85f);
                    SendBands.Feed(chunk, n);
                    SentKb += n / 1024;
                    l.Send(2, chunk);
                }
            }
        }
    }
}

using System;
using System.Collections.Generic;
using System.Diagnostics;
using NAudio.Wave;

namespace WaveTonePC
{
    /// <summary>
    /// The smart cushion. Watches how evenly sound chunks arrive and keeps just enough sound
    /// waiting in line. Mode 0 = Smart, 1 = Fast, 2 = Steady. Same idea as on the phone.
    /// </summary>
    public sealed class Cushion
    {
        public volatile float Target = 40f;
        public volatile int Nudge;
        public volatile int Mode;
        public volatile int Underruns;
        private long lastArr;
        private float peak;
        private long lastShrink;

        private static long NowMs() { return Stopwatch.GetTimestamp() * 1000L / Stopwatch.Frequency; }

        private float Lo { get { return Mode == 1 ? 15f : Mode == 2 ? 220f : 25f; } }
        private float Hi { get { return Mode == 1 ? 60f : Mode == 2 ? 300f : 220f; } }

        public void Reset()
        {
            lastArr = 0;
            peak = 0f;
            Underruns = 0;
            Target = Mode == 1 ? 25f : Mode == 2 ? 240f : 40f;
        }

        public void Arrived()
        {
            long now = Stopwatch.GetTimestamp();
            if (lastArr != 0)
            {
                float gap = (now - lastArr) * 1000f / Stopwatch.Frequency;
                if (gap < 500f)
                {
                    float dev = Math.Abs(gap - 10f);
                    peak = Math.Max(dev, peak * 0.9993f);
                }
            }
            lastArr = now;
            float want = Math.Min(Hi, Math.Max(Lo, 20f + 1.5f * peak));
            long ms = NowMs();
            if (want > Target) Target = want;
            else if (ms - lastShrink > 500 && Target > want)
            {
                Target = Math.Max(want, Target - 1f);
                lastShrink = ms;
            }
            if (Target < Lo) Target = Lo;
            if (Target > Hi) Target = Hi;
        }

        public void Underrun()
        {
            Underruns++;
            Target = Math.Min(Hi, Target + 25f);
            peak = Math.Max(peak, Target / 1.5f);
        }

        public float Effective { get { return Math.Max(10f, Target + Nudge); } }
    }

    /// <summary>The line of sound waiting to be played. Holds back until the cushion is full, never plays a half-empty line.</summary>
    public sealed class JitterSource : IWaveProvider
    {
        private readonly Queue<byte[]> q = new Queue<byte[]>();
        private readonly object lk = new object();
        private readonly Cushion c;
        private byte[] cur;
        private int curOff;
        private int queued;      // bytes waiting, including the part left in cur
        private bool primed;
        private long dryAt;
        public int Dropped;
        public WaveFormat WaveFormat { get; private set; }

        public JitterSource(Cushion cushion)
        {
            c = cushion;
            WaveFormat = new WaveFormat(48000, 16, 2);
        }

        public int QueuedMs { get { lock (lk) { return queued / 192; } } }

        private static long NowMs() { return Stopwatch.GetTimestamp() * 1000L / Stopwatch.Frequency; }

        public void Add(byte[] b)
        {
            lock (lk)
            {
                c.Arrived();
                float eff = c.Effective;
                if (queued / 192f > eff + 90f)
                {
                    while (queued / 192f > eff + 30f && q.Count > 0)
                    {
                        byte[] d = q.Dequeue();
                        queued -= d.Length;
                        Dropped++;
                    }
                }
                q.Enqueue(b);
                queued += b.Length;
            }
        }

        public int Read(byte[] buffer, int offset, int count)
        {
            lock (lk)
            {
                if (!primed)
                {
                    if (queued / 192f >= c.Effective)
                    {
                        primed = true;
                        if (dryAt != 0)
                        {
                            // the stream carried on soon after running dry: a real hiccup
                            if (NowMs() - dryAt < 300) c.Underrun();
                            dryAt = 0;
                        }
                    }
                    else
                    {
                        Array.Clear(buffer, offset, count);
                        return count;
                    }
                }
                int written = 0;
                while (written < count)
                {
                    if (cur == null)
                    {
                        if (q.Count == 0) break;
                        cur = q.Dequeue();
                        curOff = 0;
                    }
                    int n = Math.Min(count - written, cur.Length - curOff);
                    Buffer.BlockCopy(cur, curOff, buffer, offset + written, n);
                    curOff += n;
                    written += n;
                    queued -= n;
                    if (curOff >= cur.Length) cur = null;
                }
                if (written < count)
                {
                    Array.Clear(buffer, offset + written, count - written);
                    primed = false;
                    dryAt = NowMs();
                }
                return count;
            }
        }
    }
}

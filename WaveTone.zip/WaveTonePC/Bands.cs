using System;

namespace WaveTonePC
{
    /// <summary>
    /// Splits the sound into 8 bands (deep bass to treble) so the waves and bars follow what you hear.
    /// Feed it 48 kHz stereo 16-bit chunks.
    /// </summary>
    public sealed class BandAnalyzer
    {
        private const int N = 1024;
        private static readonly double[] Freq = { 60, 120, 240, 480, 960, 1900, 3800, 7600 };
        private static readonly float[] Lift = { 1f, 1.2f, 1.6f, 2.2f, 3.2f, 4.5f, 6.5f, 10f };

        private readonly float[] ring = new float[N];
        private int pos;
        private readonly float[] hann = new float[N];
        private readonly float[] coef = new float[8];
        private float refv = 0.02f;
        private readonly float[] amp = new float[8];

        /// <summary>0..1 per band, smoothed (quick up, slow down). Read from any thread.</summary>
        public readonly float[] Out = new float[8];

        public BandAnalyzer()
        {
            for (int i = 0; i < N; i++) hann[i] = (float)(0.5 - 0.5 * Math.Cos(2.0 * Math.PI * i / (N - 1)));
            for (int f = 0; f < 8; f++) coef[f] = (float)(2.0 * Math.Cos(2.0 * Math.PI * Freq[f] / 48000.0));
        }

        public void Feed(byte[] b, int n)
        {
            int frames = n / 4;
            for (int i = 0; i < frames; i++)
            {
                int o = i * 4;
                short l = BitConverter.ToInt16(b, o);
                short r = BitConverter.ToInt16(b, o + 2);
                ring[pos] = (l + r) * (0.5f / 32768f);
                pos = (pos + 1) & (N - 1);
            }
            float top = 0f;
            for (int f = 0; f < 8; f++)
            {
                float c = coef[f];
                float s1 = 0f, s2 = 0f;
                for (int k = 0; k < N; k++)
                {
                    float x = ring[(pos + k) & (N - 1)] * hann[k];
                    float s0 = x + c * s1 - s2;
                    s2 = s1;
                    s1 = s0;
                }
                float p = Math.Max(0f, s1 * s1 + s2 * s2 - c * s1 * s2);
                float a = 4f * (float)Math.Sqrt(p) / N * Lift[f];
                amp[f] = a;
                if (a > top) top = a;
            }
            refv = Math.Max(refv * 0.9996f, top);
            for (int f = 0; f < 8; f++)
            {
                float d = top < 0.0025f ? 0f : Math.Min(1f, (float)Math.Pow(amp[f] / Math.Max(refv, 0.03f), 0.75));
                Out[f] = Math.Max(d, Out[f] * 0.88f);
            }
        }

        public void Decay()
        {
            for (int f = 0; f < 8; f++) Out[f] *= 0.85f;
        }

        public void Clear()
        {
            for (int f = 0; f < 8; f++) Out[f] = 0f;
            refv = 0.02f;
            Array.Clear(ring, 0, N);
        }
    }
}

using System;
using System.Net.Sockets;

namespace WaveTonePC
{
    /// <summary>
    /// One connection to the phone. Every message is: 1 byte type, 4 bytes length, then the bytes.
    /// Types: 1 control (JSON), 2 audio (48 kHz stereo 16-bit), 3 ping, 4 pong.
    /// </summary>
    public sealed class Link
    {
        private readonly TcpClient tcp;
        private readonly NetworkStream ns;
        private readonly object wlock = new object();
        public volatile bool Alive = true;

        public Link(TcpClient c)
        {
            tcp = c;
            ns = c.GetStream();
        }

        public void Send(byte type, byte[] payload)
        {
            if (!Alive) return;
            lock (wlock)
            {
                try
                {
                    int n = payload.Length;
                    byte[] buf = new byte[5 + n];
                    buf[0] = type;
                    buf[1] = (byte)(n >> 24);
                    buf[2] = (byte)(n >> 16);
                    buf[3] = (byte)(n >> 8);
                    buf[4] = (byte)n;
                    Buffer.BlockCopy(payload, 0, buf, 5, n);
                    ns.Write(buf, 0, buf.Length);
                }
                catch
                {
                    Close();
                }
            }
        }

        private bool ReadExact(byte[] buf, int n)
        {
            int o = 0;
            while (o < n)
            {
                int r = ns.Read(buf, o, n - o);
                if (r <= 0) return false;
                o += r;
            }
            return true;
        }

        public void ReadLoop(Action<byte, byte[]> onFrame)
        {
            try
            {
                byte[] h = new byte[5];
                while (Alive)
                {
                    if (!ReadExact(h, 5)) break;
                    int n = (h[1] << 24) | (h[2] << 16) | (h[3] << 8) | h[4];
                    if (n < 0 || n > 1000000) break;
                    byte[] b = new byte[n];
                    if (n > 0 && !ReadExact(b, n)) break;
                    onFrame(h[0], b);
                }
            }
            catch
            {
            }
            finally
            {
                Close();
            }
        }

        public void Close()
        {
            Alive = false;
            try { tcp.Close(); } catch { }
        }
    }
}

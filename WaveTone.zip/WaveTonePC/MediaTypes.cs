using System;

namespace WaveTonePC
{
    /// <summary>What is playing on one device. PosAt is Environment.TickCount64 when PosMs was true.</summary>
    public sealed class MediaInfo
    {
        public string Title = "";
        public string Artist = "";
        public string App = "";
        public bool Playing;
        public long PosMs;
        public long DurMs;
        public long PosAt;
        public bool CanLike;
        public bool Liked;
        public int Vol = -1;
        public int CoverKey;
        public byte[] CoverJpeg;

        public bool Has { get { return Title.Length > 0; } }

        public long Now()
        {
            if (!Playing) return PosMs;
            long p = PosMs + (Environment.TickCount64 - PosAt);
            if (p < 0) p = 0;
            if (DurMs > 0 && p > DurMs) p = DurMs;
            return p;
        }

        public MediaInfo Copy() { return (MediaInfo)MemberwiseClone(); }
    }
}

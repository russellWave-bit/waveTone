using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;

namespace WaveTonePC
{
    /// <summary>A small always-on-top pill: shows the link and connects or disconnects. Drag it anywhere.</summary>
    public partial class PillWindow : Window
    {
        private readonly Engine E = Engine.I;
        private readonly DispatcherTimer timer = new DispatcherTimer();
        private readonly Brush mint = new SolidColorBrush(Color.FromRgb(0x1F, 0xD2, 0xAE));
        private readonly Brush amber = new SolidColorBrush(Color.FromRgb(0xF5, 0x9E, 0x0B));
        private readonly Brush grey = new SolidColorBrush(Color.FromRgb(0x9A, 0xA3, 0xC7));

        public PillWindow()
        {
            InitializeComponent();
            double x = E.PillX, y = E.PillY;
            Rect wa = SystemParameters.WorkArea;
            if (x < 0 || y < 0 || x > wa.Right - 60 || y > wa.Bottom - 40)
            {
                x = wa.Left + (wa.Width - Width) / 2;
                y = wa.Top + 6;
            }
            Left = x;
            Top = y;
            timer.Interval = TimeSpan.FromMilliseconds(350);
            timer.Tick += (s, e) => Refresh();
            timer.Start();
            Refresh();
        }

        private void Refresh()
        {
            int st = E.State;
            if (st == 2)
            {
                Dot.Fill = mint;
                Dot.Opacity = 1;
                Line1.Text = "Connected";
                Line2.Text = E.PeerName;
                LinkBtn.Content = "Disconnect";
            }
            else if (st == 1)
            {
                Dot.Fill = amber;
                Dot.Opacity = 0.45 + 0.55 * (0.5 + 0.5 * Math.Sin(Environment.TickCount64 / 260.0));
                Line1.Text = E.Connecting ? "Connecting" : "Reconnecting";
                Line2.Text = "Joining your phone...";
                LinkBtn.Content = "Stop";
            }
            else
            {
                Dot.Fill = grey;
                Dot.Opacity = 1;
                Line1.Text = "Not connected";
                Line2.Text = E.Message.Length > 0 ? E.Message : "Press Connect";
                LinkBtn.Content = "Connect";
            }
        }

        private void LinkClick(object sender, RoutedEventArgs e)
        {
            if (E.State == 0) E.ToggleLink();
            else E.Disconnect();
        }

        private void HideClick(object sender, RoutedEventArgs e)
        {
            App.SetPill(false);
        }

        private void Drag(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState != MouseButtonState.Pressed) return;
            try { DragMove(); } catch { return; }
            E.PillX = Left;
            E.PillY = Top;
            E.Save();
        }
    }
}

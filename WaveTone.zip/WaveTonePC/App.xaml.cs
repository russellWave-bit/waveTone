using System.Windows;

namespace WaveTonePC
{
    public partial class App : Application
    {
    }
}

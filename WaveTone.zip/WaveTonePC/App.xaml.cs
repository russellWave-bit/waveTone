using System.Windows;

namespace WaveTonePC
{
    public partial class App : Application
    {
        /// <summary>True only when the user really quits (tray menu or About page). The window's X just hides to the tray.</summary>
        public static bool Quitting;
        public static PillWindow Pill;
        public static Tray TrayIcon;

        public static void Quit()
        {
            Quitting = true;
            try { Engine.I.Save(); } catch { }
            try { Engine.I.Disconnect(); } catch { }
            if (TrayIcon != null) TrayIcon.Dispose();
            Current.Shutdown();
        }

        public static void ShowMain()
        {
            Window w = Current.MainWindow;
            if (w == null) return;
            w.Show();
            if (w.WindowState == WindowState.Minimized) w.WindowState = WindowState.Normal;
            w.Activate();
        }

        public static void SetPill(bool on)
        {
            Engine.I.PillOn = on;
            Engine.I.Save();
            if (Pill == null) return;
            if (on) Pill.Show(); else Pill.Hide();
        }
    }
}

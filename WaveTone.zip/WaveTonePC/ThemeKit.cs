using System;
using System.Windows;
using System.Windows.Media;
using Microsoft.Win32;

namespace WaveTonePC
{
    /// <summary>Switches every colour of the app between light and dark while it runs.</summary>
    public static class ThemeKit
    {
        public static bool Dark;

        /// <summary>mode: 0 = follow Windows, 1 = light, 2 = dark</summary>
        public static void Apply(int mode)
        {
            bool dark = mode == 2 || (mode == 0 && WindowsIsDark());
            Dark = dark;
            ResourceDictionary r = Application.Current.Resources;

            if (dark)
            {
                S(r, "BgBrush", "#0A0C1F"); S(r, "TextBrush", "#F2F4FF"); S(r, "MutedBrush", "#A9B0D6");
                S(r, "AccBrush", "#F2F4FF"); S(r, "AccHoverBrush", "#FFFFFF"); S(r, "OnAccBrush", "#0A0C1F");
                S(r, "MintBrush", "#3BE3C0"); S(r, "MintTextBrush", "#3BE3C0");
                S(r, "RoseBrush", "#FF6FAE"); S(r, "RoseTextBrush", "#FF6FAE");
                S(r, "VioletBrush", "#A58BFF"); S(r, "AmberBrush", "#FFB347"); S(r, "WarmBrush", "#FFB347");
                S(r, "GoodBrush", "#6FD3A0"); S(r, "TrackBrush", "#40FFFFFF"); S(r, "SelBrush", "#38FFFFFF");
                S(r, "HoverBrush", "#22FFFFFF"); S(r, "InnerBrush", "#22FFFFFF"); S(r, "InnerHoverBrush", "#3AFFFFFF");
                S(r, "PopBrush", "#F21E2347"); S(r, "ScrollBrush", "#55FFFFFF");
                r["GlassBrush"] = V("#D0343A68", "#C0232850");
                r["GlassStrongBrush"] = V("#F0343A68", "#E61E2347");
                r["GlassRim"] = D("#66FFFFFF", "#1AFFFFFF", "#40FFFFFF");
                r["PillBrush"] = V("#F21E2347", "#E617193A");
                r["WallBrush"] = W("#0A0C1F", "#150B2E", "#07131C");
                r["BloomViolet"] = R("#8A8C6BFF"); r["BloomRose"] = R("#70FF6FAE");
                r["BloomMint"] = R("#703BE3C0"); r["BloomAmber"] = R("#50A58BFF");
            }
            else
            {
                S(r, "BgBrush", "#DBE7FF"); S(r, "TextBrush", "#121830"); S(r, "MutedBrush", "#5A6285");
                S(r, "AccBrush", "#121830"); S(r, "AccHoverBrush", "#2A3158"); S(r, "OnAccBrush", "#FFFFFF");
                S(r, "MintBrush", "#1FD2AE"); S(r, "MintTextBrush", "#0B8F78");
                S(r, "RoseBrush", "#FF5FA2"); S(r, "RoseTextBrush", "#D42A78");
                S(r, "VioletBrush", "#8C6BFF"); S(r, "AmberBrush", "#F59E0B"); S(r, "WarmBrush", "#B45309");
                S(r, "GoodBrush", "#0B8F78"); S(r, "TrackBrush", "#33121830"); S(r, "SelBrush", "#D9FFFFFF");
                S(r, "HoverBrush", "#55FFFFFF"); S(r, "InnerBrush", "#66FFFFFF"); S(r, "InnerHoverBrush", "#99FFFFFF");
                S(r, "PopBrush", "#CCFFFFFF"); S(r, "ScrollBrush", "#55121830");
                r["GlassBrush"] = V("#C4FFFFFF", "#A0FFFFFF");
                r["GlassStrongBrush"] = V("#E6FFFFFF", "#D2FFFFFF");
                r["GlassRim"] = D("#F5FFFFFF", "#55FFFFFF", "#A0FFFFFF");
                r["PillBrush"] = V("#F2F7F9FF", "#DCDDE8FF");
                r["WallBrush"] = W("#DBE7FF", "#F6E3F6", "#D6F6EC");
                r["BloomViolet"] = R("#A08C6BFF"); r["BloomRose"] = R("#98FF5FA2");
                r["BloomMint"] = R("#981FD2AE"); r["BloomAmber"] = R("#90F59E0B");
            }
        }

        public static bool WindowsIsDark()
        {
            try
            {
                using (RegistryKey k = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize"))
                {
                    object v = k == null ? null : k.GetValue("AppsUseLightTheme");
                    if (v is int) return (int)v == 0;
                }
            }
            catch { }
            return false;
        }

        private static Color C(string hex) { return (Color)ColorConverter.ConvertFromString(hex); }
        private static void S(ResourceDictionary r, string key, string hex) { r[key] = new SolidColorBrush(C(hex)); }

        private static LinearGradientBrush V(string top, string bottom)
        {
            LinearGradientBrush g = new LinearGradientBrush { StartPoint = new Point(0, 0), EndPoint = new Point(0, 1) };
            g.GradientStops.Add(new GradientStop(C(top), 0));
            g.GradientStops.Add(new GradientStop(C(bottom), 1));
            return g;
        }

        private static LinearGradientBrush D(string a, string b, string c)
        {
            LinearGradientBrush g = new LinearGradientBrush { StartPoint = new Point(0, 0), EndPoint = new Point(1, 1) };
            g.GradientStops.Add(new GradientStop(C(a), 0));
            g.GradientStops.Add(new GradientStop(C(b), 0.5));
            g.GradientStops.Add(new GradientStop(C(c), 1));
            return g;
        }

        private static LinearGradientBrush W(string a, string b, string c)
        {
            LinearGradientBrush g = new LinearGradientBrush { StartPoint = new Point(0, 0), EndPoint = new Point(1, 1) };
            g.GradientStops.Add(new GradientStop(C(a), 0));
            g.GradientStops.Add(new GradientStop(C(b), 0.55));
            g.GradientStops.Add(new GradientStop(C(c), 1));
            return g;
        }

        private static RadialGradientBrush R(string hex)
        {
            Color c = C(hex);
            RadialGradientBrush g = new RadialGradientBrush();
            g.GradientStops.Add(new GradientStop(c, 0));
            g.GradientStops.Add(new GradientStop(Color.FromArgb(0, c.R, c.G, c.B), 1));
            return g;
        }
    }
}
